const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const api = window.nackles;
const island = $('#island'), panel = $('.panel');
const mascotWrap = $('.mascot-wrap');
let mascot = NacklesMascot.mount(mascotWrap);

// ---------- ikonlar (çizgi ikonlar, renk yazının renginden gelir) ----------
const S = 'xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"';
const F = 'xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"';
const ICONS = {
  home: `<svg ${S}><path d="M4 10.5 12 4l8 6.5V19a1 1 0 0 1-1 1h-4.5v-5.5h-5V20H5a1 1 0 0 1-1-1z"/></svg>`,
  ai: `<svg ${S} stroke-width="2.6"><path d="M12 3v18M4.2 7.5l15.6 9M4.2 16.5l15.6-9"/></svg>`,
  note: `<svg ${S}><path d="M9 18V5l11-2v13"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="17.5" cy="16" r="2.5"/></svg>`,
  timer: `<svg ${S}><circle cx="12" cy="13.5" r="7.5"/><path d="M12 10v3.5l2 2M9.5 2.5h5"/></svg>`,
  doc: `<svg ${S}><rect x="5" y="3" width="14" height="18" rx="2.5"/><path d="M9 8h6M9 12h6M9 16h3.5"/></svg>`,
  vol: `<svg ${S}><path d="M4 9.5v5h3.5L12 18V6L7.5 9.5z"/><path d="M15.5 9a4 4 0 0 1 0 6"/></svg>`,
  mute: `<svg ${S}><path d="M4 9.5v5h3.5L12 18V6L7.5 9.5z"/><path d="m16 10 4 4m0-4-4 4"/></svg>`,
  play: `<svg ${F}><path d="M7.5 4.8v14.4a.8.8 0 0 0 1.2.7l11.4-7.2a.8.8 0 0 0 0-1.4L8.7 4.1a.8.8 0 0 0-1.2.7z"/></svg>`,
  pause: `<svg ${F}><rect x="6" y="4.5" width="4" height="15" rx="1.3"/><rect x="14" y="4.5" width="4" height="15" rx="1.3"/></svg>`,
  prev: `<svg ${F}><path d="M5 5h2.2v14H5zM20 5.6v12.8a.7.7 0 0 1-1.1.6L9 12.6a.7.7 0 0 1 0-1.2l9.9-6.4a.7.7 0 0 1 1.1.6z"/></svg>`,
  next: `<svg ${F}><path d="M16.8 5H19v14h-2.2zM4 5.6v12.8a.7.7 0 0 0 1.1.6l9.9-6.4a.7.7 0 0 0 0-1.2L5.1 5a.7.7 0 0 0-1.1.6z"/></svg>`,
  reset: `<svg ${S}><path d="M3.5 12a8.5 8.5 0 1 0 2.6-6.1L3.5 8.5"/><path d="M3.5 3.5v5h5"/></svg>`,
  pc: `<svg ${S}><rect x="4" y="5" width="16" height="10.5" rx="1.5"/><path d="M2.5 19h19"/></svg>`,
  focus: `<svg ${S}><circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3" fill="currentColor"/></svg>`,
  up: `<svg ${S} stroke-width="2.6"><path d="M12 19V5M6 11l6-6 6 6"/></svg>`,
  stop: `<svg ${F}><rect x="6" y="6" width="12" height="12" rx="2.5"/></svg>`,
  chat: `<svg ${S}><path d="M5 18.5V7a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H8.5z"/></svg>`,
  bulb: `<svg ${S}><path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9c.6.4 1 1.1 1 1.8V16h5v-.3c0-.7.4-1.4 1-1.8A6 6 0 0 0 12 3z"/></svg>`,
  check: `<svg ${S} stroke-width="2.6"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg>`,
  globe: `<svg ${S}><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.6 3.7 5.6 3.7 9s-1.2 6.4-3.7 9c-2.5-2.6-3.7-5.6-3.7-9S9.5 5.6 12 3z"/></svg>`,
  lines: `<svg ${S}><path d="M5 7h14M5 12h14M5 17h9"/></svg>`,
  term: `<svg ${S} stroke-width="2.4"><path d="m6 8 4 4-4 4M12.5 16H18"/></svg>`,
  inbox: `<svg ${S}><path d="M4 13.5 6.5 5h11l2.5 8.5V19a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1z"/><path d="M4 13.5h4.5l1 2h5l1-2H20"/></svg>`,
  copy: `<svg ${S}><rect x="8" y="8" width="12" height="12" rx="2.5"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/></svg>`,
  link: `<svg ${S}><path d="M10 14a4.5 4.5 0 0 0 6.4 0l3-3a4.5 4.5 0 0 0-6.4-6.4l-1 1"/><path d="M14 10a4.5 4.5 0 0 0-6.4 0l-3 3a4.5 4.5 0 0 0 6.4 6.4l1-1"/></svg>`,
  text: `<svg ${S}><path d="M5 6h14M12 6v13M9 19h6"/></svg>`,
  pin: `<svg ${S}><path d="M9 4h6l-1 5 3 3v2H7v-2l3-3zM12 14v6"/></svg>`,
  gear: `<svg ${S}><circle cx="12" cy="12" r="3"/><path d="M19.4 13.5a7.6 7.6 0 0 0 0-3l2-1.6-2-3.4-2.4 1a7.6 7.6 0 0 0-2.6-1.5L14 2.5h-4l-.4 2.5A7.6 7.6 0 0 0 7 6.5l-2.4-1-2 3.4 2 1.6a7.6 7.6 0 0 0 0 3l-2 1.6 2 3.4 2.4-1a7.6 7.6 0 0 0 2.6 1.5l.4 2.5h4l.4-2.5a7.6 7.6 0 0 0 2.6-1.5l2.4 1 2-3.4z"/></svg>`,
  hide: `<svg ${S}><path d="M3 12s3.5-6 9-6 9 6 9 6-3.5 6-9 6-9-6-9-6z"/><path d="M4 4l16 16"/></svg>`,
  power: `<svg ${S}><path d="M12 3v8"/><path d="M6.4 6.4a8 8 0 1 0 11.2 0"/></svg>`,
  swap: `<svg ${S} stroke-width="2.6"><path d="M4 8h13l-3-3M20 16H7l3 3"/></svg>`,
  merge: `<svg ${S}><path d="M6 4v5a6 6 0 0 0 6 6h0a6 6 0 0 0 6-6V4M12 15v5"/></svg>`,
  trash: `<svg ${S}><path d="M4 7h16M9 7V4.5h6V7M6.5 7l1 13h9l1-13M10 11v6M14 11v6"/></svg>`,
};
function setIcon(node, name) { if (node.dataset.icon !== name) { node.innerHTML = ICONS[name]; node.dataset.icon = name; } }
for (const n of $$('.ico')) { const m = /\bi-(\w+)/.exec(n.className); if (m && ICONS[m[1] === 'play2' ? 'play' : m[1]]) setIcon(n, m[1] === 'play2' ? 'play' : m[1]); }
$$('.ctl.prev, .ctl.next, .ctl.play').forEach(b => { const i = document.createElement('span'); i.className = 'ico'; b.append(i); setIcon(i, b.classList.contains('prev') ? 'prev' : b.classList.contains('next') ? 'next' : 'play'); });
{ const i = document.createElement('span'); i.className = 'ico'; $('.art').append(i); setIcon(i, 'note'); }
{ const i = document.createElement('span'); i.className = 'ico'; $('.agent-ico').append(i); setIcon(i, 'ai'); }

const AI_STATES = ['running', 'question', 'done', 'error'];
const PAGES = ['home', 'ai', 'music', 'chat', 'focus', 'tray', 'clips', 'notes'];
const HEADINGS = { home: ['', ''], ai: ['Yapay ', 'zekâ'], music: ['Müzik ', 'çalar'], chat: ['Nackles ', 'sohbet'], focus: ['Odak ', 'sayacı'], tray: ['Dosya ', 'tepsisi'], clips: ['Pano ', 'geçmişi'], notes: ['Not ', 'defteri'] };
const PAGE_COLOR = { home: 'var(--c-home)', ai: 'var(--c-ai)', music: 'var(--c-music)', chat: 'var(--c-chat)', focus: 'var(--c-focus)', tray: 'var(--c-tray)', clips: 'var(--c-clips)', notes: 'var(--c-notes)' };
// Her ajanın kendi tonu: başlık, renk, ikon ve çalışırken alttan yükselen renk.
const AGENT = {
  claude: { heading: ['Claude ', 'Code'], color: 'var(--claude)', icon: 'ai', running: 'rgba(38, 168, 74, .62)', ask: 'Claude\'a yaz…' },
  codex: { heading: ['Codex ', 'ajanı'], color: 'var(--codex)', icon: 'term', running: 'rgba(60, 110, 255, .55)', ask: 'Codex\'e yaz…' },
};
const WASH = { question: 'rgba(255, 196, 60, .34)', error: 'rgba(255, 92, 92, .34)' };
const FRESH_MS = 20 * 1000; // "bitti" / "hata" çubukta bu kadar kalır

let view = { sessions: [], links: { claude: true, codex: false, codexAvailable: false }, error: '', history: [], jobsToday: 0 };
let media = { active: false };
let settings = { expandOnHover: true, showClock: true, sound: true, volume: 0.6, sleepAfterMin: 3, music: true };
let hovering = false, pinned = false, expanded = false, hoverTimer = null, leaveTimer = null;
let page = 'home';
let geminiFocused = false;
let lastActivity = Date.now(), tempMood = null, tempMoodUntil = 0;

// ---------- yardımcılar ----------
const pad2 = n => String(n).padStart(2, '0');
function duration(ms) {
  const s = Math.max(0, Math.floor(ms / 1000));
  return s >= 3600 ? `${Math.floor(s / 3600)}:${pad2(Math.floor(s / 60) % 60)}:${pad2(s % 60)}` : `${Math.floor(s / 60)}:${pad2(s % 60)}`;
}
const hhmm = d => `${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
const DAYS = ['Paz', 'Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt'];
const MONTHS = ['Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara'];
function el(tag, cls, text) { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
const cssUrl = u => `url("${String(u).replace(/"/g, '%22')}")`;

// Ayarlardaki "Adada dene" düğmeleri birkaç saniyeliğine sahte bir oturum gösterir.
let preview = null;
const current = () => (preview && Date.now() < preview.until ? preview.s : view.sessions[0] || null);
function aiState() {
  const s = current();
  if (!s) return null;
  if (s.state === 'running' || s.state === 'question') return s.state;
  if ((s.state === 'done' || s.state === 'error') && Date.now() - s.endedAt < FRESH_MS) return s.state;
  return null;
}
const hasMusic = () => settings.music && media.active;
function barMode() {
  if (aiState()) return 'ai';
  if (fz.endAt) return 'focus';
  if (hasMusic() && media.playing) return 'music';
  return 'idle';
}
function isSleepy() { return settings.sleepAfterMin > 0 && barMode() === 'idle' && Date.now() - lastActivity > settings.sleepAfterMin * 60 * 1000; }
function mediaPos() {
  if (!media.active) return 0;
  const p = media.position + (media.playing ? (Date.now() - media.updated) / 1000 : 0);
  return media.duration > 0 ? Math.min(media.duration, Math.max(0, p)) : Math.max(0, p);
}

// =========================================================
// ODAK SAYACI
// =========================================================
const fz = { h: 0, m: 25, endAt: null, left: null };
const focusTotal = () => (fz.h * 60 + fz.m) * 60000;
const focusLeft = () => fz.endAt ? Math.max(0, fz.endAt - Date.now()) : fz.left ?? focusTotal();
function focusStartPause() {
  if (fz.endAt) { fz.left = fz.endAt - Date.now(); fz.endAt = null; }
  else if (focusLeft() > 0) { fz.endAt = Date.now() + focusLeft(); fz.left = null; }
  api.focusState(Boolean(fz.endAt));
  render();
}
let guardStats = { back: 0, open: 0 };
api.guardStats().then(s => { guardStats = s; });
api.onGuardStats(s => { guardStats = s; if (s.back) setTempMood('happy', 2500); renderFocus(); });
function focusReset() { fz.endAt = null; fz.left = null; api.focusState(false); render(); }
function focusTick() {
  if (fz.endAt && Date.now() >= fz.endAt) { fz.endAt = null; fz.left = null; api.focusState(false); celebrate('done'); render(); }
}

// =========================================================
// ÇİZİM
// =========================================================
function render() {
  const s = current(), mode = barMode(), st = aiState();
  const colorState = st || (s && s.state !== 'ready' ? s.state : null);
  for (const c of AI_STATES) island.classList.toggle(c, c === colorState);
  island.classList.toggle('mode-ai', mode === 'ai');
  island.classList.toggle('mode-music', mode === 'music');
  island.classList.toggle('mode-focus', mode === 'focus');
  island.classList.toggle('idle', mode === 'idle');
  // Saat / pil kapalıysa boştaki ada daralır (CSS genişliği yaylı geçişle değişir).
  island.classList.toggle('no-clock', !settings.showClock);
  island.classList.toggle('no-battery', settings.showBattery === false || $('.battery').classList.contains('none'));
  island.classList.toggle('glow', Boolean(st) && st !== 'running');
  island.classList.toggle('playing', hasMusic() && media.playing);
  island.classList.toggle('sleepy', isSleepy());
  island.classList.toggle('agent-codex', s?.agent === 'codex');
  island.classList.toggle('tucked', isTucked());
  for (const l of $$('.layer')) l.classList.toggle('on', l.classList.contains('layer-' + mode));

  // kapalı çubuk: yapay zekâ ve müzik
  $('.layer-ai .title').textContent = s ? (s.state === 'question' ? (s.permission ? 'İzin istiyor' : 'Seni bekliyor') : s.state === 'done' ? `${s.project} bitti` : s.state === 'error' ? 'Hata' : s.title || s.project) : '';
  if (hasMusic()) $('.m-title').textContent = media.artist ? `${media.title} · ${media.artist}` : media.title;
  setArt();

  renderHome(s);
  renderAI(s);
  renderMusic();
  renderFocus();
  renderChrome();
  renderMood();
  tick();
}

function renderHome(s) {
  // Yapay zekâ kartı
  const card = $('.c-ai');
  for (const c of AI_STATES) card.classList.toggle(c, Boolean(s) && s.state === c);
  card.classList.toggle('codex', s?.agent === 'codex');
  $('.c-ai .c-label').textContent = s ? s.agentName : 'Yapay zekâ';
  setIcon($('.ai-ico .ico'), s?.agent === 'codex' ? 'term' : 'ai');
  let big = String(view.jobsToday), sub = 'bugün biten iş';
  if (s?.state === 'running') { big = s.startedAt ? duration(Date.now() - s.startedAt) : '…'; sub = s.detail || 'Düşünüyor'; }
  else if (s?.state === 'question') { big = 'İzin'; sub = s.permission?.text || 'Seni bekliyor'; }
  else if (s?.state === 'done') { big = 'Bitti'; sub = s.title || s.project; }
  else if (s?.state === 'error') { big = 'Hata'; sub = s.detail; }
  $('.ai-big').textContent = big; $('.ai-sub').textContent = sub;

  // Müzik kartı
  const on = hasMusic();
  $('.music-big').textContent = on ? (media.title || 'Bilinmeyen') : 'Sessiz';
  $('.music-sub').textContent = on ? (media.artist || media.app) : 'Çalan bir şey yok';
  setIcon($('.music-ico .ico'), on && media.playing ? 'pause' : on ? 'play' : 'note');

  // Odak kartı
  const left = focusLeft();
  $('.c-focus').classList.toggle('running', Boolean(fz.endAt));
  $('.focus-big').textContent = duration(left);
  $('.focus-sub').textContent = fz.endAt ? 'Odaklanıyorsun' : fz.left != null ? 'Duraklatıldı' : 'Başlamaya hazır';
  setIcon($('.focus-ico .ico'), fz.endAt ? 'pause' : 'play');
}

function renderAI(s) {
  const left = $('.ai-left');
  left.classList.toggle('calm', !s);
  if (s) {
    const ico = $('.agent-ico'); ico.classList.toggle('codex', s.agent === 'codex');
    setIcon(ico.querySelector('.ico'), AGENT[s.agent].icon);
    $('.agent-name').textContent = `${s.agentName} · ${s.project}`;
  }
  let num = String(view.jobsToday), cap = 'bugün biten iş';
  if (s) {
    num = s.startedAt ? duration((s.endedAt || Date.now()) - s.startedAt) : '0:00';
    cap = s.state === 'done' ? `Bitti · ${s.steps.length} adım` : s.state === 'question' ? 'İzin bekliyor' : s.detail || '';
  }
  $('.ai-num').textContent = num; $('.ai-cap').textContent = cap;

  const links = $('.links'); links.replaceChildren();
  const addLink = (agent, label) => { const b = el('button', 'link-btn', label); b.addEventListener('click', () => api.connect(agent, true)); links.append(b); };
  if (!view.links.claude) addLink('claude', 'Claude Code\'a bağlan');
  if (view.links.codexAvailable && !view.links.codex) addLink('codex', 'Codex\'e bağlan');

  const right = $('.ai-right'), rows = $('.rows');
  right.classList.toggle('asking', Boolean(s?.permission));
  rows.replaceChildren();
  if (s?.permission) {
    $('.box-title').textContent = 'İZİN İSTİYOR';
    const t = $('.perm-text'); t.replaceChildren();
    t.append(`${s.agentName} şunu yapmak istiyor: `, el('b', '', s.permission.text));
    if (!s.permission.canAnswer) t.append(el('small', '', s.agent === 'codex' ? 'Cevabı Codex penceresinden ver.' : 'Cevabı terminalden ver.'));
    $('.perm').classList.toggle('readonly', !s.permission.canAnswer);
  } else if (s && s.state === 'running' && s.steps.length) {
    $('.box-title').textContent = 'ADIMLAR';
    for (const x of s.steps.slice(-4)) rows.append(row(x.state, x.text, ''));
  } else {
    $('.box-title').textContent = 'SON İŞLER';
    for (const h of view.history.slice(0, 4)) rows.append(row(h.state, h.title, hhmm(new Date(h.at))));
    if (!view.history.length) rows.append(el('li', 'empty', 'Henüz biten iş yok. Claude Code ya da Codex bir işi bitirince burada görünür.'));
  }
  if (view.error) rows.prepend(el('li', 'empty', `Bağlantı sunucusu başlamadı: ${view.error}`));
}
function row(state, text, when) { const li = el('li'), tx = el('span', 't', text); tx.translate = false; li.append(el('span', 's ' + state), tx, el('span', 'w', when)); return li; }

// Kapak resmi sadece değişince yeniden atanır (büyük resmi her çizimde baştan çözmemek için).
let shownArt = null;
function setArt() {
  const want = hasMusic() && media.art ? media.art : '';
  if (want === shownArt) return;
  shownArt = want;
  const url = want ? cssUrl(want) : '';
  $('.art').style.backgroundImage = url; $('.art').classList.toggle('has-art', Boolean(url));
  $('.art-mini').style.backgroundImage = url;
}
function renderMusic() {
  const on = hasMusic();
  $('.mp-name').textContent = on ? (media.title || 'Bilinmeyen parça') : 'Çalan bir şey yok';
  $('.mp-artist').textContent = on ? (media.artist || media.album || '') : 'Spotify\'da ya da tarayıcıda müzik aç.';
  $('.mp-app-name').textContent = on ? media.app : 'Bu bilgisayar';
  setIcon($('.ctl.play .ico'), on && media.playing ? 'pause' : 'play');
  $('.ctl.prev').disabled = !on || !media.canPrev;
  $('.ctl.next').disabled = !on || !media.canNext;
  $('.ctl.play').disabled = !on;
}

function renderFocus() {
  const locked = fz.endAt != null || fz.left != null;
  const wheel = $('.wheel');
  wheel.classList.toggle('locked', locked);
  const show = (unit, v, max) => {
    const col = $(`.wcol[data-unit="${unit}"]`);
    col.querySelector('b').textContent = v;
    col.querySelector('.w-prev').textContent = v > 0 ? v - 1 : '';
    col.querySelector('.w-next').textContent = v < max ? v + 1 : '';
  };
  if (locked) {
    const left = Math.ceil(focusLeft() / 1000);
    $('.wcol[data-unit="h"] b').textContent = Math.floor(left / 3600);
    $('.wcol[data-unit="m"] b').textContent = `${pad2(Math.floor(left / 60) % 60)}:${pad2(left % 60)}`;
  } else { show('h', fz.h, 9); show('m', fz.m, 59); }
  $('.fz-start-txt').textContent = fz.endAt ? 'Duraklat' : fz.left != null ? 'Devam' : 'Başlat';
  setIcon($('.fz-start .ico'), fz.endAt ? 'pause' : 'play');
  // Odak koruması açıksa bugün kaç kez odağa dönüldüğü de yazar.
  const guarded = settings.focusGuard?.on && guardStats.back ? ` · bugün ${guardStats.back} kez korundun` : '';
  $('.fz-end').textContent = `Bitiş ${hhmm(new Date(Date.now() + focusLeft()))}${guarded}`;
  for (const c of $$('.chip[data-min]')) c.classList.toggle('on', !locked && fz.h === 0 && fz.m === Number(c.dataset.min));
}

function renderChrome() {
  const s = current(), ag = s ? AGENT[s.agent] : null;
  const [a, b] = page === 'ai' && ag ? ag.heading : page === 'chat' ? [`${settings.name || 'Nackles'} `, 'sohbet'] : HEADINGS[page];
  $('.h-a').textContent = a; $('.h-b').textContent = b;
  island.style.setProperty('--pc', page === 'ai' && ag ? ag.color : PAGE_COLOR[page]);
  $('.ai-ask .ask-input').placeholder = (ag || AGENT.claude).ask;
  const st = s?.state;
  const wash = page === 'ai' && (st === 'running' ? ag.running : WASH[st]);
  panel.classList.toggle('washed', Boolean(wash));
  panel.classList.toggle('live', st === 'running');
  if (wash) panel.style.setProperty('--wash', wash);
  setIcon($('.vol .ico'), settings.sound ? 'vol' : 'mute');
  $('.vol').classList.toggle('off', !settings.sound);
}

function tick() {
  const now = new Date(), s = current();
  // "Boştayken saati göster" kapalıysa kapalı adada saat yazmaz.
  $('.clock').textContent = settings.showClock ? hhmm(now) : '';
  const { days, months } = NacklesI18n.dates();
  $('.date').textContent = `${days[now.getDay()]} ${now.getDate()} ${months[now.getMonth()]} ${now.getFullYear()}`;
  $('.hm').textContent = hhmm(now);
  $('.layer-ai .time').textContent = s && s.startedAt ? duration((s.endedAt || Date.now()) - s.startedAt) : '';
  $('.focus-left').textContent = duration(focusLeft());
  if (s?.state === 'running') {
    const t = s.startedAt ? duration(Date.now() - s.startedAt) : '';
    $('.ai-big').textContent = t; $('.ai-num').textContent = t;
  }
  if (fz.endAt) { $('.focus-big').textContent = duration(focusLeft()); renderFocus(); }
  if (hasMusic()) {
    const pos = mediaPos();
    $('.bar-fill').style.width = media.duration > 0 ? `${(pos / media.duration) * 100}%` : '0%';
    $('.t-now').textContent = duration(pos * 1000);
    $('.t-end').textContent = media.duration > 0 ? duration(media.duration * 1000) : '0:00';
  } else { $('.bar-fill').style.width = '0%'; $('.t-now').textContent = '0:00'; $('.t-end').textContent = '0:00'; }
}

function renderMood() {
  const st = aiState();
  let mood = 'normal';
  if (tempMood && Date.now() < tempMoodUntil) mood = tempMood;
  else if (st === 'question') mood = 'wow';
  else if (st === 'done') mood = 'happy';
  else if (st === 'error') mood = 'sad';
  else if (isSleepy()) mood = 'sleepy';
  for (const c of [...mascot.classList]) if (c.startsWith('mood-')) mascot.classList.remove(c);
  mascot.classList.add('mood-' + mood);
  mascot.classList.toggle('look', st === 'running' && mood === 'normal');
  mascot.classList.toggle('dizzy', mood === 'dizzy');
  mascot.classList.toggle('groove', !st && hasMusic() && media.playing && mood === 'normal');
  mascotWrap.classList.toggle('sleeping', mood === 'sleepy');
}

// =========================================================
// AÇILMA VE SAYFALAR
// =========================================================
// Yazı yazılıyorsa ada açık kalır; ama pencere odağını kaybettiyse (başka yere tıklandıysa) artık yazılmıyor demektir.
function typing() { const a = document.activeElement; return geminiFocused || Boolean(document.hasFocus() && a && a !== document.body && panel.contains(a) && (a.matches('input') || a.isContentEditable)); }
let dragHold = false; // dosya sürüklenirken ada açık kalır
// Öndeki pencere ekranın üstünü kaplıyorsa (tam ekran tarayıcı gibi) ada içeri girer; bir iş bitince kısa süre görünür.
let cover = false, peekUntil = 0;
// hoverPeek: içerideki çizginin üstüne gelince önce sadece küçük ada görünür; büyük menü tıklayınca açılır.
let hoverPeek = false, peekTimer = null;
function isTucked() { return cover && !hoverPeek && Date.now() > peekUntil && !current()?.permission; }
function setHoverPeek(on) { if (hoverPeek === on) return; hoverPeek = on; render(); }
function peek(ms = 4500) { if (!cover) return; peekUntil = Date.now() + ms; render(); setTimeout(render, ms + 50); }
function wantExpanded() { return (pinned && !cover) || hovering || dragHold || Boolean(current()?.permission?.canAnswer) || typing(); }

function layout() {
  const want = wantExpanded();
  if (want === expanded) return;
  expanded = want;
  if (expanded) showPage(current()?.permission ? 'ai' : 'home', true);
  island.classList.toggle('expanded', expanded);
  api.setExpanded(expanded);
  syncGeminiWeb();
  if (!expanded) { menuOpen(false); if (panel.contains(document.activeElement)) document.activeElement.blur(); }
  hideTip();
}

function showPage(next, instant = false) {
  if (next === page) { renderChrome(); return; }
  const from = $(`.page[data-page="${page}"]`), to = $(`.page[data-page="${next}"]`);
  const dir = PAGES.indexOf(next) > PAGES.indexOf(page) ? 1 : -1;
  page = next;
  for (const b of $$('.dk[data-page]')) b.classList.toggle('on', b.dataset.page === next);
  if (instant) {
    from.classList.remove('on', 'leaving'); to.classList.add('on');
  } else {
    from.style.setProperty('--dir', dir); to.style.setProperty('--dir', dir);
    from.classList.add('leaving'); from.classList.remove('on');
    setTimeout(() => from.classList.remove('leaving'), 520);
    void to.offsetWidth; // başlangıç konumunu kaydettir, sonra kaydır
    to.classList.add('on');
  }
  if (next === 'notes') ensurePad();
  renderChrome();
  syncGeminiWeb();
}

$$('.dk[data-page]').forEach(b => b.addEventListener('click', () => showPage(b.dataset.page)));
$$('.card[data-go]').forEach(c => c.addEventListener('click', () => showPage(c.dataset.go)));

// ipucu balonu
const tip = $('.tip');
function hideTip() { tip.classList.remove('show'); }
$$('.dk').forEach(b => {
  b.addEventListener('mouseenter', () => {
    if (b.classList.contains('on')) return;
    tip.textContent = b.dataset.tip;
    const r = b.getBoundingClientRect(), d = $('.dock').getBoundingClientRect();
    tip.style.left = `${r.left - d.left + r.width / 2}px`;
    tip.classList.add('show');
  });
  b.addEventListener('mouseleave', hideTip);
  b.addEventListener('click', hideTip);
});

// ---------- fare: sadece adanın üstündeyken tıklanabilir ----------
let over = false;
document.addEventListener('mousemove', e => {
  const r = island.getBoundingClientRect();
  const inside = e.clientX >= r.left - 12 && e.clientX <= r.right + 12 && e.clientY <= r.bottom + 4;
  if (inside !== over) { over = inside; api.mouse(inside); }
  if (inside) {
    clearTimeout(leaveTimer); clearTimeout(peekTimer);
    if (cover && !expanded) {
      // Önde bir uygulama varken üstüne gelmek sadece küçük adayı çıkarır (yanlışlıkla açılmasın diye kısa bekleyerek).
      if (!hoverPeek && !hoverTimer) hoverTimer = setTimeout(() => { hoverTimer = null; setHoverPeek(true); }, 220);
    } else if (settings.expandOnHover && !hovering && !hoverTimer) hoverTimer = setTimeout(() => { hoverTimer = null; hovering = true; layout(); }, 200);
  } else {
    clearTimeout(hoverTimer); hoverTimer = null;
    if (hovering) { clearTimeout(leaveTimer); leaveTimer = setTimeout(() => { hovering = false; layout(); }, 450); }
    if (hoverPeek) { clearTimeout(peekTimer); peekTimer = setTimeout(() => setHoverPeek(false), 450); }
  }
});
document.addEventListener('mouseleave', () => {
  over = false; api.mouse(false); clearTimeout(hoverTimer); hoverTimer = null;
  // Yerel sayfadan Gemini görünümüne geçiş, adadan çıkış değildir; gerçek çıkışı ana süreç izler.
  if (island.classList.contains('gemini-web')) return;
  leaveTimer = setTimeout(() => { hovering = false; layout(); }, 450);
});
document.addEventListener('focusout', () => setTimeout(layout, 50));
window.addEventListener('blur', () => { if (typing()) document.activeElement.blur(); setTimeout(layout, 50); });
// Çubuğa tıklamak sadece açar (kalıcı olarak açık tutmak ••• menüsündeki "Açık tut" ile).
$('.bar').addEventListener('click', () => { clearTimeout(hoverTimer); hoverTimer = null; hovering = true; layout(); });
// Ana süreç imlecin adadan çıktığını haber verir: fare olayı gelmese bile ada küçülür.
api.onCursorIn(inside => {
  if (inside) { clearTimeout(leaveTimer); return; }
  clearTimeout(hoverTimer); hoverTimer = null;
  if (over) { over = false; api.mouse(false); }
  clearTimeout(leaveTimer);
  leaveTimer = setTimeout(() => { hovering = false; if (!document.hasFocus()) document.activeElement?.blur?.(); layout(); }, 450);
  clearTimeout(peekTimer); peekTimer = setTimeout(() => setHoverPeek(false), 450);
});

// =========================================================
// DÜĞMELER
// =========================================================
$('.allow').addEventListener('click', () => { const s = current(); if (s) api.decide(s.id, 'allow'); });
$('.deny').addEventListener('click', () => { const s = current(); if (s) api.decide(s.id, 'deny'); });
// ••• menüsü: adanın içinde küçük bir liste açar
const menu = $('.menu');
function menuOpen(open) {
  menu.classList.toggle('open', open);
  $('.more').classList.toggle('active', open);
  syncGeminiWeb();
  if (open) {
    menu.querySelector('[data-act="pin"]').classList.toggle('on', pinned);
    menu.querySelector('[data-act="pin"] .mi-txt').textContent = pinned ? 'Açık tutmayı bırak' : 'Açık tut';
    menu.querySelector('[data-act="sound"] .mi-txt').textContent = settings.sound ? 'Sesi kapat' : 'Sesi aç';
    setIcon(menu.querySelector('[data-act="sound"] .ico'), settings.sound ? 'vol' : 'mute');
  }
}
$('.more').addEventListener('click', e => { e.stopPropagation(); menuOpen(!menu.classList.contains('open')); });
document.addEventListener('mousedown', e => { if (menu.classList.contains('open') && !menu.contains(e.target) && !e.target.closest('.more')) menuOpen(false); });
menu.addEventListener('click', e => {
  const act = e.target.closest('.mi-item')?.dataset.act; if (!act) return;
  menuOpen(false);
  if (act === 'pin') { pinned = !pinned; layout(); }
  if (act === 'sound') api.setSound(!settings.sound);
  if (act === 'settings') api.openSettings();
  if (act === 'hide') { pinned = false; hovering = false; layout(); api.hideIsland(); }
  if (act === 'quit') api.quit();
});
$('.vol').addEventListener('click', () => api.setSound(!settings.sound));

function mediaCmd(cmd) {
  if (!hasMusic()) return;
  api.mediaCommand(cmd);
  // Anında tepki: oynatıcıdan cevap gelmeden simgeyi çevir.
  if (cmd === 'toggle') { media = { ...media, position: mediaPos(), updated: Date.now(), playing: !media.playing }; render(); }
}
$$('.ctl').forEach(b => b.addEventListener('click', () => mediaCmd(b.dataset.cmd)));
$('.music-ico').addEventListener('click', e => { e.stopPropagation(); if (hasMusic()) mediaCmd('toggle'); else showPage('music'); });

$('.focus-ico').addEventListener('click', e => { e.stopPropagation(); focusStartPause(); });
$('.fz-start').addEventListener('click', focusStartPause);
$('.fz-reset').addEventListener('click', focusReset);
$$('.chip[data-min]').forEach(c => c.addEventListener('click', () => { fz.endAt = null; fz.left = null; fz.h = 0; fz.m = Number(c.dataset.min); render(); }));
$$('.wcol').forEach(col => col.addEventListener('wheel', e => {
  e.preventDefault();
  if (fz.endAt != null || fz.left != null) return;
  const step = e.deltaY > 0 ? 1 : -1;
  if (col.dataset.unit === 'h') fz.h = Math.min(9, Math.max(0, fz.h + step));
  else fz.m = Math.min(59, Math.max(0, fz.m + step * (e.shiftKey ? 5 : 1)));
  if (fz.h === 0 && fz.m === 0) fz.m = 1;
  col.classList.remove('bump'); void col.offsetWidth; col.classList.add('bump');
  render();
}, { passive: false }));

// =========================================================
// NOT DEFTERİ: her satır ayrı; "[ ] " ile başlayan satır işaret yuvarlağı olur
// =========================================================
const padEl = $('.pad');
let padLoaded = false, saveTimer = null;

function lineEl(l) {
  const d = el('div', 'line'); d.dataset.id = l.id || crypto.randomUUID();
  const t = el('div', 'ltext', l.text);
  t.contentEditable = 'plaintext-only';
  d.append(t);
  if (l.task) makeTask(d, l.done);
  return d;
}
function makeTask(line, done = false) {
  if (!line.querySelector('.tick')) {
    const b = el('button', 'tick'); b.tabIndex = -1; b.setAttribute('aria-label', 'Bitti olarak işaretle');
    b.addEventListener('mousedown', e => e.preventDefault());
    b.addEventListener('click', () => { line.classList.toggle('done'); save(); });
    line.prepend(b);
  }
  line.classList.toggle('done', done);
}
function makeText(line) { line.querySelector('.tick')?.remove(); line.classList.remove('done'); }
const isTask = line => Boolean(line.querySelector('.tick'));
const textOf = line => line.querySelector('.ltext');

function caret(node) {
  const sel = getSelection();
  if (!sel.rangeCount || !node.contains(sel.anchorNode)) return 0;
  const r = sel.getRangeAt(0).cloneRange(); r.selectNodeContents(node); r.setEnd(sel.anchorNode, sel.anchorOffset);
  return r.toString().length;
}
function placeCaret(node, pos) {
  node.focus();
  const r = document.createRange(), t = node.firstChild;
  if (t && t.nodeType === 3) r.setStart(t, Math.min(pos, t.length)); else r.setStart(node, 0);
  r.collapse(true);
  const sel = getSelection(); sel.removeAllRanges(); sel.addRange(r);
}
function serialize() {
  return [...padEl.children].map(line => ({ id: line.dataset.id, text: textOf(line).textContent, task: isTask(line), done: line.classList.contains('done') }));
}
function save() {
  updateEmpty();
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => api.notes.set(serialize()), 350);
}
function updateEmpty() {
  const empty = !padEl.children.length || ([...padEl.children].every(l => !textOf(l).textContent && !isTask(l)) && !typing());
  $('.page[data-page="notes"]').classList.toggle('empty-pad', empty);
}
function ensurePad() { if (!padEl.children.length) padEl.append(lineEl({ text: '' })); }

padEl.addEventListener('mousedown', e => {
  if (e.target !== padEl) return;
  e.preventDefault();
  ensurePad();
  const last = padEl.lastElementChild;
  placeCaret(textOf(last), textOf(last).textContent.length);
  updateEmpty();
});
padEl.addEventListener('focusin', updateEmpty);
padEl.addEventListener('focusout', () => setTimeout(updateEmpty, 0));
padEl.addEventListener('input', e => {
  const t = e.target.closest('.ltext'); if (!t) return;
  const line = t.parentElement;
  const m = /^\[( |x|X)?\]\s/.exec(t.textContent);
  if (m) { t.textContent = t.textContent.slice(m[0].length); makeTask(line, /x/i.test(m[1] || '')); placeCaret(t, 0); }
  save();
});
padEl.addEventListener('keydown', e => {
  const t = e.target.closest('.ltext'); if (!t) return;
  const line = t.parentElement, pos = caret(t), text = t.textContent;
  if (e.key === 'Enter') {
    e.preventDefault();
    if (isTask(line) && !text) { makeText(line); save(); return; } // boş yapılacak: sıradan satıra dön
    t.textContent = text.slice(0, pos);
    const next = lineEl({ text: text.slice(pos), task: isTask(line) });
    line.after(next); placeCaret(textOf(next), 0); save();
  } else if (e.key === 'Backspace' && pos === 0 && !getSelection().toString()) {
    if (isTask(line)) { e.preventDefault(); makeText(line); save(); return; }
    const prev = line.previousElementSibling; if (!prev) return;
    e.preventDefault();
    const pt = textOf(prev), at = pt.textContent.length;
    pt.textContent += text; line.remove(); placeCaret(pt, at); save();
  } else if (e.key === 'ArrowUp' && line.previousElementSibling) {
    e.preventDefault(); placeCaret(textOf(line.previousElementSibling), pos);
  } else if (e.key === 'ArrowDown' && line.nextElementSibling) {
    e.preventDefault(); placeCaret(textOf(line.nextElementSibling), pos);
  } else if (e.key === 'Escape') { t.blur(); }
});
// Yapıştırılan çok satırlı metin ayrı satırlara bölünür.
padEl.addEventListener('paste', e => {
  const t = e.target.closest('.ltext'); if (!t) return;
  const parts = e.clipboardData.getData('text/plain').replace(/\r/g, '').split('\n');
  if (parts.length < 2) return;
  e.preventDefault();
  const line = t.parentElement, pos = caret(t), text = t.textContent;
  t.textContent = text.slice(0, pos) + parts[0];
  let after = line;
  for (const p of parts.slice(1)) { const n = lineEl({ text: p }); after.after(n); after = n; }
  const lt = textOf(after); const end = lt.textContent.length; lt.textContent += text.slice(pos); placeCaret(lt, end);
  save();
});

// Ana süreç, adanın nerede olduğunu bilmeli (sürüklenen dosyalar adaya ulaşabilsin diye).
new ResizeObserver(() => { const r = island.getBoundingClientRect(); api.islandRect({ x: r.left, y: r.top, w: r.width, h: r.height, tucked: island.classList.contains('tucked') && !expanded }); }).observe(island);

// =========================================================
// DOSYA TEPSİSİ
// =========================================================
const trayPage = $('.page[data-page="tray"]'), filesEl = $('.files');
const fmtSize = b => b >= 1e9 ? (b / 1e9).toFixed(1) + ' GB' : b >= 1e6 ? (b / 1e6).toFixed(1) + ' MB' : b >= 1e3 ? Math.round(b / 1e3) + ' KB' : b + ' B';
let shelfFiles = [];
const selected = []; // seçim sırası (birleştirmede bu sıra kullanılır)
function isSel(id) { return selected.includes(id); }
function toggleSel(id) {
  const i = selected.indexOf(id);
  if (i >= 0) selected.splice(i, 1); else selected.push(id);
  syncSelection();
}
function clearSel() { selected.length = 0; syncSelection(); }
function syncSelection() {
  for (let i = selected.length - 1; i >= 0; i--) if (!shelfFiles.some(f => f.id === selected[i])) selected.splice(i, 1);
  for (const tile of filesEl.children) {
    const n = selected.indexOf(tile.dataset.id);
    tile.classList.toggle('picked', n >= 0);
    tile.querySelector('.sel').textContent = n >= 0 && selected.length > 1 ? String(n + 1) : '';
  }
  trayPage.classList.toggle('selecting', selected.length > 0);
  $('.tb-count').textContent = `${selected.length} seçili`;
  const files = selected.map(id => shelfFiles.find(f => f.id === id)).filter(Boolean);
  $('.tb-btn[data-tb="merge"]').disabled = files.length < 2;
  $('.tb-btn[data-tb="convert"]').disabled = !files.length || files.some(f => f.dir);
  resetTrashButton();
}

function renderShelf(list) {
  shelfFiles = list;
  trayPage.classList.toggle('has-files', list.length > 0);
  const known = new Map([...filesEl.children].map(n => [n.dataset.id, n]));
  filesEl.replaceChildren(...list.map(f => {
    let tile = known.get(f.id);
    if (!tile) {
      tile = el('div', 'file'); tile.dataset.id = f.id; tile.draggable = true; tile.title = f.path;
      const img = document.createElement('img'); img.alt = ''; if (f.icon) img.src = f.icon;
      const x = el('button', 'x', '×'); x.setAttribute('aria-label', 'Tepsiden çıkar'); x.title = 'Tepsiden çıkar (dosya silinmez)';
      x.addEventListener('click', async e => { e.stopPropagation(); renderShelf(await api.shelf.remove(f.id)); syncSelection(); });
      const sel = el('button', 'sel'); sel.setAttribute('aria-label', 'Seç');
      sel.addEventListener('click', e => { e.stopPropagation(); toggleSel(f.id); });
      tile.append(sel, x, img, el('span', 'fn', f.name), el('span', 'fs', f.dir ? 'Klasör' : fmtSize(f.size)));
      if (!f.dir) {
        const cv = el('button', 'cv'), ci = el('span', 'ico'); setIcon(ci, 'swap');
        cv.append(ci, 'Dönüştür'); cv.title = 'Filee ile başka biçime dönüştür';
        cv.addEventListener('click', e => { e.stopPropagation(); openConvert([f]); });
        tile.append(cv);
      }
      // Seçim varken ya da Ctrl basılıyken tıklamak seçer; değilse dosyayı açar.
      tile.addEventListener('click', e => { if (e.ctrlKey || e.shiftKey || selected.length) toggleSel(f.id); else api.shelf.open(f.id); });
      tile.addEventListener('contextmenu', e => { e.preventDefault(); api.shelf.reveal(f.id); });
      tile.addEventListener('dragstart', e => { e.preventDefault(); api.shelf.drag(f.id); });
    }
    return tile;
  }));
  syncSelection();
}

// Seçim çubuğu
let trashArmed = null;
function resetTrashButton() {
  clearTimeout(trashArmed); trashArmed = null;
  const b = $('.tb-btn[data-tb="trash"]'); b.classList.remove('armed'); b.lastChild.textContent = 'Sil';
}
$('.tray-bar').addEventListener('click', async e => {
  const act = e.target.closest('[data-tb]')?.dataset.tb; if (!act) return;
  const ids = [...selected];
  const files = ids.map(id => shelfFiles.find(f => f.id === id)).filter(Boolean);
  if (act === 'clear') clearSel();
  if (act === 'convert' && files.length) openConvert(files);
  if (act === 'merge' && files.length > 1) openMerge(files);
  if (act === 'remove') { renderShelf(await api.shelf.removeMany(ids)); clearSel(); }
  if (act === 'trash') {
    const b = e.target.closest('[data-tb]');
    if (!trashArmed) { // ilk tıklama onay ister
      b.classList.add('armed'); b.lastChild.textContent = `${files.length} dosyayı çöpe at?`;
      trashArmed = setTimeout(resetTrashButton, 3500);
      return;
    }
    resetTrashButton();
    const r = await api.shelf.trash(ids);
    renderShelf(r.files); clearSel();
    if (r.failed.length) showTrayNote(`${r.failed.length} dosya çöpe atılamadı (açık olabilir).`, true);
    else showTrayNote(`${files.length} dosya Geri Dönüşüm Kutusu'na taşındı.`);
  }
});
$('.tray-all').addEventListener('click', e => { e.stopPropagation(); selected.length = 0; selected.push(...shelfFiles.map(f => f.id)); syncSelection(); });
$('.tray-empty').addEventListener('click', async e => { e.stopPropagation(); renderShelf(await api.shelf.clear()); clearSel(); showTrayNote('Tepsi boşaltıldı. Dosyaların yerinde duruyor.'); });
let noteTimer = null;
function showTrayNote(text, err = false) {
  const n = $('.tray-note'); n.textContent = text; n.classList.toggle('err', err); n.classList.add('show');
  clearTimeout(noteTimer); noteTimer = setTimeout(() => n.classList.remove('show'), 3500);
}

let dragDepth = 0, dragTimer = null;
const fileDrag = e => [...(e.dataTransfer?.types || [])].includes('Files');
document.addEventListener('dragenter', e => {
  if (!fileDrag(e)) return;
  dragDepth++;
  clearTimeout(dragTimer);
  island.classList.add('dragging');
  if (!dragHold) { dragHold = true; layout(); showPage('tray'); }
});
document.addEventListener('dragover', e => { if (fileDrag(e)) { e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; } });
document.addEventListener('dragleave', () => {
  if (--dragDepth > 0) return;
  dragDepth = 0; island.classList.remove('dragging');
  dragTimer = setTimeout(() => { dragHold = false; layout(); }, 600);
});
document.addEventListener('drop', async e => {
  if (!fileDrag(e)) return;
  e.preventDefault();
  dragDepth = 0; island.classList.remove('dragging');
  // FileList köprüden geçemez; tek tek File nesneleri olarak gönderilir.
  renderShelf(await api.shelf.add(Array.from(e.dataTransfer.files)));
  flash(island, 'pop', 720);
  dragTimer = setTimeout(() => { dragHold = false; layout(); }, 1500);
});
api.shelf.list().then(renderShelf);

// ---------- Filee: dönüştürme ve birleştirme ----------
const conv = { files: null, busy: false };
function closeConvert() { if (conv.busy) return; conv.files = null; trayPage.classList.remove('converting'); }
function convHeader(files, by) {
  $('.conv-name').textContent = files.length === 1 ? files[0].name : `${files.length} dosya`;
  $('.conv-by').textContent = by;
  const list = $('.conv-list'), status = $('.conv-status');
  list.replaceChildren(); status.textContent = ''; status.className = 'conv-status';
  trayPage.classList.add('converting');
  return { list, status };
}
async function openConvert(files) {
  conv.files = files;
  const { list, status } = convHeader(files, 'Filee ile dönüştür');
  status.textContent = 'Biçimler yükleniyor…';
  // Birden çok dosyada sadece hepsinin dönüşebildiği biçimler gösterilir.
  const all = await Promise.all(files.map(f => api.filee.targets(f.id)));
  if (conv.files !== files) return;
  if (all.some(t => !t)) { status.textContent = 'Filee bulunamadı.'; status.className = 'conv-status err'; return; }
  const ready = all.map(t => t.ready).reduce((a, b) => a.filter(x => b.includes(x)));
  const optional = all.map(t => t.optional).reduce((a, b) => a.filter(x => b.includes(x)));
  if (!ready.length && !optional.length) { status.textContent = files.length > 1 ? 'Bu dosyaların ortak dönüşebildiği bir biçim yok.' : 'Filee bu dosya türünü tanımıyor.'; status.className = 'conv-status err'; return; }
  status.textContent = '';
  // lang="en": Türkçe büyük harf kuralı "gif"i "GİF" yapmasın
  const chip = (fmt, i) => { const b = el('button', 'fmt', fmt); b.lang = 'en'; b.style.animationDelay = `${Math.min(i, 20) * 12}ms`; b.addEventListener('click', () => runFilee(files, { to: fmt }, `${fmt.toUpperCase()} biçimine dönüştürülüyor…`)); return b; };
  const first = ready.slice(0, 14), rest = ready.slice(14);
  list.append(...first.map(chip));
  if (rest.length) {
    const more = el('button', 'fmt more', `+${rest.length} biçim daha`);
    more.addEventListener('click', () => { more.replaceWith(...rest.map((x, i) => chip(x, i))); });
    list.append(more);
  }
  if (optional.length) list.append(el('span', 'sep', `Ek motor isteyenler (Filee → Ayarlar → Motorlar): ${optional.slice(0, 12).join(', ')}${optional.length > 12 ? '…' : ''}`));
}
async function openMerge(files) {
  conv.files = files;
  const { list, status } = convHeader(files, 'Filee ile birleştir · seçim sırasıyla');
  const opts = await api.filee.mergeOptions(files.map(f => f.id));
  if (conv.files !== files) return;
  list.append(...opts.map((o, i) => {
    const b = el('button', 'fmt wide', o.label); b.style.animationDelay = `${i * 30}ms`;
    b.addEventListener('click', () => runFilee(files, { preset: o.preset }, `${o.label}…`));
    return b;
  }));
  if (opts.length === 1) status.textContent = 'Farklı türdeki dosyalar sadece tek ZIP olarak birleştirilebilir.';
}
async function runFilee(files, job, text) {
  if (conv.busy) return;
  conv.busy = true;
  const status = $('.conv-status');
  showTrayNote(text);
  for (const f of files) filesEl.querySelector(`.file[data-id="${f.id}"]`)?.classList.add('busy');
  trayPage.classList.remove('converting');
  const r = await api.filee.run(files.map(f => f.id), job);
  conv.busy = false; conv.files = null;
  const before = new Set([...filesEl.children].map(n => n.dataset.id));
  renderShelf(r.files || []);
  for (const n of filesEl.children) n.classList.remove('busy');
  if (r.ok) {
    clearSel();
    for (const n of filesEl.children) if (!before.has(n.dataset.id)) n.classList.add('fresh');
    filesEl.scrollLeft = 0;
    showTrayNote(r.partial ? `Bazıları olmadı: ${r.error}` : 'Bitti. Sonuç asıl dosyanın yanına kaydedildi.', r.partial);
    celebrate('done');
  } else {
    trayPage.classList.add('converting');
    $('.conv-list').replaceChildren();
    status.textContent = r.error || 'Olmadı.'; status.className = 'conv-status err';
  }
}
$('.conv-close').addEventListener('click', closeConvert);
api.filee.available().then(ok => island.classList.toggle('has-filee', ok));

// =========================================================
// PANO GEÇMİŞİ
// =========================================================
const clipsPage = $('.page[data-page="clips"]'), clipList = $('.clip-list');
let clipItems = [];
function ago(t) { const m = Math.floor((Date.now() - t) / 60000); return m < 1 ? 'şimdi' : m < 60 ? `${m} dk` : `${Math.floor(m / 60)} sa`; }
function renderClips(list = clipItems) {
  clipItems = list;
  clipsPage.classList.toggle('no-clips', list.length === 0);
  clipList.replaceChildren(...list.map(c => {
    const li = el('li', 'clip'); li.title = c.kind === 'text' ? c.text.slice(0, 300) : `Resim ${c.size}`;
    if (c.kind === 'image') { const img = document.createElement('img'); img.className = 'thumb'; img.src = c.thumb; img.alt = ''; li.append(img, el('span', 'ct', `Resim · ${c.size}`)); }
    else {
      const ci = el('span', 'ci'), ico = el('span', 'ico'); ci.append(ico);
      setIcon(ico, /^https?:\/\/\S+$/.test(c.text.trim()) ? 'link' : 'text');
      const ct = el('span', 'ct', c.text.replace(/\s+/g, ' ').trim()); ct.translate = false;
      li.append(ci, ct);
    }
    const x = el('button', 'x', '×'); x.setAttribute('aria-label', 'Geçmişten sil');
    x.addEventListener('click', e => { e.stopPropagation(); api.clips.remove(c.id); });
    li.append(el('span', 'cw', ago(c.at)), x);
    li.addEventListener('click', async () => { if (!await api.clips.copy(c.id)) return; setTimeout(() => { const first = clipList.firstElementChild; if (first) { first.classList.add('copied'); setTimeout(() => first.classList.remove('copied'), 1300); } }, 60); });
    return li;
  }));
}
$('.clip-clear').addEventListener('click', () => api.clips.clear());
api.clips.onChange(renderClips);
api.clips.list().then(renderClips);
setInterval(() => { if (page === 'clips' && expanded) renderClips(); }, 30000);

// =========================================================
// SOHBET: Claude ya da Codex'e soru sor (bilgisayardaki komut satırı araçlarıyla)
// =========================================================
const chatPage = $('.page[data-page="chat"]'), msgsEl = $('.msgs');
const chat = { agent: 'claude', busy: null, bubble: null, available: { claude: true, codex: true, chatgpt: true, gemini: true } };
const ASK_TO = { claude: "Claude'a sor…", codex: "Codex'e sor…", chatgpt: "ChatGPT'ye sor…", gemini: "Gemini'ye sor…" };
const QUICK = {
  explain: t => `Şunu kısaca ve anlaşılır biçimde Türkçe açıkla:\n\n${t}`,
  spell: t => `Şu metnin yazım ve noktalama hatalarını düzelt. Sadece düzeltilmiş metni ver:\n\n${t}`,
  translate: t => `Şu metni çevir: Türkçeyse İngilizceye, değilse Türkçeye. Sadece çeviriyi ver:\n\n${t}`,
  summary: t => `Şu metni birkaç maddeyle Türkçe özetle:\n\n${t}`,
};
const QUICK_EN = {
  explain: t => `Explain this briefly and clearly:\n\n${t}`,
  spell: t => `Fix the spelling and punctuation in this text. Reply with the corrected text only:\n\n${t}`,
  translate: t => `Translate this text: if it is English, into Turkish; otherwise into English. Reply with the translation only:\n\n${t}`,
  summary: t => `Summarize this text in a few bullet points:\n\n${t}`,
};

function setChatAgent(agent) {
  chat.agent = agent;
  chatPage.dataset.agent = agent;
  for (const b of $$('.who-btn')) {
    b.classList.toggle('on', b.dataset.agent === agent);
    if (b.dataset.agent === agent) { // seçili sekme görünür alana kaysın (sadece sekme satırı kayar)
      const w = b.parentElement, r = b.getBoundingClientRect(), wr = w.getBoundingClientRect();
      if (r.left < wr.left || r.right > wr.right) w.scrollLeft += r.left - wr.left - (wr.width - r.width) / 2;
    }
  }
  $('.chat-ask .ask-input').placeholder = ASK_TO[agent];
  syncGeminiWeb();
}
// Native görünüm yalnızca Gemini seçiliyken ve ada açıkken görünür. Animasyon bitince yerleşir.
const geminiHost = $('.gemini-host');
let geminiLayoutTimer = null, geminiReadyAt = 0;
function geminiActive() { return expanded && page === 'chat' && chat.agent === 'gemini'; }
function reportGeminiBounds() {
  if (!geminiActive() || Date.now() < geminiReadyAt || $('.menu').classList.contains('open')) return;
  const r = geminiHost.getBoundingClientRect();
  api.chat.webLayout({ active: true, bounds: { x: r.x, y: r.y, width: r.width, height: r.height } });
}
function syncGeminiWeb() {
  const active = geminiActive();
  island.classList.toggle('gemini-web', active);
  clearTimeout(geminiLayoutTimer);
  geminiReadyAt = Date.now() + 700;
  api.chat.webLayout({ active, bounds: null });
  if (!active) geminiFocused = false;
  else geminiLayoutTimer = setTimeout(reportGeminiBounds, 720);
}
new ResizeObserver(reportGeminiBounds).observe(geminiHost);
window.addEventListener('resize', reportGeminiBounds);
api.chat.onWebState(state => {
  $('.gemini-status-text').textContent = state.status === 'error' ? state.text : 'Gemini açılıyor…';
  $('.gemini-retry').hidden = state.status !== 'error';
  $('.gemini-origin').textContent = state.origin;
});
api.chat.onWebFocus(focused => { geminiFocused = focused && geminiActive(); layout(); });
$('.gemini-back').addEventListener('click', () => api.chat.webAction('back'));
$('.gemini-reload').addEventListener('click', () => api.chat.webAction('reload'));
$('.gemini-retry').addEventListener('click', () => api.chat.webAction('reload'));
function syncAskButtons() {
  for (const f of $$('.ask')) {
    const busy = Boolean(chat.busy) && f.classList.contains('chat-ask');
    f.classList.toggle('busy', busy);
    f.classList.toggle('empty', !f.querySelector('.ask-input').value.trim());
    setIcon(f.querySelector('.ask-send .ico'), busy ? 'stop' : 'up');
  }
}
function addMsg(kind, text, agent) {
  const m = el('div', `m ${kind}${agent ? ' ' + agent : ''}`, text);
  msgsEl.append(m);
  chatPage.classList.add('has-msgs');
  msgsEl.scrollTop = msgsEl.scrollHeight;
  return m;
}
function ask(text, agent = chat.agent) {
  text = String(text || '').trim();
  if (agent === 'gemini') return;
  if (!text || chat.busy) return;
  if (agent !== chat.agent) setChatAgent(agent);
  addMsg('user', text);
  const bubble = addMsg('bot', '', agent);
  const dots = el('span', 'typing'); dots.append(el('i'), el('i'), el('i')); bubble.append(dots);
  const id = String(Date.now());
  chat.busy = id; chat.bubble = bubble;
  api.chat.send(id, agent, text);
  syncAskButtons();
}
api.chat.onEvent(e => {
  if (e.id !== chat.busy || !chat.bubble) return;
  const b = chat.bubble;
  if (e.type === 'delta') { b.querySelector('.typing')?.remove(); b.append(document.createTextNode(e.text)); }
  if (e.type === 'error') { b.querySelector('.typing')?.remove(); b.classList.add('err'); b.textContent = e.text; }
  if (e.type === 'done' || e.type === 'error') {
    b.querySelector('.typing')?.remove();
    if (!b.textContent) b.textContent = e.stopped ? 'Durduruldu.' : '…';
    chat.busy = null; chat.bubble = null; syncAskButtons();
  }
  msgsEl.scrollTop = msgsEl.scrollHeight;
});

for (const f of $$('.ask')) {
  const input = f.querySelector('.ask-input');
  input.addEventListener('input', syncAskButtons);
  input.addEventListener('keydown', e => { if (e.key === 'Escape') input.blur(); });
  f.addEventListener('submit', e => {
    e.preventDefault();
    if (f.classList.contains('chat-ask') && chat.busy) { api.chat.stop(chat.busy); return; }
    const text = input.value.trim(); if (!text) return;
    input.value = '';
    // Yapay zekâ sayfasından yazılınca soru, çalışan ajana sohbet sayfasında sorulur.
    if (f.classList.contains('ai-ask')) { showPage('chat'); ask(text, current()?.agent || 'claude'); }
    else ask(text);
    syncAskButtons();
  });
}
$$('.who-btn').forEach(b => b.addEventListener('click', () => { if (!chat.busy) setChatAgent(b.dataset.agent); }));
$('.chat-new').addEventListener('click', () => {
  if (chat.busy) api.chat.stop(chat.busy);
  for (const a of Object.keys(ASK_TO)) api.chat.reset(a);
  if (chat.agent === 'gemini') api.chat.webAction('new');
  msgsEl.replaceChildren(); chatPage.classList.remove('has-msgs');
});
// Sekmeler yana kayar: dikey tekerlek hareketi yatay kaydırsın
$('.who').addEventListener('wheel', e => { if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) { e.currentTarget.scrollLeft += e.deltaY; e.preventDefault(); } }, { passive: false });
// Seçili sohbetin kendi uygulamasını (yoksa sitesini) aç
$('.chat-app').addEventListener('click', () => api.chat.openApp(chat.agent));
$$('.qa').forEach(b => b.addEventListener('click', async () => {
  const clip = (await api.chat.clipboard()).trim();
  if (!clip) { addMsg('bot err', 'Önce açıklanacak / çevrilecek metni kopyala.', chat.agent); return; }
  ask((NacklesI18n.lang === 'en' ? QUICK_EN : QUICK)[b.dataset.qa](clip));
}));
api.chat.available().then(a => {
  chat.available = a;
  for (const b of $$('.who-btn')) b.classList.toggle('missing', !a[b.dataset.agent]);
  if (!a.claude && a.codex) setChatAgent('codex');
});
setChatAgent('claude');
syncAskButtons();

// =========================================================
// MASKOT VE SESLER
// =========================================================
function blink() {
  island.classList.add('blink'); mascot.classList.add('blink');
  setTimeout(() => { island.classList.remove('blink'); mascot.classList.remove('blink'); }, 130);
  setTimeout(blink, 2200 + Math.random() * 4200);
}
setTimeout(blink, 1500);
function flash(target, cls, ms) { target.classList.remove(cls); void target.getBoundingClientRect(); target.classList.add(cls); setTimeout(() => target.classList.remove(cls), ms); }
function setTempMood(mood, ms) { tempMood = mood; tempMoodUntil = Date.now() + ms; renderMood(); setTimeout(renderMood, ms + 20); }

let pokes = [];
mascotWrap.addEventListener('click', e => {
  e.stopPropagation();
  lastActivity = Date.now();
  pokes = pokes.filter(t => Date.now() - t < 2500).concat(Date.now());
  if (pokes.length >= 5) { pokes = []; setTempMood('dizzy', 3000); }
  else { flash(mascot, 'squish', 320); if (Math.random() < .4) setTempMood('happy', 900); }
});

// Ses sistemi sadece çalarken açık: kapanınca Chromium'un ses süreci de bellekten çıkar.
let audio = null, audioTimer = null;
function chime(kind) {
  if (!settings.sound || settings.volume <= 0) return;
  try {
    audio ||= new AudioContext();
    clearTimeout(audioTimer);
    audioTimer = setTimeout(() => { audio?.close(); audio = null; }, 2500);
    const tones = kind === 'error' ? [523.25, 392] : kind === 'question' ? [659.25, 659.25] : [880, 1318.5];
    tones.forEach((f, i) => {
      const o = audio.createOscillator(), g = audio.createGain(), t = audio.currentTime + i * 0.13;
      o.type = 'sine'; o.frequency.value = f;
      g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(0.3 * settings.volume, t + 0.015); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.55);
      o.connect(g).connect(audio.destination); o.start(t); o.stop(t + 0.6);
    });
  } catch {}
}
function celebrate(state) {
  chime(state);
  flash(island, 'pop', 720);
  if (state === 'done') { mascot.classList.add('dance'); setTimeout(() => mascot.classList.remove('dance'), 4200); }
  else if (state === 'error') flash(mascot, 'shake', 950);
  else setTempMood('wow', 2500);
}

function sendIcon() {
  const clone = mascot.cloneNode(true);
  clone.querySelectorAll('[class^="eyes-"]:not(.eyes-normal)').forEach(n => n.remove());
  clone.setAttribute('width', '256'); clone.setAttribute('height', '256');
  const img = new Image();
  img.onload = () => { const c = document.createElement('canvas'); c.width = c.height = 256; c.getContext('2d').drawImage(img, 0, 0, 256, 256); api.icon(c.toDataURL('image/png')); };
  img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(new XMLSerializer().serializeToString(clone));
}

// ---------- pil ----------
navigator.getBattery?.().then(b => {
  const show = () => {
    const lvl = Math.round(b.level * 100);
    $('.batt-pct').textContent = `${lvl}%`;
    $('.batt').style.setProperty('--lvl', `${lvl}%`);
    $('.battery').classList.toggle('low', lvl <= 20 && !b.charging);
  };
  show(); b.addEventListener('levelchange', show); b.addEventListener('chargingchange', show);
}).catch(() => $('.battery').classList.add('none'));

// =========================================================
// ANA SÜREÇTEN GELENLER
// =========================================================
let lastQuestion = '';
api.onState(v => {
  if (v.sessions.some(s => s.state !== 'ready')) lastActivity = Date.now();
  const q = v.sessions.find(s => s.permission);
  const key = q ? q.id + q.permission.text : '';
  if (key && key !== lastQuestion) { peek(); celebrate('question'); }
  lastQuestion = key;
  view = v; render(); layout();
});
api.onFinished(({ state }) => { peek(); celebrate(state); });
api.onCover(v => {
  cover = v;
  if (v && !typing() && !dragHold) { pinned = false; }
  render(); layout();
});
api.onPreview(kind => {
  const now = Date.now();
  preview = { until: now + 4500, s: { id: 'preview', agent: 'claude', agentName: 'Claude Code', project: 'Deneme', state: kind, title: 'Ses ve görünüm denemesi', detail: kind === 'error' ? 'Bir hata oluştu' : kind === 'question' ? 'İzin istiyor' : 'Bitti', startedAt: now - 12000, endedAt: kind === 'question' ? 0 : now, steps: [], permission: kind === 'question' ? { text: 'Çalıştırıyor · npm test', canAnswer: false } : null, at: now } };
  peek(4500); render(); celebrate(kind);
  setTimeout(() => { preview = null; render(); }, 4600);
});
api.onTogglePin(() => { pinned = !pinned; layout(); });
api.onMedia(m => {
  const was = media.playing;
  media = m;
  if (m.playing) lastActivity = Date.now();
  if (m.playing && !was && !aiState()) flash(island, 'pop', 720);
  render();
});
// Seçilen maskot ve palet: maskot sadece değişince yeniden çizilir; adanın "hazır" rengi paletin göz rengini alır.
let mascotKey = '';
async function applyMascot(s) {
  const custom = s.mascotKind.startsWith('custom:') ? { image: await api.mascotImage(s.mascotKind.slice(7)) } : null;
  const key = `${s.mascotKind}|${s.palette}|${custom ? custom.image.length : ''}`;
  if (key !== mascotKey) {
    mascotKey = key;
    mascot = NacklesMascot.mount(mascotWrap, { kind: s.mascotKind, palette: s.palette, custom });
    sendIcon();
  }
  NacklesMascot.paint(mascot, s.mascot);
  const c = NacklesMascot.colorsFor(custom ? 'glitch' : s.mascotKind, s.palette);
  document.documentElement.style.setProperty('--ready', c.eye);
  document.documentElement.style.setProperty('--mascot-accent', c.accent);
  renderMood();
}
api.onSettings(s => {
  settings = s;
  NacklesI18n.setLang(s.uiLang);
  for (const [k, v] of Object.entries(s.colors)) document.documentElement.style.setProperty('--' + k, v);
  // Kullanıcının verdiği ad her yerde görünür.
  mascotWrap.title = s.name;
  $('.chat-hello').textContent = `Ben ${s.name}. Sana nasıl yardım edebilirim?`;
  document.title = s.name;
  applyMascot(s);
  render();
});

api.notes.list().then(list => {
  if (padLoaded) return;
  padLoaded = true;
  padEl.replaceChildren(...list.map(lineEl));
  updateEmpty();
});

let lastMode = '';
setInterval(() => {
  focusTick();
  const mode = barMode() + isSleepy() + isTucked();
  if (mode !== lastMode) { lastMode = mode; render(); } else { tick(); renderMood(); }
}, 1000);
render();
