// Pano geçmişi yalnızca bellekte tutulur. Electron 45'in asenkron ClipboardItem API'si.
const crypto = require('node:crypto');

const MAX_ITEMS = 30, MAX_IMAGES = 8, MAX_TEXT = 20000, POLL_MS = 700;
const PRIVATE_FORMATS = ['ExcludeClipboardContentFromMonitorProcessing', 'Clipboard Viewer Ignore'];
const HISTORY_FORMAT = 'CanIncludeInClipboardHistory';
const hash = value => crypto.createHash('sha256').update(value).digest('hex');

function createClipHistory({ clipboard, nativeImage, ClipboardItem, onChange = () => {}, log = () => {} }) {
  let items = [], timer = null, lastKey = null, generation = 0, polling = null;
  let queue = Promise.resolve();

  // Okuma ve yazma sırayla yapılır; eski bir okuma kendi kopyamızı ya da durdurmayı geçersiz kılamaz.
  function enqueue(fn) { const task = queue.then(fn); queue = task.catch(() => {}); return task; }

  async function snapshot() {
    const clips = await clipboard.read();
    // Özel işaretleri metin/resim okunmadan kontrol et. History=1 açıkça kayıt iznidir.
    for (const clip of clips) for (const type of clip.types) {
      const format = /^electron application\/osclipboard;format="([^"]+)"$/.exec(type)?.[1];
      if (PRIVATE_FORMATS.includes(format)) return { key: 'private' };
      if (format === HISTORY_FORMAT) {
        const bytes = Buffer.from(await (await clip.getType(type)).arrayBuffer());
        if (bytes.length !== 4 || bytes.readUInt32LE(0) !== 1) return { key: 'private' };
      }
    }
    const textClip = clips.find(c => c.types.includes('text/plain'));
    if (textClip) {
      const text = await (await textClip.getType('text/plain')).text();
      if (text) return { key: `text:${hash(text)}`, entry: text.trim() && text.length <= MAX_TEXT ? { kind: 'text', text } : null };
    }
    const imageClip = clips.find(c => c.types.includes('image/png'));
    if (imageClip) {
      const blob = await imageClip.getType('image/png');
      const image = nativeImage.createFromBuffer(Buffer.from(await blob.arrayBuffer()));
      if (!image.isEmpty()) {
        const s = image.getSize();
        return { key: `image:${s.width}x${s.height}:${hash(image.toBitmap())}`, entry: { kind: 'image', image, blob } };
      }
    }
    return { key: 'empty' };
  }

  function poll() {
    const epoch = generation;
    if (polling?.epoch === epoch) return polling.task;
    const task = enqueue(async () => {
      if (epoch !== generation) return;
      try {
        const { key, entry } = await snapshot();
        if (epoch !== generation || key === lastKey) return;
        const initial = lastKey === null;
        lastKey = key;
        if (!initial && entry) add({ ...entry, key });
      } catch (e) { log('clipboard read', e.message); }
    });
    polling = { epoch, task };
    task.finally(() => { if (polling?.task === task) polling = null; });
    return task;
  }

  function add(entry) {
    items = items.filter(i => i.key !== entry.key);
    const s = entry.image?.getSize();
    items.unshift({ id: crypto.randomUUID(), at: Date.now(), ...entry,
      thumb: entry.image ? entry.image.resize({ height: Math.min(64, s.height) }).toDataURL() : '',
      size: s ? `${s.width}×${s.height}` : '',
    });
    let images = 0;
    items = items.filter(i => i.kind !== 'image' || ++images <= MAX_IMAGES).slice(0, MAX_ITEMS);
    onChange(list());
  }

  function list() {
    return items.map(({ image, blob, key, ...i }) => ({ ...i, text: i.text ? i.text.slice(0, 600) : '', long: (i.text || '').length > 600 }));
  }
  function copy(id) {
    const epoch = generation;
    return enqueue(async () => {
      const i = items.find(x => x.id === id);
      if (!i || epoch !== generation) return false;
      try {
        if (i.kind === 'text') await clipboard.writeText(i.text);
        else await clipboard.write([new ClipboardItem({ 'image/png': i.blob })]);
      } catch (e) { log('clipboard write', e.message); return false; }
      if (epoch !== generation) return false;
      lastKey = i.key;
      items = [i, ...items.filter(x => x !== i)];
      onChange(list());
      return true;
    });
  }
  function remove(id) { items = items.filter(i => i.id !== id); onChange(list()); }
  function clear() { items = []; onChange(list()); }
  function start() {
    if (timer) return polling?.task || Promise.resolve();
    generation++; lastKey = null;
    timer = setInterval(poll, POLL_MS);
    return poll(); // açılıştaki pano içeriğini kaydetmeden başlangıç durumunu al
  }
  function stop() { clearInterval(timer); timer = null; generation++; lastKey = null; items = []; }
  return { start, stop, list, copy, remove, clear, poll, running: () => Boolean(timer) };
}

module.exports = { createClipHistory, MAX_ITEMS };
