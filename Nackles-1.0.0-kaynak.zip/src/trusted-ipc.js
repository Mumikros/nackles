const { pathToFileURL } = require('node:url');

// Remote views and subframes must never reach the local desktop bridge.
function createTrustedIpc(ipc, getWindows) {
  function allowed(event) {
    if (!event?.sender || !event.senderFrame) return false;
    return getWindows().some(({ window, file }) => window && !window.isDestroyed()
      && event.sender === window.webContents
      && event.senderFrame === window.webContents.mainFrame
      && event.senderFrame.url === pathToFileURL(file).href);
  }
  return {
    on(channel, listener) {
      ipc.on(channel, (event, ...args) => { if (allowed(event)) return listener(event, ...args); });
    },
    handle(channel, listener) {
      ipc.handle(channel, (event, ...args) => {
        if (!allowed(event)) throw new Error('Untrusted IPC sender');
        return listener(event, ...args);
      });
    },
  };
}

module.exports = { createTrustedIpc };
