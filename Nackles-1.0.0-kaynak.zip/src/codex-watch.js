// Codex izleme: Codex (masaüstü uygulaması ve CLI) her sohbetin olaylarını ~/.codex/sessions/YYYY/MM/DD altındaki
// rollout-*.jsonl dosyalarına satır satır yazar. Bu dosyaları sadece OKURUZ; hiçbir şey yazmayız, ağa bir şey göndermeyiz.
// Okunan satırlar, Claude Code hook olaylarıyla aynı biçime çevrilip hub'a verilir.
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const POLL_MS = 900;
const UUID = /([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})\.jsonl$/i;

// Bir rollout satırını hook olayına çevirir. Çeviremezse null. (Testler için ayrı dışa açık.)
function translate(line, ctx) {
  const t = line.type, p = line.payload || {};
  const base = { session_id: ctx.id, cwd: ctx.cwd };
  if (t === 'session_meta' || t === 'turn_context') {
    if (p.cwd) ctx.cwd = String(p.cwd).replace(/^\\\\\?\\/, '');
    return t === 'session_meta' ? { ...base, cwd: ctx.cwd, hook_event_name: 'SessionStart' } : null;
  }
  if (t === 'event_msg') {
    if (p.type === 'task_started') { ctx.wantPrompt = true; return { ...base, hook_event_name: 'UserPromptSubmit', prompt: '' }; }
    if (p.type === 'task_complete') { ctx.wantPrompt = false; return { ...base, hook_event_name: 'Stop' }; }
    if (p.type === 'turn_aborted') { ctx.wantPrompt = false; return { ...base, hook_event_name: 'Stop' }; }
    if (/approval_request|request_permissions|elicitation/.test(p.type || '')) {
      return { ...base, hook_event_name: 'PermissionRequest', tool_name: 'shell', tool_input: { command: p.command || p.reason || '' } };
    }
    return null;
  }
  if (t === 'response_item') {
    if (p.type === 'message' && p.role === 'user' && ctx.wantPrompt) {
      const text = (p.content || []).map(c => c.text || '').join(' ').trim();
      if (text && !text.startsWith('<') && !text.startsWith('#')) { ctx.wantPrompt = false; return { ...base, hook_event_name: 'Title', prompt: text }; }
      return null;
    }
    if (/^(custom_tool_call|function_call|local_shell_call)$/.test(p.type)) {
      let input = p.arguments ?? p.input ?? p.action ?? {};
      if (typeof input === 'string') { try { input = JSON.parse(input); } catch { input = { code: input }; } }
      return { ...base, hook_event_name: 'PreToolUse', tool_name: p.name || p.type, tool_input: input, tool_use_id: p.call_id };
    }
    if (/_call_output$/.test(p.type)) return { ...base, hook_event_name: 'PostToolUse', tool_use_id: p.call_id };
  }
  return null;
}

function createCodexWatch({ onEvent, home = process.env.CODEX_HOME || path.join(os.homedir(), '.codex'), log = () => {} }) {
  const root = path.join(home, 'sessions');
  const files = new Map(); // yol -> { offset, rest, ctx }
  let timer = null, startedAt = 0;

  // Bugünün ve dünün klasörleri yeterli (gece yarısını geçen sohbetler için dün de).
  function dayDirs() {
    const out = [];
    for (const back of [0, 1]) {
      const d = new Date(Date.now() - back * 86400000);
      out.push(path.join(root, String(d.getFullYear()), String(d.getMonth() + 1).padStart(2, '0'), String(d.getDate()).padStart(2, '0')));
    }
    return out;
  }

  function scan(initial) {
    for (const dir of dayDirs()) {
      let names; try { names = fs.readdirSync(dir); } catch { continue; }
      for (const name of names) {
        const m = UUID.exec(name); if (!m || !name.startsWith('rollout-')) continue;
        const file = path.join(dir, name);
        let st; try { st = fs.statSync(file); } catch { continue; }
        let f = files.get(file);
        if (!f) {
          // Başlarken eski sohbetleri yeniden oynatmayız; sadece son 2 dakikada yazılmışsa baştan okuruz.
          const fresh = !initial || Date.now() - st.mtimeMs < 2 * 60 * 1000;
          f = { offset: fresh ? 0 : st.size, rest: '', ctx: { id: m[1], cwd: '', wantPrompt: false }, size: st.size };
          files.set(file, f);
          if (!fresh) primeCwd(file, f.ctx);
        }
        if (st.size > f.offset) read(file, f, st.size);
        else if (st.size < f.offset) { f.offset = 0; f.rest = ''; } // dosya yeniden yazılmış
      }
    }
  }

  function primeCwd(file, ctx) {
    try {
      const fd = fs.openSync(file, 'r'); const buf = Buffer.alloc(16384);
      const n = fs.readSync(fd, buf, 0, buf.length, 0); fs.closeSync(fd);
      const first = buf.subarray(0, n).toString('utf8').split('\n')[0];
      translate(JSON.parse(first), ctx);
    } catch {}
  }

  function read(file, f, size) {
    const len = Math.min(size - f.offset, 4 * 1024 * 1024);
    const buf = Buffer.alloc(len);
    try { const fd = fs.openSync(file, 'r'); fs.readSync(fd, buf, 0, len, f.offset); fs.closeSync(fd); } catch { return; }
    f.offset += len;
    const lines = (f.rest + buf.toString('utf8')).split('\n');
    f.rest = lines.pop();
    for (const raw of lines) {
      if (!raw.trim()) continue;
      let line; try { line = JSON.parse(raw); } catch { continue; }
      const ev = translate(line, f.ctx);
      if (ev) { try { onEvent(ev); } catch (e) { log('codex-watch', e.message); } }
    }
  }

  function start() {
    if (timer) return;
    startedAt = Date.now();
    scan(true);
    timer = setInterval(() => scan(false), POLL_MS);
    log('codex-watch', 'başladı', root);
  }
  function stop() { clearInterval(timer); timer = null; files.clear(); }

  return { start, stop, running: () => Boolean(timer), startedAt: () => startedAt };
}

module.exports = { createCodexWatch, translate };
