// Odak koruması: odaklanırken dikkat dağıtan bir site ya da uygulama öne gelince araya sakin bir nefes ekranı girer.
// Sadece öndeki pencerenin başlığına ve programına bakılır; hiçbir şey saklanmaz ya da gönderilmez,
// yalnızca bugünün sayıları (kaç kez geri dönüldü) userData/focus-guard.json'da tutulur.
const fs = require('node:fs');
const path = require('node:path');

const SITES = {
  youtube: { name: 'YouTube', title: /youtube/i },
  tiktok: { name: 'TikTok', title: /tiktok/i },
  instagram: { name: 'Instagram', title: /instagram/i },
  x: { name: 'X', title: /(\s[/|]\s?x\b|\bx\.com\b|twitter)/i },
  reddit: { name: 'Reddit', title: /reddit/i },
  facebook: { name: 'Facebook', title: /facebook/i },
  netflix: { name: 'Netflix', title: /netflix/i, proc: /netflix/i },
  twitch: { name: 'Twitch', title: /twitch/i },
  discord: { name: 'Discord', title: /discord/i, proc: /^discord$/i },
};
const BROWSER = /^(chrome|msedge|firefox|brave|brave\w*|opera|opera_gx|vivaldi|arc|librewolf|waterfox|thorium|floorp|zen)$/i;

// Öndeki pencere listedeki bir siteye/uygulamaya mı ait? Tarayıcıda başlığa, uygulamalarda programa bakılır.
function match(front, enabled) {
  if (!front) return null;
  for (const id of enabled) {
    const s = SITES[id]; if (!s) continue;
    if (s.proc && s.proc.test(front.proc)) return id;
    if (BROWSER.test(front.proc) && s.title.test(front.title)) return id;
  }
  return null;
}

function createGuard({ userData, getSettings, focusRunning = () => false, onTrigger = () => {}, now = () => Date.now() }) {
  const file = path.join(userData, 'focus-guard.json');
  const today = () => new Date(now()).toISOString().slice(0, 10);
  let stats = { day: today(), back: 0, open: 0 };
  try { const s = JSON.parse(fs.readFileSync(file, 'utf8')); if (s.day === today()) stats = s; } catch {}
  const snoozed = new Map(); // site → bitiş zamanı
  let showing = null;

  function active() {
    const g = getSettings().focusGuard;
    return Boolean(g?.on) && (g.always || focusRunning());
  }

  // Öndeki pencere değişince çağrılır; korunacaksa onTrigger({ site, name, front }) çalışır.
  function check(front) {
    if (showing || !active()) return null;
    const site = match(front, getSettings().focusGuard.sites);
    if (!site || (snoozed.get(site) || 0) > now()) return null;
    showing = { site, front };
    onTrigger({ site, name: SITES[site].name, front });
    return site;
  }

  function save() {
    if (stats.day !== today()) stats = { day: today(), back: 0, open: 0 };
    try { fs.mkdirSync(userData, { recursive: true }); fs.writeFileSync(file, JSON.stringify(stats)); } catch {}
  }
  // Kullanıcının cevabı: 'back' (geri dön) ya da 'open' (yine de aç → bir süre rahat bırak)
  function answer(choice) {
    const s = showing; showing = null;
    if (!s) return null;
    if (stats.day !== today()) stats = { day: today(), back: 0, open: 0 };
    if (choice === 'open') { stats.open++; snoozed.set(s.site, now() + (getSettings().focusGuard.snoozeMin || 5) * 60000); }
    else stats.back++;
    save();
    return s;
  }
  const todayStats = () => (stats.day === today() ? { back: stats.back, open: stats.open } : { back: 0, open: 0 });

  return { check, answer, todayStats, isShowing: () => Boolean(showing) };
}

module.exports = { createGuard, match, SITES };
