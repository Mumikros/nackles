// Yardımcı süreç: çalan müziği ve öndeki pencerenin adayı kapatıp kapatmadığını ("cover") bildirir, müzik komutlarını alır.
// Önce küçük C# yardımcısı (media/MediaBridge.cs, ~10 MB) kullanılır: Windows'la gelen .NET derleyicisiyle bir kez
// derlenip userData'da saklanır. Derlenemezse eski PowerShell betiğine (media.ps1, ~70 MB, "cover" yok) dönülür.
const { spawn, execFileSync } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

function buildHelper(userData, log) {
  const src = path.join(__dirname, 'media', 'MediaBridge.cs').replace('app.asar', 'app.asar.unpacked');
  const hash = crypto.createHash('sha1').update(fs.readFileSync(src)).digest('hex').slice(0, 10);
  const dir = path.join(userData, 'bin'), exe = path.join(dir, `nackles-helper-${hash}.exe`);
  if (fs.existsSync(exe)) return exe;
  const fw = path.join(process.env.WINDIR || 'C:\\Windows', 'Microsoft.NET', 'Framework64', 'v4.0.30319');
  const wm = path.join(process.env.WINDIR || 'C:\\Windows', 'System32', 'WinMetadata');
  fs.mkdirSync(dir, { recursive: true });
  for (const old of fs.readdirSync(dir)) if (/^nackles-helper-.*\.exe$/.test(old)) try { fs.unlinkSync(path.join(dir, old)); } catch {}
  execFileSync(path.join(fw, 'csc.exe'), ['/nologo', '/target:exe', '/optimize+', `/out:${exe}`,
    `/r:${path.join(fw, 'System.Runtime.dll')}`, `/r:${path.join(wm, 'Windows.Media.winmd')}`,
    `/r:${path.join(wm, 'Windows.Foundation.winmd')}`, `/r:${path.join(wm, 'Windows.Storage.winmd')}`, src],
  { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'], timeout: 60000 });
  log('media', 'yardımcı derlendi', exe);
  return exe;
}

function createMedia({ userData, onChange = () => {}, onCover = () => {}, onFront = () => {}, log = () => {} }) {
  let child = null, buffer = '', state = { active: false }, art = '', stopped = false, restarts = 0, cover = false;
  let helper; try { helper = buildHelper(userData, log); } catch (e) { helper = null; log('media', 'yardımcı derlenemedi, PowerShell kullanılacak', String(e.stderr || e.message).slice(0, 300)); }

  function start() {
    stopped = false;
    if (helper) child = spawn(helper, [String(process.pid)], { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
    else {
      const script = path.join(__dirname, 'media', 'media.ps1').replace('app.asar', 'app.asar.unpacked');
      child = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', script], { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
    }
    child.stdout.setEncoding('utf8');
    child.stdout.on('data', chunk => {
      buffer += chunk;
      let i;
      while ((i = buffer.indexOf('\n')) >= 0) {
        const line = buffer.slice(0, i).trim(); buffer = buffer.slice(i + 1);
        if (!line) continue;
        try { update(JSON.parse(line)); restarts = 0; } catch {}
      }
    });
    child.stderr.on('data', d => log('media', String(d).trim().slice(0, 300)));
    child.on('exit', code => {
      child = null;
      if (stopped) return;
      // Çökerse biraz bekleyip yeniden dene; üst üste çökerse giderek daha seyrek.
      const wait = Math.min(60000, 2000 * 2 ** restarts++);
      log('media', 'çıktı', code, 'yeniden', wait);
      setTimeout(() => { if (!stopped) start(); }, wait);
    });
  }

  let lastKey = '', artId = 0, lastFront = '';
  function update(msg) {
    if (typeof msg.cover === 'boolean' && msg.cover !== cover) { cover = msg.cover; onCover(cover); }
    // Öndeki pencere değişince (odak koruması için) bildirilir.
    if (msg.front && typeof msg.front === 'object') {
      const k = `${msg.front.hwnd}|${msg.front.title}`;
      if (k !== lastFront) { lastFront = k; onFront({ hwnd: Number(msg.front.hwnd) || 0, proc: String(msg.front.proc || ''), title: String(msg.front.title || '') }); }
    }
    if (typeof msg.art === 'string' && msg.art !== art) { art = msg.art; artId++; }
    const next = msg.active ? {
      active: true, app: appName(msg.app), title: String(msg.title || ''), artist: String(msg.artist || ''), album: String(msg.album || ''),
      playing: Boolean(msg.playing), position: Number(msg.position) || 0, duration: Number(msg.duration) || 0, updated: Number(msg.updated) || Date.now(),
      canNext: Boolean(msg.canNext), canPrev: Boolean(msg.canPrev), artId,
    } : { active: false };
    // Kapak resmi büyük olabilir: karşılaştırmaya resmin kendisi değil, numarası girer.
    const key = JSON.stringify(next);
    if (key === lastKey) return;
    lastKey = key;
    state = msg.active ? { ...next, art } : next;
    onChange(state);
  }

  function appName(id = '') {
    if (/spotify/i.test(id)) return 'Spotify';
    if (/chrome/i.test(id)) return 'Chrome';
    if (/msedge|edge/i.test(id)) return 'Edge';
    if (/firefox/i.test(id)) return 'Firefox';
    if (/brave/i.test(id)) return 'Brave';
    if (/opera/i.test(id)) return 'Opera';
    if (/zune|groove|media ?player/i.test(id)) return 'Medya Oynatıcı';
    return String(id).split(/[!.\\]/).filter(Boolean).pop() || 'Müzik';
  }

  function command(cmd) {
    if (!child || !(['toggle', 'next', 'prev'].includes(cmd) || /^minimize \d+$/.test(cmd))) return;
    child.stdin.write(cmd + '\n');
  }

  function stop() { stopped = true; try { child?.stdin.end(); child?.kill(); } catch {} }

  return { start, stop, command, get: () => state };
}

module.exports = { createMedia };
