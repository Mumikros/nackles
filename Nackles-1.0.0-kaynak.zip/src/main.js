const { app, BrowserWindow, Tray, Menu, ipcMain: electronIpcMain, nativeImage, screen, globalShortcut, dialog } = require('electron');
const path = require('node:path');
const fs = require('node:fs');
const { createHub, PORT } = require('./hub');
const { createStore } = require('./settings-store');
const { createMedia } = require('./media');
const { createNotes } = require('./notes');
const { createCodexWatch } = require('./codex-watch');
const { createChat } = require('./chat');
const { createGeminiWeb } = require('./gemini-web');
const { createClipHistory } = require('./clip-history');
const { createShelf } = require('./shelf');
const { createFilee } = require('./filee');
const { createGuard } = require('./focus-guard');
const { createTrustedIpc } = require('./trusted-ipc');
const { execFile } = require('node:child_process');
const execFileAsync = require('node:util').promisify(execFile);
const i18n = require('./shared/i18n');
const t = (...a) => i18n.t(...a);
const { clipboard, ClipboardItem, shell } = require('electron');

// Pencere adadan büyük ve şeffaf; ada genişleyince pencereyi yeniden boyutlandırmak yerine
// boş alanları tıklamaya geçirgen yapıyoruz (adanın üstündeyken tıklanabilir).
const WIN_W = 600, WIN_H = 320;
const AGENT_NAMES = { claude: 'Claude Code', codex: 'Codex' };

// Kaldırıcı (build/installer.nsh) uygulamayı bu bayrakla çalıştırır: Claude Code ayarlarındaki Nackles hook'larını
// ve "Windows ile başlat" kaydını siler, başka hiçbir şeye dokunmadan çıkar. Hazır olmayı beklemeden çıkıyoruz ki
// arkada Chromium yardımcı süreçleri kalıp kaldırıcının klasörü silmesini engellemesin.
const REMOVE_HOOKS = process.argv.includes('--remove-hooks');
if (REMOVE_HOOKS) {
  try { const h = createHub({ userData: app.getPath('userData') }); h.disconnect(); h.cleanupCodexHooks(); } catch {}
  try { app.setLoginItemSettings({ openAtLogin: false }); } catch {}
  app.exit(0);
} else if (!app.requestSingleInstanceLock()) { app.quit(); }
// Donanım hızlandırma varsayılan olarak kapalı: küçük bir ada için ekran kartı süreci ~150-200 MB bellek ve
// sürekli işlemci yiyor; kapalıyken Nackles toplam ~160 MB'ta kalıyor. Ayarlardan açılabilir (yeniden başlatınca).
if (!createStore(app.getPath('userData')).get().gpu && !process.argv.includes('--gpu')) app.disableHardwareAcceleration();

let win = null, tray = null, hub = null, store = null, settingsWin = null, media = null, notes = null, codexWatch = null, chat = null;
let clips = null, shelf = null;
let geminiWeb = null, geminiMode = false;
const ipcMain = createTrustedIpc(electronIpcMain, () => [
  { window: win, file: path.join(__dirname, 'island', 'island.html') },
  { window: settingsWin, file: path.join(__dirname, 'settings', 'settings.html') },
  { window: guardWin, file: path.join(__dirname, 'guard', 'guard.html') },
]);
const filee = createFilee({ log });

// Hata ayıklama için: pencerelerdeki hatalar userData/nackles.log dosyasına yazılır (sadece bu bilgisayarda kalır).
// 512 KB'ı geçince eskisi nackles.log.old olur, böylece dosya sonsuza kadar büyümez.
function log(...parts) {
  const file = path.join(app.getPath('userData'), 'nackles.log');
  try { if (fs.statSync(file).size > 512 * 1024) fs.renameSync(file, file + '.old'); } catch {}
  try { fs.appendFileSync(file, `[${new Date().toISOString()}] ${parts.join(' ')}\n`); } catch {}
}
function watchConsole(w, name) {
  w.webContents.on('console-message', e => { if (e.level === 'error' || e.level === 'warning') log(name, e.level, e.message, `${e.sourceId}:${e.lineNumber}`); });
  w.webContents.on('render-process-gone', (_e, d) => log(name, 'renderer gone', d.reason));
  w.webContents.on('did-fail-load', (_e, code, desc) => log(name, 'load failed', code, desc));
}
process.on('uncaughtException', e => log('main', e.stack));
process.on('unhandledRejection', e => log('main', e?.stack || String(e)));

// ---------- dil ----------
// "Otomatik" seçiliyse Windows dili Türkçe ise Türkçe, değilse İngilizce.
function uiLang() { const l = store.get().lang; return l === 'auto' ? (app.getLocale().toLowerCase().startsWith('tr') ? 'tr' : 'en') : l; }
function withLang(s) { i18n.setLang(uiLang()); return { ...s, uiLang: uiLang() }; }

// ---------- logo ----------
// Uygulama ikonu "Oyma" logosu (src/assets, scripts/make-icons.js ile üretilir). Tepside 16 px + yüksek DPI için 32 px.
const assetPath = n => path.join(__dirname, 'assets', n).replace('app.asar', 'app.asar.unpacked');
function appIcon() { return nativeImage.createFromPath(assetPath('icon.ico')); }
function trayIcon() {
  const img = nativeImage.createFromPath(assetPath('icon-16.png'));
  img.addRepresentation({ scaleFactor: 2, buffer: fs.readFileSync(assetPath('icon-32.png')) });
  return img;
}

function send(channel, data) { if (win && !win.isDestroyed()) win.webContents.send(channel, data); }
function sendSettingsWin(channel, data) { if (settingsWin && !settingsWin.isDestroyed()) settingsWin.webContents.send(channel, data); }
function pushState() { send('state', hub.view()); sendSettingsWin('info', settingsInfo()); refreshTray(); }

// Ayarlar penceresinin göstereceği her şey tek pakette.
function settingsInfo() {
  const v = hub.view();
  return { settings: withLang(store.get()), links: v.links, error: v.error, openAtLogin: app.getLoginItemSettings().openAtLogin, version: app.getVersion(), port: PORT, userData: app.getPath('userData') };
}

function openSettings() {
  if (settingsWin && !settingsWin.isDestroyed()) { if (settingsWin.isMinimized()) settingsWin.restore(); settingsWin.show(); settingsWin.focus(); return; }
  const w = new BrowserWindow({
    width: 820, height: 620, minWidth: 680, minHeight: 480, show: false, title: `${store.get().name} Ayarlar`, icon: appIcon(),
    backgroundColor: '#0B0C0E', autoHideMenuBar: true,
    titleBarStyle: 'hidden', titleBarOverlay: { color: '#0B0C0E', symbolColor: '#C9CCD2', height: 40 },
    webPreferences: { preload: path.join(__dirname, 'settings', 'settings-preload.js'), contextIsolation: true, sandbox: true, nodeIntegration: false },
  });
  settingsWin = w;
  const reveal = () => { if (!w.isDestroyed()) { w.show(); w.focus(); } };
  watchConsole(w, 'settings');
  w.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  w.webContents.on('will-navigate', e => e.preventDefault());
  w.once('ready-to-show', reveal);
  // Windows gizli başlatıldıysa ilk ShowWindow çağrısını gizli tutabilir. Yükleme sonunda görünürlüğü doğrula.
  w.loadFile(path.join(__dirname, 'settings', 'settings.html')).then(() => { if (!w.isDestroyed() && !w.isVisible()) reveal(); })
    .catch(e => log('settings load', e.message));
  w.on('closed', () => { if (settingsWin === w) settingsWin = null; });
}

// Müzik sadece ayarlarda açıksa dinlenir.
// Yardımcı süreç hep çalışır (öndeki pencereyi izlemek için); müzik bilgisi sadece ayarlarda açıksa adaya gider.
let coverState = false;
function syncMedia() {
  if (!media) {
    media = createMedia({
      userData: app.getPath('userData'),
      onChange: m => { if (store.get().music) send('media', m); },
      onCover: c => { coverState = c; send('cover', c); },
      onFront: f => guard?.check(f),
      log,
    });
    media.start();
  }
  send('media', store.get().music ? media.get() : { active: false });
}

// Codex kayıtları sadece ayarlarda açıksa izlenir.
function syncCodex() {
  const want = store.get().codexWatch;
  if (want && !codexWatch) {
    codexWatch = createCodexWatch({ onEvent: ev => hub.handle(ev, null, 'codex'), log });
    codexWatch.start();
  } else if (!want && codexWatch) {
    codexWatch.stop(); codexWatch = null;
    hub.forgetCodex();
  }
  hub.refreshLinks();
}

// Pano geçmişi sadece ayarlarda açıksa tutulur; kapatınca bellekteki geçmiş de silinir.
function syncClips() {
  const want = store.get().clipboard;
  if (want && !clips.running()) clips.start();
  else if (!want && clips.running()) { clips.stop(); send('clips', []); }
}

function applySettings() {
  i18n.setLang(uiLang());
  if (settingsWin && !settingsWin.isDestroyed()) settingsWin.setTitle(`${store.get().name} Ayarlar`);
  refreshTray();
  syncMedia(); syncCodex(); syncClips(); send('settings', withLang(store.get())); sendSettingsWin('info', settingsInfo()); }

function place() {
  const { bounds } = screen.getPrimaryDisplay();
  const height = geminiMode ? Math.min(760, bounds.height - 40) : WIN_H;
  win.setBounds({ x: Math.round(bounds.x + (bounds.width - WIN_W) / 2), y: bounds.y, width: WIN_W, height });
}

function createWindow() {
  win = new BrowserWindow({
    width: WIN_W, height: WIN_H, show: false, frame: false, transparent: true, resizable: false, movable: false,
    skipTaskbar: true, hasShadow: false, alwaysOnTop: true, fullscreenable: false, minimizable: false, maximizable: false,
    backgroundColor: '#00000000', title: 'Nackles', icon: appIcon(),
    // autoplayPolicy: ada hiç tıklanmadan da bitiş sesini çalabilsin (yoksa Chromium sesi engelliyor)
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, sandbox: true, nodeIntegration: false, backgroundThrottling: false, autoplayPolicy: 'no-user-gesture-required' },
  });
  win.setAlwaysOnTop(true, 'screen-saver');
  win.setVisibleOnAllWorkspaces(true);
  win.setIgnoreMouseEvents(true, { forward: true });
  win.setFocusable(false);
  place();
  watchConsole(win, 'island');
  geminiWeb = createGeminiWeb({ win, onState: state => send('chat:web-state', state), onFocus: focused => send('chat:web-focus', focused), log });
  win.loadFile(path.join(__dirname, 'island', 'island.html'));
  win.once('ready-to-show', () => {
    win.showInactive();
    send('settings', withLang(store.get()));
    if (media && store.get().music) send('media', media.get());
    send('cover', coverState);
    pushState();
  });
  // Dışarıdan link açılmasın.
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', e => e.preventDefault());
  screen.on('display-metrics-changed', place);
  screen.on('display-added', place);
  screen.on('display-removed', place);
}

function setConnected(agent, on) {
  if (agent === 'codex') {
    // Codex dosyasına bir şey yazmayız; sadece sohbet kayıtlarını izlemeyi açıp kapatırız.
    store.set({ codexWatch: Boolean(on) });
    applySettings(); pushState();
    return;
  }
  try { on ? hub.connect() : hub.disconnect(); }
  catch (e) {
    dialog.showErrorBox('Nackles', 'Claude Code ayar dosyası okunamadı (~/.claude/settings.json).\n' +
      'Dosyada bir JSON hatası olabilir; Nackles dosyanın üzerine yazmadı.\n\n' + e.message);
  }
  pushState();
}

function refreshTray() {
  if (!tray) return;
  const v = hub.view();
  const login = app.getLoginItemSettings().openAtLogin;
  const s = v.sessions[0];
  const nm = store.get().name;
  tray.setToolTip(s ? `${nm} · ${s.agentName} · ${s.project}: ${s.detail}` : nm);
  const agentItem = agent => v.links[agent]
    ? { label: t(`${AGENT_NAMES[agent]} bağlantısını kaldır`), click: () => setConnected(agent, false) }
    : { label: agent === 'codex' ? t("Codex'e bağlan") : t("Claude Code'a bağlan"), click: () => setConnected(agent, true) };
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: t(win?.isVisible() ? 'Adayı gizle' : 'Adayı göster'), click: () => { win.isVisible() ? win.hide() : win.showInactive(); refreshTray(); } },
    { type: 'separator' },
    agentItem('claude'),
    ...(v.links.codexAvailable || v.links.codex ? [agentItem('codex')] : []),
    { label: t('Windows ile başlat'), type: 'checkbox', checked: login, click: m => { app.setLoginItemSettings({ openAtLogin: m.checked }); refreshTray(); applySettings(); } },
    { label: t('Ayarlar') + '…', click: openSettings },
    { type: 'separator' },
    { label: t('Uygulamayı kapat'), click: () => app.quit() },
  ]));
}

app.whenReady().then(() => {
  if (REMOVE_HOOKS) return;
  app.setAppUserModelId('com.nackles.app');
  store = createStore(app.getPath('userData'));
  i18n.setLang(uiLang());
  notes = createNotes(app.getPath('userData'));
  chat = createChat({ userData: app.getPath('userData'), onEvent: e => send('chat', e), log });
  clips = createClipHistory({ clipboard, nativeImage, ClipboardItem, onChange: list => send('clips', list), log });
  guard = createGuard({ userData: app.getPath('userData'), getSettings: () => store.get(), focusRunning: () => focusRunning, onTrigger: showGuard });
  shelf = createShelf(app.getPath('userData'));
  hub = createHub({
    userData: app.getPath('userData'),
    askInIsland: () => store.get().askInIsland,
    codexOn: () => store.get().codexWatch,
    log,
    onChange: pushState,
    onFinish: s => send('finished', { id: s.id, state: s.state }),
  });
  hub.start();
  // Eski sürümlerin Codex hook'ları artık işe yaramıyor (Codex masaüstü onları çalıştırmıyor): sessizce kaldır.
  if (hub.cleanupCodexHooks()) log('eski Nackles Codex hook\'ları kaldırıldı');
  syncMedia();
  syncCodex();
  syncClips();
  createWindow();

  // Tepsi ikonu ilk anda boş; ada sayfası maskotu çizip PNG olarak gönderiyor.
  tray = new Tray(trayIcon());
  tray.on('click', () => send('toggle-pin'));
  refreshTray();

  if (process.argv.includes('--settings')) openSettings();
  globalShortcut.register('Control+Alt+N', () => { if (!win.isVisible()) win.showInactive(); send('toggle-pin'); });
});

// ---------- ayarlar penceresi ----------
ipcMain.on('open-settings', openSettings);

ipcMain.on('open-data-folder', () => shell.openPath(app.getPath('userData')));
ipcMain.on('hide-island', () => { win?.hide(); refreshTray(); });
ipcMain.on('quit', () => app.quit());
ipcMain.handle('settings:info', () => settingsInfo());
ipcMain.handle('settings:set', (_e, patch) => { if (patch && typeof patch === 'object') store.set(patch); applySettings(); return settingsInfo(); });
ipcMain.handle('settings:reset', () => { store.reset(); applySettings(); return settingsInfo(); });
ipcMain.handle('settings:login', (_e, on) => { app.setLoginItemSettings({ openAtLogin: Boolean(on) }); refreshTray(); return settingsInfo(); });
// ---------- kendi maskotunu ekleme ----------
// Seçilen resim userData/mascots içine kopyalanır; ada ve ayarlar onu buradan okur.
const MASCOT_EXT = { '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp', '.svg': 'image/svg+xml' };
const mascotDir = () => path.join(app.getPath('userData'), 'mascots');
function mascotFile(id) {
  if (!/^[a-z0-9-]{6,40}$/.test(String(id))) return null;
  try { const f = fs.readdirSync(mascotDir()).find(n => n.startsWith(id + '.')); return f ? path.join(mascotDir(), f) : null; } catch { return null; }
}
ipcMain.handle('mascot:add', async e => {
  const r = await dialog.showOpenDialog(BrowserWindow.fromWebContents(e.sender), {
    title: t('Maskot resmi seç'), properties: ['openFile'],
    filters: [{ name: t('Resim'), extensions: ['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg'] }],
  });
  if (r.canceled || !r.filePaths[0]) return { ok: false };
  const src = r.filePaths[0], ext = path.extname(src).toLowerCase();
  if (!MASCOT_EXT[ext]) return { ok: false, error: 'Bu dosya türü desteklenmiyor.' };
  if (fs.statSync(src).size > 3 * 1024 * 1024) return { ok: false, error: 'Resim 3 MB\'tan küçük olmalı.' };
  const id = require('node:crypto').randomBytes(6).toString('hex');
  fs.mkdirSync(mascotDir(), { recursive: true });
  fs.copyFileSync(src, path.join(mascotDir(), id + ext));
  const name = path.basename(src, ext).slice(0, 24) || 'Maskot';
  store.set({ customMascots: [...store.get().customMascots, { id, name }], mascotKind: 'custom:' + id });
  applySettings();
  return { ok: true, info: settingsInfo() };
});
ipcMain.handle('mascot:image', (_e, id) => {
  const f = mascotFile(id); if (!f) return '';
  return `data:${MASCOT_EXT[path.extname(f).toLowerCase()]};base64,${fs.readFileSync(f).toString('base64')}`;
});
ipcMain.handle('mascot:remove', (_e, id) => {
  const f = mascotFile(id); if (f) try { fs.unlinkSync(f); } catch {}
  const s = store.get();
  store.set({ customMascots: s.customMascots.filter(m => m.id !== id), mascotKind: s.mascotKind === 'custom:' + id ? 'robot' : s.mascotKind });
  applySettings();
  return settingsInfo();
});
ipcMain.handle('settings:connect', (_e, agent, on) => { setConnected(agent, Boolean(on)); return settingsInfo(); });
ipcMain.on('settings:preview', (_e, kind) => { if (['done', 'error', 'question'].includes(kind)) { if (!win.isVisible()) win.showInactive(); send('preview', kind); } });

// ---------- ada ----------
// Tıklanabilirlik: fare adanın üstündeyse pencere fareyi alır, değilse alttaki pencerelere geçirir.
// Explorer'dan dosya sürüklerken pencereye fare olayı gelmez; bu yüzden imleci ayrıca biz yokluyoruz.
let rendererOver = false, islandRect = null, ignoring = true, lastCursorIn = false;
function updateIgnore() {
  if (!win || win.isDestroyed()) return;
  let cursorIn = false;
  if (islandRect) {
    const p = screen.getCursorScreenPoint(), b = win.getBounds();
    const x = p.x - b.x, y = p.y - b.y;
    // İçerideyken (ince çizgi) sadece çizginin kendisi tıklanabilir; normalde kenarlarda biraz pay bırakılır.
    const mx = islandRect.tucked ? 0 : 12, my = islandRect.tucked ? 0 : 4;
    cursorIn = x >= islandRect.x - mx && x <= islandRect.x + islandRect.w + mx && y >= 0 && y <= islandRect.y + islandRect.h + my;
  }
  // Ada, fare çıkınca küçülebilsin diye imlecin içeride olup olmadığını buradan da öğrenir
  // (pencere fareyi geçirirken "mouseleave" bazen hiç gelmiyor).
  if (cursorIn !== lastCursorIn) { lastCursorIn = cursorIn; send('cursor-in', cursorIn); if (!cursorIn) rendererOver = false; }
  const ignore = !(rendererOver || cursorIn);
  if (ignore !== ignoring) { ignoring = ignore; win.setIgnoreMouseEvents(ignore, { forward: true }); }
}
setInterval(updateIgnore, 100).unref();
ipcMain.on('mouse', (_e, over) => { rendererOver = Boolean(over); updateIgnore(); });
ipcMain.on('island-rect', (_e, r) => { if (r && [r.x, r.y, r.w, r.h].every(Number.isFinite)) islandRect = { ...r, tucked: Boolean(r.tucked) }; });
// Kapalı ada tıklanınca öne gelmesin (öndeki pencere tarayıcı olarak kalsın); açıkken yazı yazılabilsin diye odak alabilir.
ipcMain.on('expanded', (_e, on) => { if (win && !win.isDestroyed()) win.setFocusable(Boolean(on)); });

// ---------- pano geçmişi ----------
ipcMain.handle('clips:list', () => clips.list());
ipcMain.handle('clips:copy', (_e, id) => clips.copy(String(id)));
ipcMain.on('clips:remove', (_e, id) => clips.remove(String(id)));
ipcMain.on('clips:clear', () => clips.clear());

// ---------- dosya tepsisi ----------
async function shelfView() {
  return Promise.all(shelf.list().map(async f => {
    let icon = '';
    try { icon = (await app.getFileIcon(f.path, { size: 'normal' })).toDataURL(); } catch {}
    return { ...f, icon };
  }));
}
ipcMain.handle('shelf:list', () => shelfView());
ipcMain.handle('shelf:add', (_e, paths) => { shelf.add(Array.isArray(paths) ? paths.map(String) : []); return shelfView(); });
ipcMain.handle('shelf:remove', (_e, id) => { shelf.remove(String(id)); return shelfView(); });
ipcMain.handle('shelf:clear', () => { shelf.clear(); return shelfView(); });
ipcMain.on('shelf:open', (_e, id) => { const f = shelf.get(String(id)); if (f) shell.openPath(f.path); });
ipcMain.on('shelf:reveal', (_e, id) => { const f = shelf.get(String(id)); if (f) shell.showItemInFolder(f.path); });
// Filee ile dönüştürme: sonuç asıl dosyanın yanına kaydedilir ve tepsiye eklenir.
ipcMain.handle('filee:available', () => filee.available());
ipcMain.handle('filee:targets', async (_e, id) => { const f = shelf.get(String(id)); return f ? filee.targets(f.path) : null; });
// ids: tepsideki dosyalar (seçim sırasıyla); job: { to: 'jpg' } ya da { preset: 'merge-pdf' }
ipcMain.handle('filee:run', async (_e, ids, job) => {
  const paths = [].concat(ids).map(id => shelf.get(String(id))?.path).filter(Boolean);
  if (!paths.length) return { ok: false, error: 'Dosya tepside yok.', files: await shelfView() };
  const r = await filee.convert(paths, job?.to ? { to: String(job.to) } : { preset: String(job?.preset || '') });
  if (r.outputs.length) shelf.add(r.outputs);
  return { ...r, files: await shelfView() };
});
ipcMain.handle('filee:merge-options', (_e, ids) => require('./filee').mergeOptions([].concat(ids).map(id => shelf.get(String(id))?.path).filter(Boolean)));
// Silme: dosyalar Geri Dönüşüm Kutusu'na gider (geri alınabilir), sonra tepsiden çıkar.
ipcMain.handle('shelf:trash', async (_e, ids) => {
  const failed = [];
  for (const id of [].concat(ids)) {
    const f = shelf.get(String(id)); if (!f) continue;
    try { await shell.trashItem(f.path); shelf.remove(f.id); } catch (e) { failed.push(f.path); log('çöpe atılamadı', f.path, e.message); }
  }
  return { failed, files: await shelfView() };
});
ipcMain.handle('shelf:remove-many', async (_e, ids) => { for (const id of [].concat(ids)) shelf.remove(String(id)); return shelfView(); });
// Tepsiden dışarı sürükleme: dosya, bırakıldığı yere (masaüstü, klasör, e-posta…) Windows'un kendi sürüklemesiyle gider.
ipcMain.on('shelf:drag', async (e, id) => {
  const f = shelf.get(String(id)); if (!f) return;
  let icon;
  try { icon = await app.getFileIcon(f.path, { size: 'normal' }); } catch {}
  if (!icon || icon.isEmpty()) icon = nativeImage.createFromDataURL('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=');
  e.sender.startDrag({ file: f.path, icon });
});
ipcMain.on('decide', (_e, { id, behavior }) => hub.decide(String(id), behavior === 'allow' ? 'allow' : 'deny'));
ipcMain.on('connect', (_e, { agent, on }) => setConnected(agent, Boolean(on)));
// Yalnızca yerel ada bu görünümün konumunu ve gezinmesini yönetebilir.
ipcMain.on('chat:web-layout', (e, data) => {
  if (!win || win.isDestroyed() || e.sender !== win.webContents || e.senderFrame !== win.webContents.mainFrame) return;
  const active = data?.active === true;
  if (geminiMode !== active) { geminiMode = active; place(); }
  geminiWeb?.setBounds(active ? data.bounds : null);
});
ipcMain.on('chat:web-action', (e, action) => {
  if (!win || win.isDestroyed() || e.sender !== win.webContents || e.senderFrame !== win.webContents.mainFrame) return;
  geminiWeb?.action(action);
});
const CHAT_AGENTS = ['claude', 'codex', 'chatgpt', 'gemini'];
const chatAgent = a => CHAT_AGENTS.includes(a) ? a : 'claude';
const CHAT_APPS = {
  claude: { scheme: 'claude', url: 'https://claude.ai/new' },
  codex: { scheme: 'codex', url: 'https://chatgpt.com/codex' },
  chatgpt: { scheme: 'chatgpt', url: 'https://chatgpt.com/' },
  gemini: { url: 'https://gemini.google.com/app' },
};
ipcMain.handle('chat:available', () => ({ ...chat.available(), gemini: true }));
ipcMain.on('chat:open-app', async (_e, agent) => {
  const { scheme, url } = CHAT_APPS[chatAgent(agent)];
  if (scheme && process.platform === 'win32') {
    try {
      await execFileAsync('reg.exe', ['query', `HKCR\\${scheme}`, '/v', 'URL Protocol'], { windowsHide: true, timeout: 3000 });
      await shell.openExternal(`${scheme}://`);
      return;
    } catch { /* Uygulama bulunamazsa veya açılamazsa sabit site adresine dön. */ }
  }
  try { await shell.openExternal(url); } catch (e) { log('chat open-app', e.message); }
});
ipcMain.on('chat:send', (_e, { id, agent, text }) => {
  if (typeof text !== 'string' || !text.trim()) return;
  if (agent === 'gemini') return; // Gemini'nin kendi web sayfasında yazışılır.
  chat.send(String(id), chatAgent(agent), text.slice(0, 20000));
});
ipcMain.on('chat:stop', (_e, id) => chat.stop(String(id)));
ipcMain.on('chat:reset', (_e, agent) => chat.reset(chatAgent(agent)));
// Hızlı işlemler (Açıkla, Çevir…) panodaki metinle çalışır.
ipcMain.handle('chat:clipboard', async () => (await clipboard.readText()).slice(0, 8000));
ipcMain.on('set-sound', (_e, on) => { store.set({ sound: Boolean(on) }); applySettings(); });
ipcMain.on('media-command', (_e, cmd) => media?.command(String(cmd)));
ipcMain.handle('notes:list', () => notes.list());
ipcMain.handle('notes:add', (_e, text) => notes.add(String(text || '')));
ipcMain.handle('notes:update', (_e, id, patch) => notes.update(String(id), patch && typeof patch === 'object' ? patch : {}));
ipcMain.handle('notes:remove', (_e, id) => notes.remove(String(id)));
ipcMain.handle('notes:clear-done', () => notes.clearDone());
ipcMain.handle('notes:set', (_e, lines) => notes.set(lines));
// ---------- odak koruması ----------
let focusRunning = false, guardWin = null, guard = null;
ipcMain.on('focus-state', (_e, on) => { focusRunning = Boolean(on); });
ipcMain.handle('guard:stats', () => guard?.todayStats() || { back: 0, open: 0 });
function mascotImageData(kind) {
  if (!kind.startsWith('custom:')) return '';
  const f = mascotFile(kind.slice(7)); if (!f) return '';
  return `data:${MASCOT_EXT[path.extname(f).toLowerCase()]};base64,${fs.readFileSync(f).toString('base64')}`;
}
function showGuard({ name }) {
  if (guardWin && !guardWin.isDestroyed()) return;
  const { bounds } = screen.getPrimaryDisplay();
  guardWin = new BrowserWindow({
    ...bounds, frame: false, transparent: true, resizable: false, movable: false, skipTaskbar: true, alwaysOnTop: true,
    fullscreenable: false, minimizable: false, maximizable: false, backgroundColor: '#00000000', title: 'Odak koruması', show: false,
    webPreferences: { preload: path.join(__dirname, 'guard', 'guard-preload.js'), contextIsolation: true, sandbox: true, nodeIntegration: false },
  });
  guardWin.setAlwaysOnTop(true, 'screen-saver');
  guardWin.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  guardWin.webContents.on('will-navigate', e => e.preventDefault());
  watchConsole(guardWin, 'guard');
  guardWin.loadFile(path.join(__dirname, 'guard', 'guard.html'));
  guardWin.once('ready-to-show', () => {
    const s = store.get();
    guardWin.webContents.send('guard:show', { uiLang: uiLang(), name, kind: s.mascotKind, palette: s.palette, image: mascotImageData(s.mascotKind), snoozeMin: s.focusGuard.snoozeMin, back: guard.todayStats().back });
    guardWin.show(); guardWin.focus();
  });
  // Ekran bir şekilde kapanırsa "geri dön" sayılmaz, sadece kapanır.
  guardWin.on('closed', () => { guardWin = null; if (guard.isShowing()) guard.answer('open'); });
}
// Ayarlardaki "Dene": aynı ekran, ama arkada gerçek bir pencere yok (hiçbir şey küçültülmez, sayılmaz).
ipcMain.on('guard:try', () => showGuard({ name: 'YouTube' }));
ipcMain.on('guard:answer', (_e, choice) => {
  const shown = guard.answer(choice);
  if (shown && choice === 'back') media?.command(`minimize ${shown.front.hwnd}`);
  if (guardWin && !guardWin.isDestroyed()) guardWin.close();
  send('guard-stats', guard.todayStats());
});

// Ada maskotunu çizip gönderiyor; tepsi ve pencere ikonu artık logo olduğu için şimdilik kullanılmıyor.
ipcMain.on('icon', () => {});

// Nackles zaten açıkken tekrar başlatılırsa ayarları aç.
app.on('second-instance', () => { if (store) openSettings(); });
app.on('will-quit', () => { globalShortcut.unregisterAll(); geminiWeb?.close(); hub?.stop(); media?.stop(); codexWatch?.stop(); chat?.stopAll(); clips?.stop(); });
app.on('window-all-closed', () => app.quit());
