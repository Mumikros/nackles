// Dosya tepsisi: adaya bırakılan dosyaların yerini (yolunu) hatırlar. Dosyaları kopyalamaz ya da taşımaz;
// tepsiden çıkarmak dosyayı silmez. Liste userData/shelf.json'da durur.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const MAX_FILES = 40;

function createShelf(userData) {
  const file = path.join(userData, 'shelf.json');
  let files = [];
  try { const s = JSON.parse(fs.readFileSync(file, 'utf8')); if (Array.isArray(s)) files = s.filter(f => f && typeof f.path === 'string'); } catch {}

  function save() {
    fs.mkdirSync(userData, { recursive: true });
    fs.writeFileSync(file + '.tmp', JSON.stringify(files, null, 1));
    fs.renameSync(file + '.tmp', file);
  }
  // Silinmiş ya da taşınmış dosyalar listeden düşer.
  function list() {
    const before = files.length;
    files = files.filter(f => fs.existsSync(f.path));
    if (files.length !== before) save();
    return files.map(f => {
      let size = 0, dir = false;
      try { const st = fs.statSync(f.path); size = st.size; dir = st.isDirectory(); } catch {}
      return { ...f, name: path.basename(f.path), size, dir };
    });
  }
  function add(paths) {
    for (const p of [].concat(paths)) {
      if (typeof p !== 'string' || !path.isAbsolute(p) || !fs.existsSync(p)) continue;
      files = files.filter(f => f.path.toLowerCase() !== p.toLowerCase());
      files.unshift({ id: crypto.randomUUID(), path: p, at: Date.now() });
    }
    files = files.slice(0, MAX_FILES);
    save();
    return list();
  }
  function remove(id) { files = files.filter(f => f.id !== id); save(); return list(); }
  function clear() { files = []; save(); return list(); }
  const get = id => files.find(f => f.id === id) || null;

  return { list, add, remove, clear, get };
}

module.exports = { createShelf, MAX_FILES };
