# Nackles müzik köprüsü: Windows'un medya kontrolünü (Spotify, tarayıcı, Groove... Windows'un "şu an çalıyor"
# kutusuna düşen her şey) okur. Her saniye bir JSON satırı yazar; stdin'den komut okur:
#   toggle | next | prev
# Ağa hiçbir şey göndermez.
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
Add-Type -AssemblyName System.Runtime.WindowsRuntime

$asTaskGeneric = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
  $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
} | Select-Object -First 1
function Await($op, [Type]$type) {
  $task = $asTaskGeneric.MakeGenericMethod($type).Invoke($null, @($op))
  $task.Wait(3000) | Out-Null
  $task.Result
}

[Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType = WindowsRuntime] | Out-Null
[Windows.Storage.Streams.IRandomAccessStreamWithContentType, Windows.Storage.Streams, ContentType = WindowsRuntime] | Out-Null
$managerType = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]
$propsType = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties]
$manager = Await ($managerType::RequestAsync()) $managerType

function Get-Art($props) {
  if (-not $props.Thumbnail) { return '' }
  try {
    $stream = Await ($props.Thumbnail.OpenReadAsync()) ([Windows.Storage.Streams.IRandomAccessStreamWithContentType])
    $net = [System.IO.WindowsRuntimeStreamExtensions]::AsStreamForRead($stream)
    $ms = New-Object System.IO.MemoryStream
    $net.CopyTo($ms)
    $type = if ($stream.ContentType) { $stream.ContentType } else { 'image/png' }
    $data = "data:$type;base64," + [Convert]::ToBase64String($ms.ToArray())
    $net.Dispose(); $ms.Dispose()
    return $data
  } catch { return '' }
}

# [Console]::In'in ReadLineAsync'i aslında bekletir; ayrı bir StreamReader gerçekten arka planda okur.
$stdin = New-Object System.IO.StreamReader([Console]::OpenStandardInput())
$pending = $stdin.ReadLineAsync()
$lastKey = ''
$art = ''

while ($true) {
  $session = $null
  try { $session = $manager.GetCurrentSession() } catch {}

  # Komutlar
  while ($pending.IsCompleted) {
    $cmd = $pending.Result
    if ($null -eq $cmd) { exit 0 } # Nackles kapandı
    if ($session) {
      try {
        switch ($cmd.Trim()) {
          'toggle' { Await ($session.TryTogglePlayPauseAsync()) ([bool]) | Out-Null }
          'next' { Await ($session.TrySkipNextAsync()) ([bool]) | Out-Null }
          'prev' { Await ($session.TrySkipPreviousAsync()) ([bool]) | Out-Null }
        }
      } catch {}
    }
    $pending = $stdin.ReadLineAsync()
  }

  $out = @{ active = $false }
  if ($session) {
    try {
      $props = Await ($session.TryGetMediaPropertiesAsync()) $propsType
      $info = $session.GetPlaybackInfo()
      $tl = $session.GetTimelineProperties()
      $key = "$($session.SourceAppUserModelId)|$($props.Title)|$($props.Artist)"
      $sendArt = $false
      if ($key -ne $lastKey) { $art = Get-Art $props; $lastKey = $key; $sendArt = $true }
      $out = @{
        active   = $true
        app      = $session.SourceAppUserModelId
        title    = $props.Title
        artist   = $props.Artist
        album    = $props.AlbumTitle
        playing  = ($info.PlaybackStatus.ToString() -eq 'Playing')
        position = $tl.Position.TotalSeconds
        duration = ($tl.EndTime - $tl.StartTime).TotalSeconds
        updated  = [DateTimeOffset]::new($tl.LastUpdatedTime).ToUnixTimeMilliseconds()
        canNext  = $info.Controls.IsNextEnabled
        canPrev  = $info.Controls.IsPreviousEnabled
      }
      # Kapak resmi büyük olabilir: sadece parça değişince gönderilir.
      if ($sendArt) { $out.art = $art }
    } catch { $out = @{ active = $false } }
  }
  [Console]::Out.WriteLine(($out | ConvertTo-Json -Compress))
  [Console]::Out.Flush()
  Start-Sleep -Milliseconds 900
}
