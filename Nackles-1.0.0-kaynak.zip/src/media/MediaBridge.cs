// Nackles yardımcısı (media.ps1'in hafif hâli). Her saniye bir JSON satırı yazar:
//  - Windows'un medya kontrolü: çalan parça, kapak, oynatma durumu
//  - Öndeki pencere ekranın üst ortasını kaplıyor mu ("cover"): kaplıyorsa ada içeri girer
// stdin'den toggle | next | prev komutlarını alır. Ağa hiçbir şey göndermez.
// Windows'la gelen .NET Framework derleyicisiyle (csc.exe) ilk açılışta derlenir.
using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Windows.Media.Control;
using Windows.Storage.Streams;

static class MediaBridge
{
    [StructLayout(LayoutKind.Sequential)] struct RECT { public int L, T, R, B; }
    [StructLayout(LayoutKind.Sequential)] struct MONITORINFO { public int cbSize; public RECT rcMonitor, rcWork; public int dwFlags; }
    [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder s, int n);
    [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
    [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
    [DllImport("user32.dll")] static extern IntPtr MonitorFromWindow(IntPtr h, uint flags);
    [DllImport("user32.dll")] static extern IntPtr MonitorFromPoint(POINT p, uint flags);
    [DllImport("user32.dll")] static extern bool GetMonitorInfo(IntPtr m, ref MONITORINFO mi);
    [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
    [StructLayout(LayoutKind.Sequential)] struct POINT { public int X, Y; }

    // Öndeki pencere birincil ekranın üst ortasını (adanın durduğu yeri) kaplıyor mu?
    // Masaüstü, görev çubuğu, simge durumundaki pencereler ve Nackles'ın kendi pencereleri sayılmaz.
    // Nackles'ın kendi penceresi öne gelirse (adaya tıklanınca) karar değişmez: son gerçek pencereye bakmaya devam edilir.
    static IntPtr lastOther = IntPtr.Zero;
    static bool Covered(uint ownPid)
    {
        try
        {
            var h = GetForegroundWindow();
            uint pid; GetWindowThreadProcessId(h, out pid);
            if (pid == ownPid) h = lastOther; else lastOther = h;
            if (h == IntPtr.Zero || !IsWindowVisible(h) || IsIconic(h)) return false;
            var cls = new StringBuilder(64); GetClassName(h, cls, 64);
            var c = cls.ToString();
            if (c == "Progman" || c == "WorkerW" || c == "Shell_TrayWnd" || c == "Shell_SecondaryTrayWnd") return false;
            var primary = MonitorFromPoint(new POINT { X = 0, Y = 0 }, 1);
            if (MonitorFromWindow(h, 2) != primary) return false;
            var mi = new MONITORINFO { cbSize = Marshal.SizeOf(typeof(MONITORINFO)) };
            GetMonitorInfo(primary, ref mi);
            RECT r; GetWindowRect(h, out r);
            int cx = (mi.rcMonitor.L + mi.rcMonitor.R) / 2;
            // Pencerenin üst kenarı ekranın en üstüne yakınsa ve ortayı geçiyorsa ada onun üstünde kalır.
            return r.T <= mi.rcMonitor.T + 12 && r.L < cx - 60 && r.R > cx + 60;
        }
        catch { return false; }
    }

    // Odak koruması için: öndeki pencerenin başlığı ve programı (sadece anlık okunur, saklanmaz).
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
    [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr h, int cmd);
    static readonly System.Collections.Generic.Dictionary<uint, string> procNames = new System.Collections.Generic.Dictionary<uint, string>();
    static string Front(uint ownPid)
    {
        try
        {
            var h = GetForegroundWindow();
            uint pid; GetWindowThreadProcessId(h, out pid);
            if (h == IntPtr.Zero || pid == ownPid) return null;
            string proc;
            if (!procNames.TryGetValue(pid, out proc))
            {
                try { proc = System.Diagnostics.Process.GetProcessById((int)pid).ProcessName; } catch { proc = ""; }
                if (procNames.Count > 200) procNames.Clear();
                procNames[pid] = proc;
            }
            var t = new StringBuilder(300); GetWindowText(h, t, 300);
            return "{\"hwnd\":" + h.ToInt64() + ",\"proc\":\"" + Esc(proc) + "\",\"title\":\"" + Esc(t.ToString()) + "\"}";
        }
        catch { return null; }
    }

    static string Esc(string s)
    {
        if (s == null) return "";
        var b = new StringBuilder();
        foreach (var c in s)
        {
            if (c == '"' || c == '\\') { b.Append('\\').Append(c); }
            else if (c < 0x20) { b.AppendFormat("\\u{0:x4}", (int)c); }
            else b.Append(c);
        }
        return b.ToString();
    }

    // WinRT işlemini en fazla 3 sn bekler (System.Runtime.WindowsRuntime olmadan, durumunu yoklayarak).
    static T Wait<T>(Windows.Foundation.IAsyncOperation<T> op)
    {
        var until = DateTime.UtcNow.AddSeconds(3);
        while (op.Status == Windows.Foundation.AsyncStatus.Started && DateTime.UtcNow < until) Thread.Sleep(5);
        return op.Status == Windows.Foundation.AsyncStatus.Completed ? op.GetResults() : default(T);
    }

    static string Art(GlobalSystemMediaTransportControlsSessionMediaProperties p)
    {
        try
        {
            if (p.Thumbnail == null) return "";
            var stream = Wait(p.Thumbnail.OpenReadAsync());
            if (stream == null || stream.Size == 0 || stream.Size > 4000000) return "";
            var size = (uint)stream.Size;
            var reader = new DataReader(stream.GetInputStreamAt(0));
            if (Wait(reader.LoadAsync(size)) != size) return "";
            var bytes = new byte[size];
            reader.ReadBytes(bytes);
            var type = string.IsNullOrEmpty(stream.ContentType) ? "image/png" : stream.ContentType;
            return "data:" + type + ";base64," + Convert.ToBase64String(bytes);
        }
        catch { return ""; }
    }

    static void Main(string[] args)
    {
        SetProcessDPIAware();
        Console.OutputEncoding = new UTF8Encoding(false);
        uint ownPid = 0; if (args.Length > 0) uint.TryParse(args[0], out ownPid);
        var manager = Wait(GlobalSystemMediaTransportControlsSessionManager.RequestAsync());
        string pending = null; var gate = new object();
        // Komutlar ayrı bir iş parçacığında okunur; stdin kapanınca (Nackles kapandı) çıkılır.
        new Thread(() =>
        {
            string line;
            while ((line = Console.In.ReadLine()) != null) lock (gate) pending = line.Trim();
            Environment.Exit(0);
        }) { IsBackground = true }.Start();

        string lastKey = null;
        while (true)
        {
            GlobalSystemMediaTransportControlsSession session = null;
            try { session = manager != null ? manager.GetCurrentSession() : null; } catch { }

            string cmd; lock (gate) { cmd = pending; pending = null; }
            // Odak koruması "geri dön" dediğinde dikkat dağıtan pencere simge durumuna küçültülür.
            if (cmd != null && cmd.StartsWith("minimize "))
            {
                long hw; if (long.TryParse(cmd.Substring(9), out hw)) ShowWindow(new IntPtr(hw), 6);
                cmd = null;
            }
            if (cmd != null && session != null)
            {
                try
                {
                    if (cmd == "toggle") Wait(session.TryTogglePlayPauseAsync());
                    else if (cmd == "next") Wait(session.TrySkipNextAsync());
                    else if (cmd == "prev") Wait(session.TrySkipPreviousAsync());
                }
                catch { }
            }

            string json = "{\"active\":false}";
            if (session != null)
            {
                try
                {
                    var p = Wait(session.TryGetMediaPropertiesAsync());
                    var info = session.GetPlaybackInfo();
                    var tl = session.GetTimelineProperties();
                    var key = session.SourceAppUserModelId + "|" + (p != null ? p.Title : "") + "|" + (p != null ? p.Artist : "");
                    var sb = new StringBuilder("{\"active\":true");
                    sb.Append(",\"app\":\"").Append(Esc(session.SourceAppUserModelId)).Append('"');
                    sb.Append(",\"title\":\"").Append(Esc(p != null ? p.Title : "")).Append('"');
                    sb.Append(",\"artist\":\"").Append(Esc(p != null ? p.Artist : "")).Append('"');
                    sb.Append(",\"album\":\"").Append(Esc(p != null ? p.AlbumTitle : "")).Append('"');
                    sb.Append(",\"playing\":").Append(info.PlaybackStatus == GlobalSystemMediaTransportControlsSessionPlaybackStatus.Playing ? "true" : "false");
                    sb.Append(",\"position\":").Append(tl.Position.TotalSeconds.ToString(System.Globalization.CultureInfo.InvariantCulture));
                    sb.Append(",\"duration\":").Append((tl.EndTime - tl.StartTime).TotalSeconds.ToString(System.Globalization.CultureInfo.InvariantCulture));
                    sb.Append(",\"updated\":").Append(tl.LastUpdatedTime.ToUnixTimeMilliseconds());
                    sb.Append(",\"canNext\":").Append(info.Controls.IsNextEnabled ? "true" : "false");
                    sb.Append(",\"canPrev\":").Append(info.Controls.IsPreviousEnabled ? "true" : "false");
                    // Kapak resmi sadece parça değişince gönderilir.
                    if (key != lastKey && p != null) { sb.Append(",\"art\":\"").Append(Art(p)).Append('"'); lastKey = key; }
                    sb.Append('}');
                    json = sb.ToString();
                }
                catch { json = "{\"active\":false}"; }
            }
            var front = Front(ownPid);
            json = json.Substring(0, json.Length - 1) + ",\"cover\":" + (Covered(ownPid) ? "true" : "false") + (front != null ? ",\"front\":" + front : "") + "}";
            Console.Out.WriteLine(json);
            Console.Out.Flush();
            Thread.Sleep(450);
        }
    }
}
