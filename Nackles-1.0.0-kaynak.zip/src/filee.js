// Filee entegrasyonu (https://github.com/KnifeLemon/Filee, MIT): bilgisayarda kurulu Filee'nin komut satırı aracıyla
// tepsideki dosyaları başka biçime dönüştürür. Dönüştürme tamamen yerelde olur; sonuç asıl dosyanın yanına kaydedilir.
const { execFile, execFileSync } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');

// Seçicide önce gösterilecek yaygın biçimler (Filee'nin desteklediği sırayla değil, bu sırayla).
const POPULAR = ['jpg', 'png', 'webp', 'pdf', 'docx', 'txt', 'md', 'html', 'mp4', 'mp3', 'gif', 'ico', 'xlsx', 'csv', 'pptx', 'epub', 'svg', 'zip', 'wav', 'avif'];

function findFilee() {
  const candidates = [
    path.join(process.env.ProgramFiles || 'C:\\Program Files', 'Filee', 'filee-cli.exe'),
    path.join(process.env.LOCALAPPDATA || '', 'Programs', 'Filee', 'filee-cli.exe'),
  ];
  try {
    const cmd = execFileSync('where.exe', ['filee.cmd'], { encoding: 'utf8', windowsHide: true, stdio: ['ignore', 'pipe', 'ignore'] }).split(/\r?\n/)[0].trim();
    if (cmd) candidates.unshift(path.join(path.dirname(cmd), '..', 'filee-cli.exe'));
  } catch {}
  return candidates.find(p => { try { return fs.statSync(p).isFile(); } catch { return false; } }) || null;
}

// "filee formats png" çıktısını okur: ilk liste hemen kullanılabilenler, ikincisi ek motor isteyenler.
function parseFormats(text) {
  const lists = [];
  const lines = String(text).split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    if (/converts to:|With optional engines/i.test(lines[i]) && lines[i + 1]) lists.push(lines[i + 1].split(',').map(s => s.trim().toLowerCase()).filter(s => /^[a-z0-9_]+$/.test(s)));
  }
  return { ready: lists[0] || [], optional: lists[1] || [] };
}

function sortPopular(list) {
  const rank = f => { const i = POPULAR.indexOf(f); return i < 0 ? 999 : i; };
  return [...list].sort((a, b) => rank(a) - rank(b));
}

// Seçili dosyaların türüne göre sunulacak birleştirme seçenekleri (Filee hazır ayarları).
const KINDS = {
  pdf: ['pdf'],
  image: ['png', 'jpg', 'jpeg', 'webp', 'gif', 'bmp', 'tiff', 'tif', 'heic', 'avif', 'jxl', 'ico'],
  video: ['mp4', 'mov', 'mkv', 'webm', 'avi', 'm4v', 'wmv', 'flv'],
  audio: ['mp3', 'm4a', 'wav', 'flac', 'ogg', 'opus', 'aac', 'wma'],
};
function mergeOptions(paths) {
  const kinds = new Set(paths.map(p => { const e = path.extname(p).slice(1).toLowerCase(); return Object.keys(KINDS).find(k => KINDS[k].includes(e)) || 'other'; }));
  const only = kinds.size === 1 ? [...kinds][0] : null;
  const out = [];
  if (only === 'pdf') out.push({ preset: 'merge-pdf', label: 'PDF\'leri birleştir' });
  if (only === 'image') out.push({ preset: 'merge-images', label: 'Resimleri birleştir' }, { preset: 'video-from-images', label: 'Resimlerden video' });
  if (only === 'video') out.push({ preset: 'merge-videos', label: 'Videoları birleştir' });
  if (only === 'audio') out.push({ preset: 'merge-audio', label: 'Sesleri birleştir' });
  out.push({ preset: 'zip-all', label: 'Tek ZIP yap' });
  return out;
}

function createFilee({ log = () => {} } = {}) {
  let exe; const cache = new Map();
  const tool = () => (exe === undefined ? (exe = findFilee()) : exe);

  function run(args, timeout) {
    return new Promise(resolve => {
      execFile(tool(), args, { windowsHide: true, timeout, maxBuffer: 4 * 1024 * 1024, encoding: 'utf8' },
        (err, stdout, stderr) => resolve({ code: err ? (typeof err.code === 'number' ? err.code : 1) : 0, stdout, stderr, killed: err?.killed }));
    });
  }

  async function targets(file) {
    if (!tool()) return null;
    const ext = path.extname(file).slice(1).toLowerCase();
    if (!ext) return { ready: [], optional: [] };
    if (!cache.has(ext)) {
      const r = await run(['formats', ext], 20000);
      const f = parseFormats(r.stdout);
      cache.set(ext, { ready: sortPopular(f.ready), optional: f.optional });
    }
    return cache.get(ext);
  }

  // Bir ya da birden çok dosyayı dönüştürür: { to: 'jpg' } ya da { preset: 'merge-pdf' }.
  // Birleştirme hazır ayarları dosyaları verilen sırayla tek dosyada toplar.
  async function convert(files, { to, preset } = {}) {
    files = [].concat(files);
    if (!tool()) return { ok: false, error: 'Filee bulunamadı.', outputs: [] };
    const arg = to ? ['--to', to] : ['--preset', preset];
    if (!/^[a-z0-9_-]+$/i.test(arg[1] || '')) return { ok: false, error: 'Geçersiz biçim.', outputs: [] };
    const r = await run(['convert', ...files, ...arg, '--json'], 15 * 60 * 1000);
    let res; try { res = JSON.parse(r.stdout); } catch {}
    const outputs = (res?.files || []).flatMap(f => f.outputs || []);
    const errors = (res?.files || []).filter(f => f.state === 'failed').map(f => f.error).filter(Boolean);
    if (outputs.length && !errors.length) return { ok: true, outputs };
    let error = errors[0] || (r.killed ? 'İşlem çok uzun sürdü.' : String(r.stderr || r.stdout || 'Dönüştürülemedi.').trim().slice(0, 300));
    // Filee çok uzun klasör yollarında yanıltıcı bir "yer yok" hatası veriyor.
    if (/Not enough space/i.test(error) && files.some(f => f.length > 200)) error = 'Dosyanın klasör yolu çok uzun; dosyayı daha kısa bir yola taşıyıp tekrar dene.';
    log('filee', arg.join(' '), error);
    return { ok: outputs.length > 0, partial: outputs.length > 0, error, outputs };
  }

  return { available: () => Boolean(tool()), targets, convert };
}

module.exports = { createFilee, parseFormats, sortPopular, mergeOptions };
