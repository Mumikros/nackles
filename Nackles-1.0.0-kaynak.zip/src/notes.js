// Hızlı notlar: userData/notes.json içinde, sadece bu bilgisayarda tutulur.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const MAX_NOTES = 50, MAX_LEN = 500;

function createNotes(userData) {
  const file = path.join(userData, 'notes.json');
  let notes = [];
  try {
    const saved = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (Array.isArray(saved)) notes = saved.filter(n => n && typeof n.text === 'string').map(clean);
  } catch {}

  // task: satır işaret yuvarlaklı bir yapılacak mı (not defterinde "[ ]" ile başlar)
  function clean(n) { return { id: String(n.id || crypto.randomUUID()), text: String(n.text).slice(0, MAX_LEN), task: Boolean(n.task), done: Boolean(n.done), at: Number(n.at) || Date.now() }; }
  function save() {
    fs.mkdirSync(userData, { recursive: true });
    fs.writeFileSync(file + '.tmp', JSON.stringify(notes, null, 1));
    fs.renameSync(file + '.tmp', file);
    return list();
  }
  function list() { return notes.map(n => ({ ...n })); }

  function add(text) {
    text = String(text || '').trim();
    if (!text) return list();
    notes.unshift(clean({ text }));
    notes = notes.slice(0, MAX_NOTES);
    return save();
  }
  function update(id, patch = {}) {
    const n = notes.find(x => x.id === id); if (!n) return list();
    if (typeof patch.text === 'string') { const t = patch.text.trim(); if (!t) return remove(id); n.text = t.slice(0, MAX_LEN); }
    if (typeof patch.done === 'boolean') n.done = patch.done;
    return save();
  }
  function remove(id) { notes = notes.filter(n => n.id !== id); return save(); }
  function clearDone() { notes = notes.filter(n => !n.done); return save(); }
  // Not defteri tüm satırları birlikte kaydeder (sıra korunur, sondaki boş satırlar atılır).
  function set(lines) {
    if (!Array.isArray(lines)) return list();
    const kept = lines.filter(n => n && typeof n.text === 'string').slice(0, 200).map(clean);
    while (kept.length && !kept[kept.length - 1].text.trim() && !kept[kept.length - 1].task) kept.pop();
    notes = kept;
    return save();
  }

  return { list, add, update, remove, clearDone, set };
}

module.exports = { createNotes, MAX_NOTES, MAX_LEN };
