// Odak koruması ekranı: bir nefes boyunca (8 sn) bekletir; "Geri dön" hemen, "Yine de aç" nefesten sonra seçilebilir.
const $ = s => document.querySelector(s);
const api = window.guard;
let mascot = null;

api.onShow(async d => {
  NacklesI18n.setLang(d.uiLang);
  const c = NacklesMascot.colorsFor(d.kind.startsWith('custom:') ? 'glitch' : d.kind, d.palette);
  document.documentElement.style.setProperty('--accent', c.eye);
  mascot = NacklesMascot.mount($('.mascot-box'), { kind: d.kind, palette: d.palette, custom: d.image ? { image: d.image } : null });
  mascot.classList.remove('mood-normal'); mascot.classList.add('mood-wow');
  $('.t').textContent = `${d.name} açıyorsun.`;
  $('.open').textContent = `Yine de aç (${d.snoozeMin} dk)`;
  $('.note').textContent = d.back ? `Bugün ${d.back} kez odağına geri döndün.` : '';
  document.body.classList.add('breathing');
  // Nefes al / ver yazısı halkayla birlikte değişir
  let inhale = true;
  $('.phase').textContent = 'Nefes al';
  setTimeout(() => { mascot.classList.replace('mood-wow', 'mood-normal'); }, 1500);
  const tick = setInterval(() => { inhale = !inhale; $('.phase').textContent = inhale ? 'Nefes al' : 'Nefes ver'; }, 4000);
  setTimeout(() => { $('.open').disabled = false; }, 8000);
  window.addEventListener('beforeunload', () => clearInterval(tick));
  $('.back').focus();
});

function choose(choice) {
  if (choice === 'back' && mascot) { mascot.classList.remove('mood-normal', 'mood-wow'); mascot.classList.add('mood-happy', 'dance'); }
  $('.btns').style.pointerEvents = 'none';
  setTimeout(() => api.answer(choice), choice === 'back' ? 650 : 0);
}
$('.back').addEventListener('click', () => choose('back'));
$('.open').addEventListener('click', () => { if (!$('.open').disabled) choose('open'); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') choose('back'); });
