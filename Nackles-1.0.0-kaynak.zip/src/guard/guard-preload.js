const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('guard', {
  onShow: cb => ipcRenderer.on('guard:show', (_e, d) => cb(d)),
  answer: choice => ipcRenderer.send('guard:answer', choice === 'open' ? 'open' : 'back'),
});
