const api = window.nacklesSettings;
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];

const STATE_NAMES = { claude: ['Claude tonu', 'Claude çalışıyor'], codex: ['Codex tonu', 'Codex çalışıyor'], question: ['Seni bekliyor', 'İzin istiyor'], done: ['Bitti', 'İş bitti'], error: ['Hata', 'Bir şey ters gitti'] };
const DEFAULT_COLORS = { claude: '#E07A4F', codex: '#6C8CFF', question: '#FFD050', done: '#4FDB7D', error: '#FF5C5C' };

let info = null;

// ---------- maskotlar ----------
let brand = NacklesMascot.mount($('#brand-mascot'));
let stage = NacklesMascot.mount($('#stage-mascot'));
let about = NacklesMascot.mount($('#about-mascot'));
let mascots = [brand, stage, about];

// ---------- maskot ve palet seçimi ----------
const imageCache = {};
async function mascotOpts(kind, palette) {
  if (!kind.startsWith('custom:')) return { kind, palette };
  const id = kind.slice(7);
  imageCache[id] ??= await api.mascotImage(id);
  return { kind, palette, custom: { image: imageCache[id] } };
}
let shownMascot = '';
async function showMascot(s) {
  const key = s.mascotKind + '|' + s.palette;
  if (key === shownMascot) return;
  shownMascot = key;
  const o = await mascotOpts(s.mascotKind, s.palette);
  brand = NacklesMascot.mount($('#brand-mascot'), o);
  stage = NacklesMascot.mount($('#stage-mascot'), o);
  about = NacklesMascot.mount($('#about-mascot'), o);
  mascots = [brand, stage, about];
  const c = NacklesMascot.colorsFor(o.custom ? 'glitch' : s.mascotKind, s.palette);
  document.documentElement.style.setProperty('--accent', c.eye);
  $('.robot-only').style.display = s.mascotKind === 'robot' ? '' : 'none';
}
async function renderPickers(s) {
  const grid = $('#kind-grid');
  const kinds = [...Object.entries(NacklesMascot.KINDS).map(([k, v]) => ({ kind: k, name: v.name })),
    ...s.customMascots.map(m => ({ kind: 'custom:' + m.id, name: m.name, id: m.id }))];
  const tiles = [];
  for (const k of kinds) {
    const b = document.createElement('button');
    b.className = 'pick' + (s.mascotKind === k.kind ? ' on' : '');
    b.innerHTML = NacklesMascot.svg(await mascotOpts(k.kind, s.palette));
    const label = document.createElement('span'); label.textContent = k.name; b.append(label);
    b.addEventListener('click', () => save({ mascotKind: k.kind }));
    if (k.id) {
      const x = document.createElement('span'); x.className = 'pick-x'; x.textContent = '×'; x.title = 'Bu maskotu sil';
      x.addEventListener('click', async e => { e.stopPropagation(); delete imageCache[k.id]; render(await api.removeMascot(k.id)); });
      b.append(x);
    }
    tiles.push(b);
  }
  const add = document.createElement('button');
  add.className = 'pick add';
  add.innerHTML = '<span class="plus">+</span><span>Kendi resmini ekle</span>';
  add.title = 'PNG, JPG, GIF, WebP ya da SVG · en fazla 3 MB';
  add.addEventListener('click', async () => { const r = await api.addMascot(); if (r.ok) render(r.info); else if (r.error) alert(r.error); });
  tiles.push(add);
  grid.replaceChildren(...tiles);

  const pal = $('#pal-grid');
  const pals = [['auto', 'Otomatik', NacklesMascot.colorsFor(s.mascotKind.startsWith('custom:') ? 'glitch' : s.mascotKind, 'auto')],
    ...Object.entries(NacklesMascot.PALETTES).map(([k, v]) => [k, v.name, v])];
  pal.replaceChildren(...pals.map(([k, name, c]) => {
    const b = document.createElement('button');
    b.className = 'pal' + (s.palette === k ? ' on' : '');
    // Satır içi style özniteliği CSP'ye takılır; renkler doğrudan stil nesnesine yazılır.
    const sw = document.createElement('span'); sw.className = 'sw';
    for (const [bg, border] of [[c.body, c.line], [c.line], [c.eye]]) { const i = document.createElement('i'); i.style.background = bg; if (border) i.style.borderColor = border; sw.append(i); }
    b.append(sw);
    const label = document.createElement('span'); label.textContent = name; b.append(label);
    b.addEventListener('click', () => save({ palette: k }));
    return b;
  }));
}

function blink() {
  for (const m of mascots) m.classList.add('blink');
  setTimeout(() => mascots.forEach(m => m.classList.remove('blink')), 130);
  setTimeout(blink, 2200 + Math.random() * 4000);
}
setTimeout(blink, 1200);

function setMood(mood) {
  for (const c of [...stage.classList]) if (c.startsWith('mood-')) stage.classList.remove(c);
  stage.classList.add('mood-' + mood);
  stage.classList.toggle('dizzy', mood === 'dizzy');
  $('#stage-mascot').classList.toggle('sleeping', mood === 'sleepy');
  $$('#moods [data-mood]').forEach(b => b.classList.toggle('active', b.dataset.mood === mood));
}
$$('#moods [data-mood]').forEach(b => b.addEventListener('click', () => setMood(b.dataset.mood)));
$('#dance').addEventListener('click', () => {
  stage.classList.remove('dance'); void stage.getBBox(); stage.classList.add('dance');
  setTimeout(() => stage.classList.remove('dance'), 3000);
});
$('#stage-mascot').addEventListener('click', () => { stage.classList.remove('squish'); void stage.getBBox(); stage.classList.add('squish'); setTimeout(() => stage.classList.remove('squish'), 320); });

// ---------- sayfalar ----------
function show(page) {
  $$('.nav').forEach(n => n.classList.toggle('active', n.dataset.page === page));
  $$('.page').forEach(p => p.classList.toggle('active', p.id === 'page-' + page));
}
$$('.nav').forEach(n => n.addEventListener('click', () => show(n.dataset.page)));

// ---------- durum renkleri ----------
function buildSwatches() {
  const box = $('#state-colors');
  for (const [key, [name, sample]] of Object.entries(STATE_NAMES)) {
    const row = document.createElement('div'); row.className = 'swatch';
    const mini = document.createElement('div'); mini.className = 'mini'; mini.dataset.state = key;
    const mi = document.createElement('span'); mi.className = 'mi';
    const label = document.createElement('span'); label.textContent = sample;
    const me = document.createElement('span'); me.className = 'me'; me.append(document.createElement('i'), document.createElement('i'));
    mini.append(mi, label, me);
    const n = document.createElement('span'); n.className = 'swatch-name'; n.textContent = name;
    const input = document.createElement('input'); input.type = 'color'; input.className = 'color'; input.dataset.color = key;
    row.append(mini, n, input);
    box.append(row);
  }
}
buildSwatches();

// ---------- kayıt ----------
let pending = {}, saveTimer = null;
function save(patch, wait = 0) {
  for (const [k, v] of Object.entries(patch)) {
    pending[k] = (k === 'colors' || k === 'mascot' || k === 'focusGuard') ? { ...(pending[k] || {}), ...v } : v;
  }
  clearTimeout(saveTimer);
  saveTimer = setTimeout(async () => { const p = pending; pending = {}; render(await api.set(p)); }, wait);
}

$$('[data-key]').forEach(input => {
  const key = input.dataset.key;
  if (input.type === 'checkbox') input.addEventListener('change', () => save({ [key]: input.checked }));
  else if (input.type === 'text') input.addEventListener('input', () => { showName(input.value.trim() || 'Nackles'); save({ [key]: input.value }, 400); });
  else input.addEventListener('input', () => { paintRange(input); save({ [key]: Number(input.value) }, 150); });
});
$$('[data-mascot]').forEach(input => {
  const key = input.dataset.mascot;
  if (input.type === 'checkbox') input.addEventListener('change', () => save({ mascot: { [key]: input.checked } }));
});
$$('[data-color]').forEach(input => input.addEventListener('input', () => {
  input.closest('.swatch').querySelector('.mini').style.setProperty('--c', input.value);
  save({ colors: { [input.dataset.color]: input.value } }, 120);
}));

$('#openAtLogin').addEventListener('change', async e => render(await api.login(e.target.checked)));
$('#reset').addEventListener('click', async () => render(await api.reset()));
$('#reset-colors').addEventListener('click', () => save({ colors: DEFAULT_COLORS }));
$$('.status-card[data-agent]').forEach(card => card.querySelector('.conn-btn').addEventListener('click', async () => {
  const agent = card.dataset.agent;
  render(await api.connect(agent, !info.links[agent]));
}));
$$('[data-preview]').forEach(b => b.addEventListener('click', () => api.preview(b.dataset.preview)));

$('#guard-try').addEventListener('click', () => api.tryGuard());
$$('#lang-pick [data-lang]').forEach(b => b.addEventListener('click', () => save({ lang: b.dataset.lang })));

// ---------- odak koruması ----------
const GUARD_SITES = { youtube: 'YouTube', tiktok: 'TikTok', instagram: 'Instagram', x: 'X (Twitter)', reddit: 'Reddit', facebook: 'Facebook', netflix: 'Netflix', twitch: 'Twitch', discord: 'Discord' };
$$('[data-guard]').forEach(input => {
  const key = input.dataset.guard;
  if (input.type === 'checkbox') input.addEventListener('change', () => save({ focusGuard: { [key]: input.checked } }));
  else input.addEventListener('input', () => { paintRange(input); save({ focusGuard: { [key]: Number(input.value) } }, 150); });
});
function renderGuard(g) {
  const active = document.activeElement;
  $$('[data-guard]').forEach(input => {
    if (input === active && input.type === 'range') return;
    if (input.type === 'checkbox') input.checked = Boolean(g[input.dataset.guard]);
    else { input.value = g[input.dataset.guard]; paintRange(input); }
  });
  $('#site-grid').replaceChildren(...Object.entries(GUARD_SITES).map(([id, name]) => {
    const b = document.createElement('button');
    b.className = 'site' + (g.sites.includes(id) ? ' on' : '');
    b.textContent = name;
    b.addEventListener('click', () => save({ focusGuard: { sites: g.sites.includes(id) ? g.sites.filter(x => x !== id) : [...g.sites, id] } }));
    return b;
  }));
}

// Asistanın adı sayfadaki her yerde (başlık, marka, açıklamalar) yazarken güncellenir.
function showName(name) {
  for (const n of $$('.nm')) n.textContent = name;
  document.title = `${name} Ayarlar`;
}

function paintRange(input) {
  const p = ((input.value - input.min) / (input.max - input.min)) * 100;
  input.style.setProperty('--p', p + '%');
  if (input.dataset.key === 'volume') $('#vol-out').textContent = Math.round(input.value * 100) + '%';
  if (input.dataset.guard === 'snoozeMin') $('#snooze-out').textContent = input.value + ' dk';
  if (input.dataset.key === 'sleepAfterMin') $('#sleep-out').textContent = Number(input.value) === 0 ? 'Hiç' : input.value + ' dk';
}

// ---------- çizim ----------
function render(next) {
  info = next;
  const s = info.settings;
  // Kullanıcı sürüklerken değeri ezmeyelim.
  const active = document.activeElement;
  $$('[data-key]').forEach(input => {
    if (input === active && (input.type === 'range' || input.type === 'text')) return;
    if (input.type === 'checkbox') input.checked = Boolean(s[input.dataset.key]);
    else if (input.type === 'text') input.value = s[input.dataset.key];
    else { input.value = s[input.dataset.key]; paintRange(input); }
  });
  $$('[data-mascot]').forEach(input => {
    const v = s.mascot[input.dataset.mascot];
    if (input.type === 'checkbox') input.checked = v; else if (input !== active) input.value = v.toLowerCase();
  });
  $$('[data-color]').forEach(input => {
    const v = s.colors[input.dataset.color];
    if (input !== active) input.value = v.toLowerCase();
    input.closest('.swatch').querySelector('.mini').style.setProperty('--c', v);
  });
  showMascot(s).then(() => { for (const m of mascots) NacklesMascot.paint(m, s.mascot); });
  NacklesI18n.setLang(s.uiLang);
  for (const b of $$('#lang-pick [data-lang]')) b.classList.toggle('on', b.dataset.lang === s.lang);
  renderPickers(s);
  renderGuard(s.focusGuard);
  if (document.activeElement?.dataset?.key !== 'name') showName(s.name);

  $('#openAtLogin').checked = info.openAtLogin;
  $('#version').textContent = 'Sürüm ' + info.version;
  $('#version2').textContent = info.version;
  $('#open-data').onclick = () => api.openDataFolder();

  for (const card of $$('.status-card[data-agent]')) {
    const agent = card.dataset.agent, name = agent === 'codex' ? 'Codex' : 'Claude Code', on = info.links[agent];
    const missing = agent === 'codex' && !on && !info.links.codexAvailable;
    card.querySelector('.dot').className = 'dot' + (info.error ? ' err' : on ? ' on' : '');
    card.querySelector('.conn-title').textContent = info.error ? `${name}: bağlantı sunucusu çalışmıyor` : on ? `${name} bağlı` : `${name} bağlı değil`;
    card.querySelector('.conn-sub').textContent = info.error
      || (on && agent === 'codex' ? 'Codex sohbetleri izleniyor. Nackles, Codex\'in kayıt dosyalarını sadece okur.'
        : on ? `Yeni ${name} oturumları adada görünür.` : missing ? 'Bu bilgisayarda Codex bulunamadı. Yine de bağlayabilirsin.' : `Bağlanınca ${name}'in ne yaptığını adada görürsün.`);
    const btn = card.querySelector('.conn-btn');
    btn.textContent = on ? 'Bağlantıyı kaldır' : 'Bağlan';
    btn.className = 'btn conn-btn' + (on ? ' danger' : '');
  }
}

api.onInfo(render);
api.info().then(render);
