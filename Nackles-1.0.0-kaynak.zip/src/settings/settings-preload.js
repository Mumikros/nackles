const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('nacklesSettings', {
  info: () => ipcRenderer.invoke('settings:info'),
  set: patch => ipcRenderer.invoke('settings:set', patch),
  reset: () => ipcRenderer.invoke('settings:reset'),
  login: on => ipcRenderer.invoke('settings:login', on),
  connect: (agent, on) => ipcRenderer.invoke('settings:connect', agent, on),
  tryGuard: () => ipcRenderer.send('guard:try'),
  openDataFolder: () => ipcRenderer.send('open-data-folder'),
  addMascot: () => ipcRenderer.invoke('mascot:add'),
  removeMascot: id => ipcRenderer.invoke('mascot:remove', id),
  mascotImage: id => ipcRenderer.invoke('mascot:image', id),
  preview: kind => ipcRenderer.send('settings:preview', kind),
  onInfo: cb => ipcRenderer.on('info', (_e, v) => cb(v)),
});
