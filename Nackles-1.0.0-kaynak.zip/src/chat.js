// Adadaki metin sohbeti: kullanıcının hesabıyla resmî Claude Code ve Codex araçlarını çalıştırır.
// Gemini, gemini-web.js üzerinden kendi web arayüzünü kullanır.
const { spawn, execFileSync } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');

function findClaude() {
  // 1) PATH'teki claude  2) Claude masaüstü uygulamasıyla gelen claude.exe (en yeni sürüm)
  try { const p = execFileSync('where.exe', ['claude.exe'], { encoding: 'utf8', windowsHide: true, stdio: ['ignore', 'pipe', 'ignore'] }).split(/\r?\n/)[0].trim(); if (p) return p; } catch {}
  const root = path.join(process.env.APPDATA || '', 'Claude', 'claude-code');
  let best = null;
  try {
    for (const ver of fs.readdirSync(root)) for (const h of fs.readdirSync(path.join(root, ver))) {
      const exe = path.join(root, ver, h, 'claude.exe');
      try { const t = fs.statSync(exe).mtimeMs; if (!best || t > best.t) best = { exe, t }; } catch {}
    }
  } catch {}
  return best?.exe || null;
}

function findCodex() {
  // Önce Codex masaüstü uygulamasının kendi codex.exe'si (uygulamanın kullandığı modelleri tanır),
  // yoksa PATH'teki codex.
  const bin = path.join(process.env.LOCALAPPDATA || '', 'OpenAI', 'Codex', 'bin');
  let best = null;
  try {
    for (const d of fs.readdirSync(bin)) {
      const exe = path.join(bin, d, 'codex.exe');
      try { const t = fs.statSync(exe).mtimeMs; if (!best || t > best.t) best = { exe, t }; } catch {}
    }
  } catch {}
  if (best) return best.exe;
  for (const name of ['codex.exe', 'codex.cmd']) {
    try { const p = execFileSync('where.exe', [name], { encoding: 'utf8', windowsHide: true, stdio: ['ignore', 'pipe', 'ignore'] }).split(/\r?\n/)[0].trim(); if (p) return p; } catch {}
  }
  return null;
}

// ChatGPT sekmesi Codex komut satırını kullanır (kullanıcının ChatGPT hesabıyla); Codex sekmesinden ayrı bir sohbettir.
const AGENTS = ['claude', 'codex', 'chatgpt'];

function createChat({ userData, onEvent = () => {}, log = () => {} }) {
  const sessions = { claude: null, codex: null, chatgpt: null }; // devam eden sohbetin kimliği
  const running = new Map(); // id -> child
  const workDir = path.join(userData, 'chat');
  fs.mkdirSync(workDir, { recursive: true });
  let paths = null;
  const tools = () => (paths ||= { claude: findClaude(), codex: findCodex() });
  const toolFor = agent => tools()[agent === 'chatgpt' ? 'codex' : agent];

  function available() { return Object.fromEntries(AGENTS.map(a => [a, Boolean(toolFor(a))])); }

  // Nackles başka bir Claude/Codex oturumunun içinden başlatıldıysa onun ortam değişkenlerini taşır;
  // bunlar komut satırı aracını o oturumun girişine yönlendirip "giriş yapılmamış" hatasına yol açar.
  function cleanEnv() {
    const env = { ...process.env };
    for (const k of Object.keys(env)) if (/^(CLAUDE|ANTHROPIC_|CODEX_INTERNAL|ELECTRON_RUN_AS_NODE)/i.test(k)) delete env[k];
    return env;
  }

  function launch(cmd, args, cwd = workDir) {
    // .cmd dosyaları cmd.exe üzerinden çalışır; kullanıcının metni argümanda değil stdin'den gider.
    const opts = { cwd, windowsHide: true, env: cleanEnv() };
    if (/\.cmd$/i.test(cmd)) return spawn('cmd.exe', ['/d', '/s', '/c', cmd, ...args], opts);
    return spawn(cmd, args, opts);
  }

  function send(id, agent, text) {
    if (!AGENTS.includes(agent)) return;
    const exe = toolFor(agent);
    if (!exe) {
      const missing = { claude: 'Claude Code bulunamadı.', codex: 'Codex komut satırı bulunamadı.', chatgpt: 'ChatGPT için Codex uygulaması gerekiyor (ChatGPT hesabınla giriş yapılmış olmalı).' };
      onEvent({ id, type: 'error', text: missing[agent] || 'Bilinmeyen sohbet.' }); return;
    }
    let child;
    if (agent === 'claude') {
      // Hook'lar kapalı: sohbet adada ayrı bir "iş" gibi görünmesin, başka uygulamaların hook'ları da çalışmasın.
      const args = ['-p', '--output-format', 'stream-json', '--verbose', '--include-partial-messages', '--tools', '', '--settings', '{"disableAllHooks":true}'];
      if (sessions.claude) args.push('--resume', sessions.claude);
      child = launch(exe, args);
    } else {
      // "exec resume" --sandbox/--color kabul etmez (çıkış kodu 2); salt-okunur sandbox'ı ikisinde de -c ile veriyoruz.
      const base = ['--json', '--skip-git-repo-check', '-c', 'sandbox_mode="read-only"'];
      const args = sessions[agent] ? ['exec', 'resume', ...base, sessions[agent], '-'] : ['exec', ...base, '--color', 'never', '-'];
      child = launch(exe, args);
    }
    running.set(id, child);
    // CLI erken çıkarsa stdin EPIPE uygulamanın ana sürecini düşürmesin.
    child.stdin.on('error', e => { if (e.code !== 'EPIPE') log('chat stdin', agent, e.message); });
    child.stdin.end(text);
    child.stdout.setEncoding('utf8');
    let buf = '', said = '', err = '';
    function readLine(raw) {
        if (!running.has(id)) return;
        const line = raw.trim();
        if (!line.startsWith('{')) return;
        let ev; try { ev = JSON.parse(line); } catch { return; }
        if (agent === 'claude') {
          if (ev.session_id) sessions.claude = ev.session_id;
          const d = ev.type === 'stream_event' && ev.event?.type === 'content_block_delta' && ev.event.delta?.type === 'text_delta' ? ev.event.delta.text : '';
          if (d) { said += d; onEvent({ id, type: 'delta', text: d }); }
          if (ev.type === 'result' && !said && ev.result) { said = String(ev.result); onEvent({ id, type: 'delta', text: said }); }
          if (ev.type === 'result' && ev.is_error) err = String(ev.result || 'Claude bir hata verdi.');
          if (/not logged in|\/login/i.test(said) && !err) err = said;
        } else {
          if (ev.type === 'thread.started' && ev.thread_id) sessions[agent] = ev.thread_id;
          if (ev.type === 'item.completed' && ev.item?.type === 'agent_message' && ev.item.text) {
            const d = (said ? '\n\n' : '') + ev.item.text; said += d; onEvent({ id, type: 'delta', text: d });
          }
          if (ev.type === 'error' || ev.type === 'turn.failed') err = String(ev.message || ev.error?.message || 'Codex bir hata verdi.');
        }
    }
    child.stdout.on('data', chunk => {
      buf += chunk;
      let i;
      while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i); buf = buf.slice(i + 1);
        readLine(line);
      }
    });
    let errOut = '';
    child.stderr.on('data', d => { const s = String(d).trim(); if (s) { errOut = (errOut + '\n' + s).slice(-2000); log('chat', agent, 'stderr received'); } });
    child.on('error', e => { running.delete(id); onEvent({ id, type: 'error', text: e.message }); });
    child.on('close', code => {
      if (!running.has(id)) return; // durduruldu
      if (buf.trim()) readLine(buf);
      running.delete(id);
      if (/not logged in|\/login/i.test(err)) err = 'Claude Code komut satırına giriş yapılmamış. Bir kez terminalde claude çalıştırıp /login yazman gerekiyor.';
      if (err || code !== 0 || !said) onEvent({ id, type: 'error', text: err || `Cevap alınamadı (çıkış kodu ${code}).` });
      else onEvent({ id, type: 'done' });
    });
  }

  function stop(id) {
    const c = running.get(id); if (!c) return;
    running.delete(id);
    try { if (process.platform === 'win32') spawn('taskkill', ['/pid', String(c.pid), '/t', '/f'], { windowsHide: true }); else c.kill(); } catch {}
    onEvent({ id, type: 'done', stopped: true });
  }
  function reset(agent) { if (agent in sessions) sessions[agent] = null; }
  function stopAll() { for (const id of [...running.keys()]) stop(id); }

  return { send, stop, reset, stopAll, available };
}

module.exports = { createChat };
