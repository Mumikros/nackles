// Nackles ayarları: userData/settings.json içinde tutulur. Bilinmeyen ya da hatalı değerler varsayılana döner.
const fs = require('node:fs');
const path = require('node:path');

const DEFAULTS = {
  name: 'Nackles',        // asistanın adı (kullanıcı değiştirebilir)
  mascotKind: 'robot',    // robot | glitch | golge | baykus | custom:<id>
  palette: 'auto',        // auto (maskotun kendi rengi) | klasik | gece | kizil | asit | komur
  customMascots: [],      // kullanıcının eklediği resimler: [{ id, name }] (dosyalar userData/mascots içinde)
  // odak koruması: dikkat dağıtan site/uygulama açılınca nefes ekranı (always: sayaç çalışmasa da)
  focusGuard: { on: false, always: false, sites: ['youtube', 'tiktok', 'instagram', 'x', 'reddit', 'facebook', 'netflix', 'twitch', 'discord'], snoozeMin: 5 },
  askInIsland: true,      // izin isteklerini adada sor
  expandOnHover: true,    // üstüne gelince ada açılsın
  showClock: true,        // boştayken saati göster
  showBattery: true,      // boştayken pil yüzdesini göster
  music: true,            // çalan müziği adada göster
  codexWatch: true,       // Codex sohbet kayıtlarını izle
  clipboard: true,        // pano geçmişi (sadece bellekte)
  gpu: false,             // donanım hızlandırma (yeniden başlatınca geçerli)
  sound: true,
  volume: 0.6,
  sleepAfterMin: 3,       // maskot kaç dakika sonra uyusun (0 = hiç)
  // durum renkleri: claude/codex = çalışırken ajanın tonu (ready/running eski sürümlerden kalma, artık kullanılmıyor)
  colors: { claude: '#E07A4F', codex: '#6C8CFF', question: '#FFD050', done: '#4FDB7D', error: '#FF5C5C' },
  lang: 'auto',           // arayüz dili: auto (Windows dili) | tr | en
  mascot: { eye: '#7DF3E1', tip: '#3EE0C6', cheeks: true },
};

const isColor = v => typeof v === 'string' && /^#[0-9a-f]{6}$/i.test(v);
const num = (v, min, max, d) => (typeof v === 'number' && Number.isFinite(v) ? Math.min(max, Math.max(min, v)) : d);
const bool = (v, d) => (typeof v === 'boolean' ? v : d);

function clean(input = {}) {
  const d = DEFAULTS, i = input || {};
  const colors = {}, c = i.colors || {};
  for (const k of Object.keys(d.colors)) colors[k] = isColor(c[k]) ? c[k].toUpperCase() : d.colors[k];
  const m = i.mascot || {};
  const name = typeof i.name === 'string' ? i.name.replace(/[\u0000-\u001f<>]/g, '').replace(/\s+/g, ' ').trim().slice(0, 24) : '';
  const customMascots = Array.isArray(i.customMascots)
    ? i.customMascots.filter(m => m && /^[a-z0-9-]{6,40}$/.test(m.id)).slice(0, 12).map(m => ({ id: m.id, name: String(m.name || 'Maskot').slice(0, 24) }))
    : [];
  const kinds = ['robot', 'glitch', 'golge', 'baykus', ...customMascots.map(m => 'custom:' + m.id)];
  return {
    name: name || d.name,
    lang: ['auto', 'tr', 'en'].includes(i.lang) ? i.lang : d.lang,
    mascotKind: kinds.includes(i.mascotKind) ? i.mascotKind : d.mascotKind,
    palette: ['auto', 'klasik', 'gece', 'kizil', 'asit', 'komur'].includes(i.palette) ? i.palette : d.palette,
    customMascots,
    focusGuard: (() => {
      const g = i.focusGuard || {}, dg = d.focusGuard;
      const sites = Array.isArray(g.sites) ? g.sites.filter(x => dg.sites.includes(x)) : dg.sites;
      return { on: bool(g.on, dg.on), always: bool(g.always, dg.always), sites: [...new Set(sites)], snoozeMin: Math.round(num(g.snoozeMin, 1, 60, dg.snoozeMin)) };
    })(),
    askInIsland: bool(i.askInIsland, d.askInIsland),
    expandOnHover: bool(i.expandOnHover, d.expandOnHover),
    showClock: bool(i.showClock, d.showClock),
    showBattery: bool(i.showBattery, d.showBattery),
    music: bool(i.music, d.music),
    codexWatch: bool(i.codexWatch, d.codexWatch),
    clipboard: bool(i.clipboard, d.clipboard),
    gpu: bool(i.gpu, d.gpu),
    sound: bool(i.sound, d.sound),
    volume: num(i.volume, 0, 1, d.volume),
    sleepAfterMin: Math.round(num(i.sleepAfterMin, 0, 60, d.sleepAfterMin)),
    colors,
    mascot: { eye: isColor(m.eye) ? m.eye.toUpperCase() : d.mascot.eye, tip: isColor(m.tip) ? m.tip.toUpperCase() : d.mascot.tip, cheeks: bool(m.cheeks, d.mascot.cheeks) },
  };
}

function createStore(userData) {
  const file = path.join(userData, 'settings.json');
  let current;
  try { current = clean(JSON.parse(fs.readFileSync(file, 'utf8'))); } catch { current = clean(); }

  function set(patch) {
    const next = { ...current, ...patch };
    if (patch.colors) next.colors = { ...current.colors, ...patch.colors };
    if (patch.mascot) next.mascot = { ...current.mascot, ...patch.mascot };
    if (patch.focusGuard) next.focusGuard = { ...current.focusGuard, ...patch.focusGuard };
    current = clean(next);
    fs.mkdirSync(userData, { recursive: true });
    fs.writeFileSync(file, JSON.stringify(current, null, 2));
    return current;
  }
  function reset() { current = clean(); try { fs.unlinkSync(file); } catch {} return current; }

  return { get: () => current, set, reset };
}

module.exports = { createStore, clean, DEFAULTS };
