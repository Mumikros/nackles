// Gemini'nin kendi sitesi, ada penceresinin içinde ayrı ve sandbox'lı bir görünümde çalışır.
// Sayfaya preload/script eklenmez; tarayıcı çerezleri ya da CLI kimlik bilgileri taşınmaz.
const { WebContentsView, session } = require('electron');
const HOME = 'https://gemini.google.com/app';
const PARTITION = 'persist:gemini-web';

function allowed(url) {
  try {
    const u = new URL(url);
    return u.protocol === 'https:' && !u.username && !u.password && !u.port &&
      ['gemini.google.com', 'accounts.google.com', 'consent.google.com', 'myaccount.google.com'].includes(u.hostname);
  } catch { return false; }
}

function createGeminiWeb({ win, onState = () => {}, onFocus = () => {}, log = () => {} }) {
  let view = null, bounds = null, ready = false, closed = false;
  function state(status, text = '') {
    let origin = 'gemini.google.com';
    try { origin = new URL(view.webContents.getURL()).hostname; } catch {}
    onState({ status, text, origin });
  }
  function applyBounds() {
    if (!view || view.webContents.isDestroyed()) return;
    if (bounds) view.setBounds(bounds);
    view.setVisible(Boolean(bounds && ready));
  }
  function load(url) {
    if (!view || view.webContents.isDestroyed()) return;
    view.webContents.loadURL(url).catch(e => {
      if (closed || e.code === 'ERR_ABORTED') return;
      ready = false; applyBounds(); state('error', 'Gemini açılamadı. Bağlantını kontrol edip yeniden dene.');
      log('gemini web load', e.code || 'failed');
    });
  }
  function ensure() {
    if (closed || view) return;
    const ses = session.fromPartition(PARTITION);
    ses.setPermissionCheckHandler(() => false);
    ses.setPermissionRequestHandler((_wc, _permission, callback) => callback(false));
    view = new WebContentsView({ webPreferences: {
      session: ses, sandbox: true, contextIsolation: true, nodeIntegration: false,
      webSecurity: true, allowRunningInsecureContent: false, navigateOnDragDrop: false,
    } });
    view.setVisible(false);
    win.contentView.addChildView(view);
    const wc = view.webContents;
    wc.setWindowOpenHandler(({ url }) => {
      // Giriş bağlantıları da adanın içinde açılır. Yeni bir pencere oluşturulmaz.
      if (allowed(url)) load(url);
      return { action: 'deny' };
    });
    const navigate = (event, url) => { if (!allowed(url)) event.preventDefault(); };
    wc.on('will-navigate', navigate);
    wc.on('will-redirect', navigate);
    wc.on('did-start-loading', () => { ready = false; applyBounds(); state('loading'); });
    wc.on('did-finish-load', () => { ready = true; applyBounds(); state('ready'); });
    wc.on('did-navigate-in-page', () => state(ready ? 'ready' : 'loading'));
    wc.on('did-fail-load', (_event, code, _description, _url, isMainFrame) => {
      if (!isMainFrame || code === -3 || closed) return;
      ready = false; applyBounds(); state('error', 'Gemini açılamadı. Bağlantını kontrol edip yeniden dene.');
    });
    wc.on('render-process-gone', () => {
      ready = false; applyBounds(); state('error', 'Gemini açılamadı. Bağlantını kontrol edip yeniden dene.');
    });
    wc.on('focus', () => onFocus(true));
    wc.on('blur', () => onFocus(false));
    load(HOME);
  }
  function setBounds(rect) {
    bounds = null;
    if (rect && ['x', 'y', 'width', 'height'].every(k => Number.isFinite(rect[k]))) {
      const [width, height] = win.getContentSize();
      const x = Math.max(0, Math.round(rect.x)), y = Math.max(0, Math.round(rect.y));
      const w = Math.min(Math.round(rect.width), width - x), h = Math.min(Math.round(rect.height), height - y);
      if (w >= 100 && h >= 100) bounds = { x, y, width: w, height: h };
    }
    if (bounds) ensure();
    applyBounds();
    if (!bounds) onFocus(false);
  }
  function action(what) {
    if (closed || !['new', 'reload', 'back'].includes(what)) return;
    ensure();
    if (!view || view.webContents.isDestroyed()) return;
    if (what === 'new') load(HOME);
    if (what === 'reload') view.webContents.reload();
    if (what === 'back' && view.webContents.navigationHistory.canGoBack()) view.webContents.navigationHistory.goBack();
  }
  function close() {
    closed = true; bounds = null;
    if (view) {
      if (!win.isDestroyed()) win.contentView.removeChildView(view);
      if (!view.webContents.isDestroyed()) view.webContents.close();
      view = null;
    }
  }
  return { setBounds, action, close };
}

module.exports = { createGeminiWeb, allowed };
