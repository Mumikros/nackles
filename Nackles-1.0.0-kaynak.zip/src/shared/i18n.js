// Dil desteği: arayüz Türkçe yazılır; İngilizce seçilince metinler bu sözlükten çevrilir.
// Pencerelerde ekrandaki metinler kendiliğinden çevrilir (sonradan değişen metinler de). Kullanıcı içeriği
// (notlar, sohbet, şarkı/dosya adları) translate="no" olan alanlarda durur ve hiç çevrilmez.
// "{0}" içeren anahtarlar kalıptır: "Bitti · {0} adım" → "Done · {0} steps".
(function (root) {
  const EN = {
    // ---- ada: menü, sekmeler, sayfalar ----
    'Odak': 'Focus', 'Açık tut': 'Keep open', 'Açık tutmayı bırak': 'Stop keeping open', 'Sesi kapat': 'Mute', 'Sesi aç': 'Unmute',
    'Ayarlar': 'Settings', 'Adayı gizle': 'Hide island', 'Uygulamayı kapat': 'Quit', 'Yapay zekâ': 'AI', 'Müzik': 'Music',
    'Reddet': 'Deny', 'İzin ver': 'Allow', 'Yeni sohbet': 'New chat', 'Sana nasıl yardım edebilirim?': 'How can I help you?',
    'Bir şey kopyala ve aşağıdan seç, ya da soru yaz.': 'Copy something and pick below, or ask a question.',
    'Açıkla': 'Explain', 'Yazımı düzelt': 'Fix spelling', 'Çevir': 'Translate', 'Özetle': 'Summarize',    'Bu bilgisayar': 'This PC', 'Sıfırla': 'Reset', 'sa': 'h', 'dk': 'min', 'Başlat': 'Start', 'Duraklat': 'Pause', 'Devam': 'Resume',
    '{0} dk': '{0} min', 'Bitiş {0}': 'Ends {0}', 'Bitiş {0} · bugün {1} kez korundun': 'Ends {0} · protected {1} times today',
    'Dosyaları buraya bırak': 'Drop files here', 'İstediğin zaman dışarı sürükle · açmak için tıkla': 'Drag them out any time · click to open',
    'Tümünü seç': 'Select all', 'Tepsiyi boşalt': 'Empty tray', 'Dönüştür': 'Convert', 'Birleştir': 'Merge', 'Tepsiden çıkar': 'Remove from tray',
    'Sil': 'Delete', 'Filee ile dönüştür': 'Convert with Filee', 'Henüz bir şey kopyalamadın': 'Nothing copied yet',
    'Kopyaladıkların burada birikir. Tıklayınca yeniden kopyalanır.': 'What you copy collects here. Click to copy again.',
    'Geçmişi temizle': 'Clear history', 'Sadece bellekte tutulur': 'Kept in memory only', 'Yazmak için tıkla': 'Click to type',
    'Kendiliğinden kaydedilir · [ ] yazınca işaret yuvarlağı olur': 'Saves by itself · type [ ] for a check circle',
    'Ana': 'Home', 'Sohbet': 'Chat', 'Tepsi': 'Tray', 'Pano': 'Clipboard', 'Not': 'Note', 'Menü': 'Menu',
    'Oynat / duraklat': 'Play / pause', 'Başlat / duraklat': 'Start / pause', 'Gönder': 'Send', 'Önceki': 'Previous', 'Sonraki': 'Next',
    'Seçimi kaldır': 'Clear selection', 'Kapat': 'Close', 'Ana ekran': 'Home', 'Ses': 'Sound', 'Yapay ': 'AI ', 'zekâ': '',
    'Müzik ': 'Music ', 'çalar': 'player', 'Odak ': 'Focus ', 'sayacı': 'timer', 'Dosya ': 'File ', 'tepsisi': 'tray',
    'Pano ': 'Clipboard ', 'geçmişi': 'history', 'Not ': 'Note', 'defteri': 'pad', 'sohbet': 'chat', 'ajanı': 'agent',
    'Not defteri': 'Notepad',
    // ---- ada: durumlar ----
    'Çalışıyor': 'Working', 'Seni bekliyor': 'Waiting for you', 'Bitti': 'Done', 'Hata': 'Error', 'Hazır': 'Ready',
    'İzin istiyor': 'Asking permission', '{0} bitti': '{0} done', 'bugün biten iş': 'jobs done today', 'Düşünüyor': 'Thinking',
    'Düşünüyor…': 'Thinking…', 'İzin': 'Permission', 'Sessiz': 'Quiet', 'Çalan bir şey yok': 'Nothing is playing',
    'Odaklanıyorsun': 'Focusing', 'Duraklatıldı': 'Paused', 'Başlamaya hazır': 'Ready to start',
    'Bitti · {0} adım': 'Done · {0} steps', 'İzin bekliyor': 'Waiting for permission',
    "Claude Code'a bağlan": 'Connect Claude Code', "Codex'e bağlan": 'Connect Codex',
    'İZİN İSTİYOR': 'ASKING PERMISSION', 'ADIMLAR': 'STEPS', 'SON İŞLER': 'RECENT', '{0} şunu yapmak istiyor:': '{0} wants to:',
    'Cevabı Codex penceresinden ver.': 'Answer in the Codex window.', 'Cevabı terminalden ver.': 'Answer in the terminal.',
    'Henüz biten iş yok. Claude Code ya da Codex bir işi bitirince burada görünür.': 'No finished jobs yet. They show up here when Claude Code or Codex finishes one.',
    'Bağlantı sunucusu başlamadı: {0}': 'Connection server did not start: {0}', 'Bilinmeyen parça': 'Unknown track', 'Bilinmeyen': 'Unknown',
    "Spotify'da ya da tarayıcıda müzik aç.": 'Play music in Spotify or your browser.',
    'Bitti olarak işaretle': 'Mark as done', '{0} seçili': '{0} selected', 'Tepsiden çıkar (dosya silinmez)': 'Remove from tray (file is not deleted)',
    'Seç': 'Select', 'Klasör': 'Folder', 'Filee ile başka biçime dönüştür': 'Convert to another format with Filee',
    '{0} dosyayı çöpe at?': 'Move {0} files to Recycle Bin?', '{0} dosya çöpe atılamadı (açık olabilir).': "{0} files couldn't be moved to the Recycle Bin (they may be open).",
    "{0} dosya Geri Dönüşüm Kutusu'na taşındı.": '{0} files moved to the Recycle Bin.', 'Tepsi boşaltıldı. Dosyaların yerinde duruyor.': 'Tray emptied. Your files are where they were.',
    'Biçimler yükleniyor…': 'Loading formats…', 'Filee bulunamadı.': 'Filee was not found.', 'Bu dosyaların ortak dönüşebildiği bir biçim yok.': 'These files have no format in common.',
    'Filee bu dosya türünü tanımıyor.': "Filee doesn't know this file type.", '+{0} biçim daha': '+{0} more formats',
    'Filee ile birleştir · seçim sırasıyla': 'Merge with Filee · in selection order', 'Farklı türdeki dosyalar sadece tek ZIP olarak birleştirilebilir.': 'Files of different types can only be merged into one ZIP.',
    'Bazıları olmadı: {0}': 'Some failed: {0}', 'Bitti. Sonuç asıl dosyanın yanına kaydedildi.': 'Done. Saved next to the original file.', 'Olmadı.': "That didn't work.",
    '{0} dosya': '{0} files', '{0} biçimine dönüştürülüyor…': 'Converting to {0}…', '{0}…': '{0}…',
    'şimdi': 'now', '{0} sa': '{0} h', 'Geçmişten sil': 'Remove from history', 'Resim · {0}': 'Image · {0}',
    'Önce açıklanacak / çevrilecek metni kopyala.': 'Copy the text you want explained / translated first.',
    'Ses ve görünüm denemesi': 'Sound and look test', 'Bir hata oluştu': 'Something went wrong', 'Deneme': 'Test',
    'Ben {0}. Sana nasıl yardım edebilirim?': "I'm {0}. How can I help you?", 'Claude\'a sor…': 'Ask Claude…', 'Codex\'e sor…': 'Ask Codex…', "ChatGPT'ye sor…": 'Ask ChatGPT…', "Gemini'ye sor…": 'Ask Gemini…',
    'Uygulamada aç': 'Open in app',
    'ChatGPT için Codex uygulaması gerekiyor (ChatGPT hesabınla giriş yapılmış olmalı).': 'ChatGPT needs the Codex app (signed in with your ChatGPT account).',
    'Geri': 'Back', 'Yeniden yükle': 'Reload', 'Yeniden dene': 'Try again', 'Gemini açılıyor…': 'Opening Gemini…',
    'Gemini açılamadı. Bağlantını kontrol edip yeniden dene.': 'Could not open Gemini. Check your connection and try again.',
    'Claude\'a yaz…': 'Write to Claude…', 'Codex\'e yaz…': 'Write to Codex…', 'Durduruldu.': 'Stopped.',
    'Not ekle… (Enter)': 'Add a note… (Enter)', 'Kopyalandı · ': 'Copied · ',
    // hub'dan gelen adım açıklamaları
    'Okuyor · {0}': 'Reading · {0}', 'Düzenliyor · {0}': 'Editing · {0}', 'Düzenliyor': 'Editing', 'Çalıştırıyor · {0}': 'Running · {0}',
    'Arıyor · {0}': 'Searching · {0}', 'Web · {0}': 'Web · {0}', 'Alt ajan · {0}': 'Subagent · {0}', 'Görev listesini güncelliyor': 'Updating the task list',
    'Kod çalıştırıyor': 'Running code', 'Kod çalıştırıyor · {0}': 'Running code · {0}', 'Bekliyor': 'Waiting',
    'İzin verildi, devam ediyor': 'Allowed, continuing', 'Reddedildi': 'Denied', 'Terminalden cevaplandı': 'Answered in the terminal',
    "Codex'te izin istiyor · {0}": 'Asking permission in Codex · {0}', 'Terminalde izin istiyor · {0}': 'Asking permission in the terminal · {0}',
    // ---- ayarlar ----
    '{0} Ayarlar': '{0} Settings', 'Ayarlar ': 'Settings ', 'Genel': 'General', 'Görünüm': 'Appearance', 'Maskot': 'Mascot', 'Odak koruması': 'Focus guard', 'Hakkında': 'About',
    'Asistanın adı': "Assistant's name", 'Adada, sohbette ve menülerde bu ad görünür. İstediğin gibi değiştir.': 'Shown on the island, in chat and in menus. Change it as you like.',
    'Dil': 'Language', 'Arayüz dili. Otomatik seçenek Windows dilini kullanır.': 'Interface language. Automatic follows your Windows language.', 'Otomatik': 'Automatic',
    'Windows ile başlat': 'Start with Windows', 'Bilgisayar açılınca': 'When the computer starts,', 'da açılsın.': 'opens too.',
    'Üstüne gelince aç': 'Open on hover', 'Fare adanın üstüne gelince ada büyüsün.': 'Expand the island when the mouse is over it.',
    'Boştayken saati göster': 'Show the clock when idle', 'Yapay zekâ çalışmıyorken adada saat dursun.': 'Show the time on the island when no AI is working.',
    'Spotify, YouTube ve diğer oynatıcılarda çalanı adada göster ve kontrol et.': 'Show and control what plays in Spotify, YouTube and other players.',
    'Pano geçmişi': 'Clipboard history', 'Son kopyaladıklarını adada tut. Sadece bellekte durur,': 'Keep what you recently copied on the island. Memory only,',
    'kapanınca silinir. Parola yöneticilerinin gizli işaretlediği kopyalar alınmaz.': 'clears it on quit. Copies that password managers mark as private are skipped.',
    'Donanım hızlandırma': 'Hardware acceleration', 'Animasyonlar biraz daha akıcı olur ama': 'Animations get a bit smoother but',
    'yaklaşık 150–250 MB daha fazla bellek kullanır.': 'uses about 150–250 MB more memory.', 'yeniden başlayınca geçerli olur.': 'applies after a restart.',
    'Adayı aç / kapat': 'Open / close the island', 'Her yerden çalışan kısayol.': 'Works from anywhere.', 'Tüm ayarları sıfırla': 'Reset all settings',
    'Renkler, ses ve maskot varsayılana döner. Claude Code bağlantısı değişmez.': 'Colors, sound and mascot go back to defaults. The Claude Code connection stays.',
    'İzinleri adada sor': 'Ask permissions on the island', 'Claude bir komut için izin isteyince adadan İzin ver / Reddet de. Kapalıysa ada sadece haber verir, cevabı terminalde verirsin.': 'When Claude asks permission for a command, answer Allow / Deny on the island. When off, the island only tells you and you answer in the terminal.',
    'Bağlanınca ne olur?': 'What happens when you connect?', 'Claude Code:': 'Claude Code:', 'Codex:': 'Codex:',
    ", Claude Code'un ayarlarına sadece kendi bağlantısını ekler; senin diğer ayarların olduğu gibi kalır ve değiştirmeden önce bir yedek alınır. Claude Code'dan gelen bilgiler bilgisayarından hiç çıkmaz.": " only adds its own connection to Claude Code's settings; your other settings stay as they are and a backup is made first. Nothing from Claude Code ever leaves your computer.",
    "Codex'in hiçbir dosyasına yazılmaz.": 'Nothing is written to any Codex file.', ", Codex'in her sohbet için tuttuğu kayıt dosyalarını (": ' only reads the log files Codex keeps for each chat (',
    ") sadece okur. Codex hesap izni ya da hook onayı gerekmez. Codex izin isterse ada bunu gösterir; cevabı Codex'in penceresinden verirsin.": '). No Codex account permission or hook approval needed. If Codex asks for permission the island shows it; you answer in the Codex window.',
    'Adanın her durumda parladığı renk.': 'The color the island glows in each state.', 'Varsayılan renkler': 'Default colors', 'Durum renklerini ilk hâline döndür.': 'Reset the state colors.', 'Geri al': 'Undo',
    'Normal': 'Normal', 'Mutlu': 'Happy', 'Şaşkın': 'Surprised', 'Üzgün': 'Sad', 'Uykulu': 'Sleepy', 'Başı dönmüş': 'Dizzy', 'Dans et': 'Dance',
    'Adada ve tepsi ikonunda görünen karakter.': 'The character on the island.', 'Renk paleti': 'Color palette', 'Maskotun ve adanın vurgu renkleri birlikte değişir.': "The mascot's and the island's accent colors change together.",
    'Yanaklar': 'Cheeks', 'Robotun pembe yanakları görünsün.': "Show the robot's pink cheeks.", 'Uyku süresi': 'Sleep after', 'Boşta bu kadar dakika kalınca uyusun. 0 = hiç uyumasın.': 'Falls asleep after this many idle minutes. 0 = never.',
    'Kendi resmini ekle': 'Add your own image', 'Bu maskotu sil': 'Delete this mascot', 'Robot': 'Robot', 'Glitch': 'Glitch', 'Gölge': 'Shadow', 'Baykuş': 'Owl',
    'Klasik': 'Classic', 'Gece moru': 'Night purple', 'Kızıl': 'Crimson', 'Asit': 'Acid', 'Kömür ve altın': 'Coal & gold',
    'Odaklanırken dikkat dağıtan bir site ya da uygulama açınca araya sakin bir nefes ekranı girer. Sen "Geri dön" ya da "Yine de aç" dersin.': 'When you open a distracting site or app while focusing, a calm breathing screen steps in. You choose "Go back" or "Open anyway".',
    'Odak korumasını aç': 'Turn on focus guard', 'Varsayılan olarak sadece Odak sayacı çalışırken devreye girer.': 'By default it only works while the Focus timer runs.',
    'Her zaman koru': 'Always guard', 'Odak sayacı çalışmasa da korusun.': 'Guard even when the Focus timer is off.', '"Yine de aç" deyince': 'After "Open anyway"',
    'Bu kadar dakika o siteye bir daha karışmaz.': "Leaves that site alone for this many minutes.", 'Korunacak siteler ve uygulamalar': 'Sites and apps to guard',
    'Tarayıcıda sekme başlığına, uygulamalarda programa bakılır.': 'Uses the tab title in browsers and the program for apps.', 'Gizlilik': 'Privacy',
    'Sadece öndeki pencerenin başlığına ve programına anlık bakılır; hiçbir şey kaydedilmez ya da gönderilmez. Yalnızca bugün kaç kez odağına döndüğün sayılır.': "Only the front window's title and program are checked in the moment; nothing is stored or sent. Only how many times you went back to focus today is counted.",
    'Bitiş sesi': 'Finish sound', 'Claude bitirince ya da hata olunca kısa bir ses çalsın.': 'Play a short sound when Claude finishes or fails.', 'Ses seviyesi': 'Volume',
    'Adada dene': 'Try on the island', 'Sesi ve maskotun tepkisini şimdi gör.': "See the sound and the mascot's reaction now.",
    'Windows için Dynamic Island · sürüm': 'Dynamic Island for Windows · version', 'Hesap yok, kayıt yok, takip yok.': 'No account, no sign-up, no tracking.',
    'Claude Code ve Codex olayları, müzik bilgisi ve notların bilgisayarından çıkmaz.': 'Claude Code and Codex events, music info and your notes never leave your computer.',
    'Otomatik güncelleme ya da uzak sunucu yok.': 'No auto-updates, no remote servers.', 'Ayarların ve notların sadece bu bilgisayarda durur.': 'Your settings and notes stay on this computer only.',
    'Ayar klasörünü aç': 'Open settings folder', 'Boşta': 'Idle', 'Claude çalışıyor': 'Claude is working', 'İş bitti': 'Job done', 'Bir şey ters gitti': 'Something went wrong',
    'Hiç': 'Never', 'Sürüm {0}': 'Version {0}', '{0}: bağlantı sunucusu çalışmıyor': "{0}: connection server isn't running", '{0} bağlı': '{0} connected', '{0} bağlı değil': '{0} not connected',
    "Codex sohbetleri izleniyor. Nackles, Codex'in kayıt dosyalarını sadece okur.": "Watching Codex chats. Only Codex's log files are read.", 'Yeni {0} oturumları adada görünür.': 'New {0} sessions show up on the island.',
    'Bu bilgisayarda Codex bulunamadı. Yine de bağlayabilirsin.': "Codex wasn't found on this PC. You can connect anyway.", "Bağlanınca {0}'in ne yaptığını adada görürsün.": 'Connect to see what {0} is doing on the island.',
    'Bağlantıyı kaldır': 'Disconnect', 'Bağlan': 'Connect', 'Yapay zekâ ': 'AI ',
    'Nasıl bağlanır?': 'How to connect', "Claude Code: yukarıdaki Bağlan düğmesine bas. Claude Code'a bir sonraki işini verdiğinde ada canlanır.": 'Claude Code: press Connect above. The island comes alive the next time you give Claude Code a job.',
    "Codex: Bağlan düğmesine bas, sonra Codex'te yeni bir sohbet başlat.": 'Codex: press Connect, then start a new chat in Codex.',
    'İzin isteklerini adadan cevaplamak için İzinleri adada sor açık kalsın.': 'To answer permission requests on the island, keep Ask permissions on the island turned on.',
    'Ekranı dene': 'Try the screen', 'Nefes ekranının nasıl göründüğüne bak. Hiçbir pencere küçültülmez.': 'See what the breathing screen looks like. No window gets minimized.', 'Dene': 'Try',
    'Boştayken pili göster': 'Show battery when idle', 'Adada pil yüzdesi dursun. Saat ve pil kapalıysa ada küçülür.': 'Show the battery level on the island. With clock and battery off the island gets smaller.',
    'Claude tonu': 'Claude tone', 'Codex tonu': 'Codex tone', 'Codex çalışıyor': 'Codex is working',
    'Türkçe': 'Türkçe', 'English': 'English',
    // ---- odak koruması ekranı ----
    'Önce bir nefes al.': 'Take a breath first.', 'Nefes al': 'Breathe in', 'Nefes ver': 'Breathe out', 'Geri dön': 'Go back', 'Yine de aç': 'Open anyway',
    '{0} açıyorsun.': "You're opening {0}.", 'Yine de aç ({0} dk)': 'Open anyway ({0} min)', 'Bugün {0} kez odağına geri döndün.': 'You went back to focus {0} times today.',
    // ---- ana süreç ----
    'Adayı göster': 'Show island', 'Claude Code bağlantısını kaldır': 'Disconnect Claude Code', 'Codex bağlantısını kaldır': 'Disconnect Codex',
    'Maskot resmi seç': 'Choose a mascot image', 'Resim': 'Image', 'Bu dosya türü desteklenmiyor.': "This file type isn't supported.", "Resim 3 MB'tan küçük olmalı.": 'The image must be under 3 MB.',
    'Dosya tepside yok.': "The file isn't in the tray.", 'Codex komut satırı bulunamadı.': 'Codex command line not found.', 'Claude Code bulunamadı.': 'Claude Code not found.',
    'Claude bir hata verdi.': 'Claude returned an error.', 'Codex bir hata verdi.': 'Codex returned an error.',
    'Claude Code komut satırına giriş yapılmamış. Bir kez terminalde claude çalıştırıp /login yazman gerekiyor.': "Claude Code's command line isn't signed in. Run claude in a terminal once and type /login.",
    'Cevap alınamadı (çıkış kodu {0}).': 'No answer (exit code {0}).', "PDF'leri birleştir": 'Merge PDFs', 'Resimleri birleştir': 'Merge images', 'Resimlerden video': 'Video from images',
    'Videoları birleştir': 'Merge videos', 'Sesleri birleştir': 'Merge audio', 'Tek ZIP yap': 'One ZIP', 'Geçersiz biçim.': 'Invalid format.', 'İşlem çok uzun sürdü.': 'It took too long.',
    'Dönüştürülemedi.': "Couldn't convert.", 'Dosyanın klasör yolu çok uzun; dosyayı daha kısa bir yola taşıyıp tekrar dene.': "The file's folder path is too long; move it to a shorter path and try again.",
  };
  // Tarih için gün ve ay kısaltmaları
  const DATES = {
    tr: { days: ['Paz', 'Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt'], months: ['Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara'] },
    en: { days: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'], months: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'] },
  };

  const esc = s => s.replace(/[.*+?^$()|[\]\\]/g, '\\$&');
  const PATTERNS = Object.keys(EN).filter(k => /\{\d\}/.test(k)).map(k => ({
    re: new RegExp('^' + esc(k).replace(/\\\{|\\\}/g, m => m).replace(/\{(\d)\}/g, '(.+?)') + '$'), key: k,
  })).sort((a, b) => b.key.length - a.key.length);

  let lang = 'tr';
  // Metni seçili dile çevirir; bilinmeyen metin olduğu gibi kalır.
  function t(text, ...vars) {
    let s = String(text);
    if (vars.length) s = s.replace(/\{(\d)\}/g, (_, i) => vars[i] ?? '');
    if (lang === 'tr') return s;
    return translate(s);
  }
  function translate(s) {
    const lead = s.match(/^\s*/)[0], trail = s.match(/\s*$/)[0], core = s.trim();
    if (!core) return s;
    if (core in EN) return lead + EN[core] + trail;
    for (const p of PATTERNS) {
      const m = core.match(p.re);
      if (m) return lead + EN[p.key].replace(/\{(\d)\}/g, (_, i) => { const v = m[+i + 1] ?? ''; return v in EN ? EN[v] : v; }) + trail;
    }
    return s;
  }

  // ---- pencerelerde kendiliğinden çeviri ----
  const original = new WeakMap(); // düğüm → Türkçe asıl metin
  const ATTRS = ['placeholder', 'title', 'aria-label', 'data-tip'];
  const skip = n => { const el = n.nodeType === 1 ? n : n.parentElement; return !el || el.closest('[translate="no"], script, style, textarea, input:not([type="button"])') && !(el.matches?.('input') && n.nodeType === 1); };
  function doText(n) {
    if (skip(n)) return;
    const cur = n.nodeValue;
    const prev = original.get(n);
    // JS metni değiştirdiyse yeni asıl metin odur
    const src = prev && prev.out === cur ? prev.src : cur;
    const out = lang === 'tr' ? src : translate(src);
    original.set(n, { src, out });
    if (out !== cur) n.nodeValue = out;
  }
  function doAttrs(el) {
    if (el.closest?.('[translate="no"]')) return;
    for (const a of ATTRS) {
      if (!el.hasAttribute?.(a)) continue;
      const key = '__i18n_' + a, cur = el.getAttribute(a), prev = el[key];
      const src = prev && prev.out === cur ? prev.src : cur;
      const out = lang === 'tr' ? src : translate(src);
      el[key] = { src, out };
      if (out !== cur) el.setAttribute(a, out);
    }
  }
  function walk(rootEl) {
    if (!rootEl) return;
    if (rootEl.nodeType === 3) return doText(rootEl);
    if (rootEl.nodeType !== 1) return;
    doAttrs(rootEl);
    const w = document.createTreeWalker(rootEl, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT);
    for (let n = w.nextNode(); n; n = w.nextNode()) n.nodeType === 3 ? doText(n) : doAttrs(n);
  }
  let observer = null;
  function watch() {
    if (observer || typeof MutationObserver === 'undefined') return;
    observer = new MutationObserver(list => {
      observer.disconnect();
      for (const m of list) {
        if (m.type === 'characterData') doText(m.target);
        else if (m.type === 'attributes') doAttrs(m.target);
        else m.addedNodes.forEach(walk);
      }
      observer.observe(document.body, OPTS);
    });
    observer.observe(document.body, OPTS);
  }
  const OPTS = { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ATTRS };

  function setLang(next) {
    next = next === 'en' ? 'en' : 'tr';
    const changed = next !== lang;
    lang = next;
    if (typeof document !== 'undefined' && document.body) {
      document.documentElement.lang = lang;
      if (changed || !observer) { observer?.disconnect(); walk(document.body); observer = null; watch(); }
    }
  }

  const api = { t, setLang, get lang() { return lang; }, dates: () => DATES[lang], EN };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.NacklesI18n = api;
})(typeof window !== 'undefined' ? window : globalThis);

