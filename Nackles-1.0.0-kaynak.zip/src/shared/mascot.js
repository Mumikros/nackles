// Maskotlar: ada, ayarlar penceresi ve tepsi ikonu aynı çizimleri kullanır.
// Her maskot aynı "ruh hâli" sınıflarına sahiptir (eyes-normal, eyes-happy, …) ki animasyonlar hepsinde çalışsın.
// Renkler paletten gelir; kullanıcı kendi resmini de maskot olarak ekleyebilir (o zaman göz ifadeleri olmaz).
(() => {
  const PALETTES = {
    klasik: { name: 'Klasik', line: '#15171C', body: '#EEF1F5', eye: '#7DF3E1', accent: '#3EE0C6', visor: '#12141A' },
    gece: { name: 'Gece moru', line: '#C08BFF', body: '#1E1030', eye: '#FF6BE0', accent: '#FF4FD8', visor: '#0D0716' },
    kizil: { name: 'Kızıl', line: '#FF4646', body: '#2A0C0C', eye: '#FFB020', accent: '#FFB020', visor: '#120404' },
    asit: { name: 'Asit', line: '#B6FF3B', body: '#122008', eye: '#2BFFC6', accent: '#2BFFC6', visor: '#060B03' },
    komur: { name: 'Kömür ve altın', line: '#F5C542', body: '#1A1A1C', eye: '#FFFFFF', accent: '#F5C542', visor: '#0B0B0C' },
  };
  // Her maskotun "otomatik" paleti
  const KINDS = {
    robot: { name: 'Robot', palette: 'klasik' },
    glitch: { name: 'Glitch', palette: 'gece' },
    golge: { name: 'Gölge', palette: 'kizil' },
    baykus: { name: 'Baykuş', palette: 'komur' },
  };

  // Ortak göz ifadeleri: iki göz merkezi verilir, her ruh hâli için bir grup üretilir.
  function eyes(c, [lx, ly], [rx, ry], { w = 11, h = 17, normal } = {}) {
    const both = f => f(lx, ly) + f(rx, ry);
    const n = normal || ((x, y) => `<rect class="eye" x="${x - w / 2}" y="${y - h / 2}" width="${w}" height="${h}" rx="${w / 2}" fill="${c.eye}"/>`);
    return `
      <g class="eyes-normal">${both(n)}</g>
      <g class="eyes-happy" fill="none" stroke="${c.eye}" stroke-width="4" stroke-linecap="round">${both((x, y) => `<path d="M${x - 7} ${y + 3} Q${x} ${y - 8} ${x + 7} ${y + 3}"/>`)}</g>
      <g class="eyes-sleepy" fill="none" stroke="${c.eye}" stroke-width="4" stroke-linecap="round">${both((x, y) => `<path d="M${x - 7} ${y + 1} Q${x} ${y + 6} ${x + 7} ${y + 1}"/>`)}</g>
      <g class="eyes-sad" fill="none" stroke="#FF8A8A" stroke-width="4" stroke-linecap="round">
        <path d="M${lx - 7} ${ly - 4} L${lx + 6} ${ly + 1}"/><path d="M${rx + 7} ${ry - 4} L${rx - 6} ${ry + 1}"/>
        <circle cx="${lx}" cy="${ly + 7}" r="2.5" fill="#FF8A8A" stroke="none"/><circle cx="${rx}" cy="${ry + 7}" r="2.5" fill="#FF8A8A" stroke="none"/>
      </g>
      <g class="eyes-wow">${both((x, y) => `<circle cx="${x}" cy="${y}" r="7.5" fill="#FFD866"/><circle cx="${x + 2}" cy="${y - 2}" r="2.4" fill="#12141A"/>`)}</g>
      <g class="eyes-dizzy" fill="none" stroke="${c.eye}" stroke-width="3" stroke-linecap="round">${both((x, y) => `<path d="M${x} ${y} m-1 0 a1 1 0 1 1 2 0 a3 3 0 1 1 -5 0 a5 5 0 1 1 9 0"/>`)}</g>`;
  }

  const DRAW = {
    // İlk maskotumuz: krem kafa, iki anten, vizör
    robot: c => `
      <g class="antennae">
        <path d="M46 28 L38 11" stroke="${c.line}" stroke-width="4.5" stroke-linecap="round" fill="none"/>
        <path d="M74 28 L82 11" stroke="${c.line}" stroke-width="4.5" stroke-linecap="round" fill="none"/>
        <circle class="tip" cx="38" cy="10" r="6" fill="${c.accent}" stroke="${c.line}" stroke-width="3.5"/>
        <circle class="tip" cx="82" cy="10" r="6" fill="${c.accent}" stroke="${c.line}" stroke-width="3.5"/>
      </g>
      <rect x="7" y="54" width="12" height="26" rx="5" fill="${c.body}" stroke="${c.line}" stroke-width="4" opacity=".85"/>
      <rect x="101" y="54" width="12" height="26" rx="5" fill="${c.body}" stroke="${c.line}" stroke-width="4" opacity=".85"/>
      <rect x="15" y="24" width="90" height="82" rx="33" fill="${c.body}" stroke="${c.line}" stroke-width="5"/>
      <rect x="25" y="39" width="70" height="42" rx="21" fill="${c.visor}"/>
      <rect x="33" y="44" width="18" height="4" rx="2" fill="#FFFFFF" opacity=".16"/>
      ${eyes(c, [47.5, 59.5], [72.5, 59.5])}
      <g class="cheeks"><circle cx="31" cy="89" r="5" fill="#FF9AAE" opacity=".75"/><circle cx="89" cy="89" r="5" fill="#FF9AAE" opacity=".75"/></g>
      <path d="M53 91 Q60 97 67 91" stroke="${c.line}" stroke-width="3.5" stroke-linecap="round" fill="none"/>`,

    // Kenarları bozulan neon hayalet: arkadaki kopya ara sıra titrer
    glitch: c => `
      <path class="ghost-echo" d="M30 106 V58 a30 30 0 0 1 60 0 V106 l-10 -9 -10 9 -10 -9 -10 9 -10 -9z" fill="none" stroke="${c.accent}" stroke-width="3.5" stroke-linejoin="round" opacity=".75"/>
      <path d="M30 106 V58 a30 30 0 0 1 60 0 V106 l-10 -9 -10 9 -10 -9 -10 9 -10 -9z" fill="${c.body}" stroke="${c.line}" stroke-width="4" stroke-linejoin="round"/>
      <path class="tip" d="M36 82 h12 M70 40 h12" stroke="${c.accent}" stroke-width="2.5" stroke-linecap="round" opacity=".85"/>
      ${eyes(c, [48, 62], [72, 62])}`,

    // Şimşek kuyruklu neon kedi
    golge: c => `
      <path class="tip" d="M96 82 l10 -5 -6 11 11 -4" fill="none" stroke="${c.accent}" stroke-width="3.5" stroke-linejoin="round" stroke-linecap="round"/>
      <path d="M30 40 L40 16 L53 35 Q60 33 67 35 L80 16 L90 40 Q98 54 96 72 Q92 100 60 102 Q28 100 24 72 Q22 54 30 40z" fill="${c.body}" stroke="${c.line}" stroke-width="4" stroke-linejoin="round"/>
      <path d="M40 24 L44 34 M80 24 L76 34" stroke="${c.line}" stroke-width="2" stroke-linecap="round" opacity=".5"/>
      ${eyes(c, [47, 62], [73, 62], { normal: (x, y) => `<path class="eye" d="M${x - 9} ${y} q9 -8 18 0 q-9 8 -18 0z" fill="${c.eye}"/><rect x="${x - 1.4}" y="${y - 5}" width="2.8" height="10" rx="1.4" fill="${c.visor}"/>` })}
      <path d="M57 76 h6 l-3 3.5z" fill="${c.eye}"/>
      <path d="M30 78 l-14 -3 M30 83 l-14 2 M90 78 l14 -3 M90 83 l14 2" stroke="${c.line}" stroke-width="2" stroke-linecap="round" opacity=".6"/>`,

    // Geometrik neon baykuş: büyük göz halkaları
    baykus: c => `
      <path d="M26 30 L42 42 Q60 35 78 42 L94 30 L92 72 Q90 104 60 106 Q30 104 28 72 Z" fill="${c.body}" stroke="${c.line}" stroke-width="4" stroke-linejoin="round"/>
      <circle cx="45" cy="62" r="15" fill="${c.visor}" stroke="${c.line}" stroke-width="3"/>
      <circle cx="75" cy="62" r="15" fill="${c.visor}" stroke="${c.line}" stroke-width="3"/>
      ${eyes(c, [45, 62], [75, 62], { normal: (x, y) => `<circle class="eye" cx="${x}" cy="${y}" r="7" fill="${c.eye}"/><circle cx="${x + 2.5}" cy="${y - 2.5}" r="2" fill="#FFFFFF" opacity=".9"/>` })}
      <path class="tip" d="M55 78 L60 88 L65 78 Z" fill="${c.accent}"/>
      <path d="M46 94 l6 4 6 -4 M62 94 l6 4 6 -4" fill="none" stroke="${c.line}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" opacity=".6"/>`,
  };

  function colorsFor(kind, palette) {
    const auto = KINDS[kind]?.palette || 'gece';
    return PALETTES[palette] || PALETTES[auto];
  }

  // Maskot SVG'sini üretir. custom: { image: dataURL } — kullanıcının kendi resmi.
  function svg({ kind = 'robot', palette = 'auto', custom = null } = {}) {
    if (custom?.image) {
      const href = String(custom.image).replace(/"/g, '%22');
      return `<svg class="mascot mood-normal custom" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg"><g class="body"><image href="${href}" x="8" y="8" width="104" height="104" preserveAspectRatio="xMidYMid meet"/></g></svg>`;
    }
    const draw = DRAW[kind] || DRAW.robot;
    return `<svg class="mascot mood-normal kind-${kind in DRAW ? kind : 'robot'}" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg"><g class="body">${draw(colorsFor(kind, palette))}</g></svg>`;
  }

  window.NacklesMascot = {
    PALETTES, KINDS, colorsFor, svg,
    // Kutunun içindeki maskotu (varsa) değiştirir ve yeni <svg>'yi döndürür; ruh hâli sınıfları korunur.
    mount(container, opts = {}) {
      const old = container.querySelector('svg.mascot');
      const keep = old ? [...old.classList].filter(c => /^(mood-|look|dizzy|groove|dance)/.test(c)) : [];
      old?.remove();
      container.insertAdjacentHTML('afterbegin', svg(opts));
      const el = container.querySelector('svg.mascot');
      if (keep.length) { el.classList.remove('mood-normal'); el.classList.add(...keep); }
      return el;
    },
    // Eski çağrılarla uyum: yanakları gizle/göster
    paint(el, { cheeks = true } = {}) { const c = el.querySelector('.cheeks'); if (c) c.style.display = cheeks ? '' : 'none'; },
  };
})();
