// Yapay zekâ bağlantısı.
//  - Claude Code: ~/.claude/settings.json içindeki "http" hook'u her olayı (prompt, araç, izin, bitiş) yerel
//    sunucumuza JSON olarak gönderir. Sunucu sadece 127.0.0.1'de dinler ve her isteği gizli bir token ile doğrular.
//  - Codex: masaüstü uygulaması hooks.json'daki hook'ları çalıştırmadığı için Codex'in kendi sohbet kayıtlarını
//    okuyoruz (bkz. codex-watch.js); olaylar aynı handle() fonksiyonuna gelir.
// Hiçbir veri bilgisayardan çıkmaz.
const http = require('node:http');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');

const PORT = 48217;
const ROUTE = '/nackles-hook';
const URL = `http://127.0.0.1:${PORT}${ROUTE}`;
const EVENTS = ['UserPromptSubmit', 'PreToolUse', 'PostToolUse', 'PostToolUseFailure', 'PermissionRequest',
  'Notification', 'Stop', 'StopFailure', 'SessionEnd'];
const AGENTS = { claude: 'Claude Code', codex: 'Codex' };
const OLD_CODEX_SCRIPT = 'nackles-codex-hook.ps1'; // eski sürümlerin Codex hook'u; temizlik için tanınır
// İzin sorusu bu kadar bekler; cevap gelmezse Claude Code kendi terminal sorusuna döner.
const PERMISSION_WAIT_S = 300;
const RANK = { question: 4, error: 3, running: 2, done: 1, ready: 0 };

function createHub({
  userData,
  settingsFile = path.join(os.homedir(), '.claude', 'settings.json'),
  codexHome = process.env.CODEX_HOME || path.join(os.homedir(), '.codex'),
  onChange = () => {}, onFinish = () => {}, askInIsland = () => true,
  codexOn = () => false, // Codex izleyicisi açık mı (ayarlardan)
  port = PORT, // testler çalışan uygulamayla çakışmasın diye başka port verebilir
  log = () => {},
}) {
  const sessions = new Map();
  const codexFile = path.join(codexHome, 'hooks.json');
  let server = null, listenError = '';

  // Biten işlerin kısa geçmişi ("bugün 10 iş" ve "son işler" listesi için). userData/history.json'da durur.
  const historyFile = path.join(userData, 'history.json');
  let history = [];
  try { const h = JSON.parse(fs.readFileSync(historyFile, 'utf8')); if (Array.isArray(h)) history = h.slice(0, 50); } catch {}
  function remember(s) {
    history.unshift({ agent: s.agent, agentName: s.agentName, project: s.project, title: s.title || s.project, state: s.state, at: s.endedAt, ms: s.endedAt - (s.startedAt || s.endedAt) });
    history = history.slice(0, 50);
    try { fs.mkdirSync(userData, { recursive: true }); fs.writeFileSync(historyFile, JSON.stringify(history)); } catch {}
  }
  function jobsToday() { const d = new Date(); d.setHours(0, 0, 0, 0); return history.filter(h => h.at >= d.getTime() && h.state === 'done').length; }

  function token() {
    const f = path.join(userData, 'hook-token');
    try { const t = fs.readFileSync(f, 'utf8').trim(); if (/^[0-9a-f]{32}$/.test(t)) return t; } catch {}
    const t = crypto.randomBytes(16).toString('hex');
    fs.mkdirSync(userData, { recursive: true });
    fs.writeFileSync(f, t);
    return t;
  }

  // ---- ayar dosyaları ----
  function readJson(file) {
    if (!fs.existsSync(file)) return {};
    const text = fs.readFileSync(file, 'utf8');
    if (!text.trim()) return {};
    return JSON.parse(text); // bozuksa hata fırlatır: kullanıcının dosyasının üzerine asla yazmayız
  }
  function writeJson(file, data) {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    if (fs.existsSync(file)) fs.copyFileSync(file, file + '.nackles-yedek');
    fs.writeFileSync(file + '.tmp', JSON.stringify(data, null, 2) + '\n');
    fs.renameSync(file + '.tmp', file);
  }
  const isOurs = hook => Boolean(hook) && ((typeof hook.url === 'string' && hook.url.includes(ROUTE)) ||
    (typeof hook.command === 'string' && (hook.command.includes(URL) || hook.command.includes(OLD_CODEX_SCRIPT))));
  function strip(config) {
    let removed = false;
    for (const event of Object.keys(config.hooks || {})) {
      const groups = (config.hooks[event] || [])
        .map(group => { const hooks = (group.hooks || []).filter(hook => !isOurs(hook)); if (hooks.length !== (group.hooks || []).length) removed = true; return { ...group, hooks }; })
        .filter(group => group.hooks.length);
      if (groups.length) config.hooks[event] = groups; else delete config.hooks[event];
    }
    if (config.hooks && !Object.keys(config.hooks).length) delete config.hooks;
    return removed;
  }

  // ---- Claude Code ----
  function connected() {
    try {
      const hooks = readJson(settingsFile).hooks || {};
      return EVENTS.every(e => (hooks[e] || []).some(g => (g.hooks || []).some(isOurs)));
    } catch { return false; }
  }
  function connect() {
    const config = readJson(settingsFile); strip(config); config.hooks ||= {};
    for (const event of EVENTS) {
      const hook = { type: 'http', url: URL, timeout: event === 'PermissionRequest' ? PERMISSION_WAIT_S + 5 : 2, headers: { 'X-Nackles-Token': token() } };
      (config.hooks[event] ||= []).push({ hooks: [hook] });
    }
    writeJson(settingsFile, config); linkAt = 0; onChange();
  }
  // Bağlıyken hook'lardaki token bizimkinden farklıysa (ör. hook-token silinmiş ya da başka profilden yazılmış)
  // Claude Code'un her isteği 403 alır ve ada hiçbir şey görmez: hook'ları güncel token ile yeniden yazarız.
  function repair() {
    try {
      if (!connected()) return false;
      const hooks = readJson(settingsFile).hooks || {}, t = token();
      const stale = EVENTS.some(e => (hooks[e] || []).some(g => (g.hooks || []).some(h => isOurs(h) && h.headers?.['X-Nackles-Token'] !== t)));
      if (stale) connect();
      return stale;
    } catch (e) { log('hook onarılamadı', e.message); return false; }
  }
  function disconnect() {
    if (!fs.existsSync(settingsFile)) return;
    const config = readJson(settingsFile); strip(config); writeJson(settingsFile, config);
    for (const [id, s] of sessions) if (s.agent === 'claude') sessions.delete(id);
    linkAt = 0; onChange();
  }

  // ---- Codex ----
  // Eski sürümlerin ~/.codex/hooks.json'a eklediği Nackles satırlarını siler (başkalarınınkine dokunmaz).
  function cleanupCodexHooks() {
    try {
      if (!fs.existsSync(codexFile)) return false;
      const config = readJson(codexFile);
      if (!strip(config)) return false;
      writeJson(codexFile, config);
      return true;
    } catch (e) { log('codex hooks temizlenemedi', e.message); return false; }
  }
  function forgetCodex() { for (const [id, s] of sessions) if (s.agent === 'codex') sessions.delete(id); linkAt = 0; onChange(); }
  // Codex bu bilgisayarda kullanılmış mı? (~/.codex içinde Codex'in kendi dosyaları var mı)
  function codexAvailable() {
    try { return fs.readdirSync(codexHome).some(n => /^(config\.toml|auth\.json|history\.jsonl|version\.json)$/.test(n)); } catch { return false; }
  }

  // ---- oturumlar ----
  function session(event, agent) {
    const id = agent + ':' + String(event.session_id || 'default');
    let s = sessions.get(id);
    if (!s) {
      s = { id, agent, agentName: AGENTS[agent], project: path.basename(event.cwd || '') || AGENTS[agent], state: 'ready', title: '', detail: '', startedAt: 0, endedAt: 0, steps: [], permission: null, at: Date.now() };
      sessions.set(id, s);
    }
    if (event.cwd) s.project = path.basename(event.cwd);
    s.at = Date.now();
    return s;
  }

  function describe(tool, input = {}) {
    input = input && typeof input === 'object' ? input : {};
    const file = p => (p ? path.basename(String(p)) : '');
    const short = (t, n = 60) => { t = String(Array.isArray(t) ? t.join(' ') : t || '').replace(/\s+/g, ' ').trim(); return t.length > n ? t.slice(0, n - 1) + '…' : t; };
    switch (tool) {
      case 'Read': return { kind: 'read', text: 'Okuyor · ' + file(input.file_path) };
      case 'Edit': case 'MultiEdit': case 'Write': case 'NotebookEdit':
        return { kind: 'edit', text: 'Düzenliyor · ' + file(input.file_path || input.notebook_path) };
      case 'apply_patch': case 'ApplyPatch': {
        const m = /\*\*\* (?:Update|Add|Delete) File: (.+)/.exec(String(input.input || input.patch || input.command || ''));
        return { kind: 'edit', text: 'Düzenliyor' + (m ? ' · ' + file(m[1].trim()) : '') };
      }
      case 'Bash': case 'PowerShell': case 'shell': case 'exec_command': case 'local_shell': case 'unified_exec':
        return { kind: 'run', text: 'Çalıştırıyor · ' + short(input.command || input.cmd, 48) };
      case 'Grep': case 'Glob': return { kind: 'search', text: 'Arıyor · ' + short(input.pattern, 40) };
      case 'WebFetch': case 'WebSearch': case 'web_search': return { kind: 'web', text: 'Web · ' + short(input.url || input.query, 44) };
      case 'Task': case 'Agent': return { kind: 'agent', text: 'Alt ajan · ' + short(input.description, 44) };
      case 'TodoWrite': case 'update_plan': return { kind: 'plan', text: 'Görev listesini güncelliyor' };
      // Codex masaüstü uygulamasının "kod modu" araçları
      case 'exec': return { kind: 'run', text: 'Kod çalıştırıyor' + (input.code ? ' · ' + short(String(input.code).split('\n')[0], 40) : '') };
      case 'wait': case 'sleep': return { kind: 'wait', text: 'Bekliyor' };
      default: return { kind: 'tool', text: short(String(tool || 'Araç').replace(/^mcp__[^_]+__/, ''), 40) };
    }
  }

  function release(s, decision) {
    const p = s.permission; if (!p) return;
    s.permission = null;
    if (p.res && !p.res.writableEnded) {
      p.res.writeHead(200, { 'Content-Type': 'application/json' });
      p.res.end(decision ? JSON.stringify({ hookSpecificOutput: { hookEventName: 'PermissionRequest', decision } }) : '');
    }
  }

  function decide(id, behavior) {
    const s = sessions.get(id);
    if (!s || !s.permission || !s.permission.res) return;
    release(s, behavior === 'allow' ? { behavior: 'allow' } : { behavior: 'deny', message: 'Nackles üzerinden reddedildi.' });
    s.state = 'running';
    s.detail = behavior === 'allow' ? 'İzin verildi, devam ediyor' : 'Reddedildi';
    onChange();
  }

  // res: Claude Code'un HTTP isteği (izin cevabı onunla gider). Codex izleyicisinden gelen olaylarda null.
  function handle(event, res, agent = 'claude') {
    const name = event.hook_event_name;
    const s = session(event, agent);
    // Yeni bir olay geldiyse bekleyen izin terminalden cevaplanmış demektir.
    if (name !== 'PermissionRequest' && name !== 'Notification' && name !== 'PreToolUse') release(s, null);
    switch (name) {
      case 'SessionStart':
        break;
      case 'Title': // Codex: prompt metni görev başladıktan hemen sonra gelir
        s.title = String(event.prompt || '').replace(/\s+/g, ' ').trim().slice(0, 80) || s.title;
        break;
      case 'UserPromptSubmit':
        s.state = 'running'; s.startedAt = Date.now(); s.endedAt = 0; s.steps = []; s.permission = null;
        s.title = String(event.prompt || '').replace(/\s+/g, ' ').trim().slice(0, 80) || 'Çalışıyor';
        s.detail = 'Düşünüyor…';
        break;
      case 'PreToolUse': {
        const d = describe(event.tool_name, event.tool_input);
        if (s.state !== 'question') s.state = 'running';
        if (!s.startedAt) s.startedAt = Date.now();
        s.detail = d.text;
        s.steps.push({ id: event.tool_use_id || event.call_id, kind: d.kind, text: d.text, state: 'busy' });
        s.steps = s.steps.slice(-6);
        break;
      }
      case 'PostToolUse': case 'PostToolUseFailure': {
        const callId = event.tool_use_id || event.call_id;
        const step = s.steps.find(x => x.id && x.id === callId) || s.steps.findLast(x => x.state === 'busy');
        if (step) step.state = name === 'PostToolUseFailure' ? 'failed' : 'done';
        if (s.state === 'question' && !s.permission) s.state = 'running';
        break;
      }
      case 'PermissionRequest': {
        release(s, null);
        const d = describe(event.tool_name, event.tool_input);
        // Codex beklemez: cevap Codex'in kendi penceresinde verilir. Ayarlarda kapalıysa Claude için de öyle.
        if (agent === 'codex' || !askInIsland() || !res) {
          s.state = 'question'; s.detail = (agent === 'codex' ? 'Codex\'te izin istiyor · ' : 'Terminalde izin istiyor · ') + d.text;
          s.permission = { tool: String(event.tool_name || ''), text: d.text, res: null };
          break;
        }
        s.state = 'question'; s.detail = 'İzin istiyor';
        s.permission = { tool: String(event.tool_name || ''), text: d.text, res };
        const timer = setTimeout(() => { if (s.permission && s.permission.res === res) { release(s, null); s.state = 'running'; onChange(); } }, PERMISSION_WAIT_S * 1000);
        res.on('close', () => {
          clearTimeout(timer);
          if (s.permission && s.permission.res === res) { s.permission = null; s.state = 'running'; s.detail = 'Terminalden cevaplandı'; onChange(); }
        });
        onChange();
        return; // cevabı kullanıcı verince göndereceğiz
      }
      case 'Notification':
        if (!s.permission && /input|waiting|bekl/i.test(String(event.message || ''))) { s.state = 'question'; s.detail = 'Seni bekliyor'; }
        break;
      case 'Stop':
        s.state = 'done'; s.endedAt = Date.now(); s.detail = 'Bitti'; s.permission = null;
        if (!s.startedAt) s.startedAt = s.endedAt;
        for (const st of s.steps) if (st.state === 'busy') st.state = 'done';
        remember(s);
        onFinish(s);
        break;
      case 'StopFailure':
        s.state = 'error'; s.endedAt = Date.now(); s.detail = String(event.error || 'Bir hata oluştu').slice(0, 80);
        remember(s);
        onFinish(s);
        break;
      case 'SessionEnd':
        sessions.delete(s.id);
        break;
    }
    if (res) { res.writeHead(200); res.end(''); }
    onChange();
  }

  function start() {
    const secret = Buffer.from(token());
    const authorized = t => typeof t === 'string' && /^[0-9a-f]{32}$/.test(t) && crypto.timingSafeEqual(Buffer.from(t), secret);
    if (repair()) log('Claude Code hook token\'ı güncellendi');
    let rejected = 0;
    server = http.createServer((req, res) => {
      if (req.method !== 'POST' || !req.url.startsWith(ROUTE) || !authorized(req.headers['x-nackles-token'])) {
        // Token tutmuyorsa bir kez kayda yaz ve hook'ları onarmayı dene (her istekte değil).
        if (req.url.startsWith(ROUTE) && rejected++ === 0) { log('geçersiz token ile istek'); if (repair()) log('hook token\'ı onarıldı'); }
        res.writeHead(403); res.end(); return;
      }
      let body = '';
      req.on('data', c => { body += c; if (body.length > 2e6) req.destroy(); });
      req.on('end', () => {
        // PowerShell üzerinden gelen veride başta BOM (EF BB BF) olabilir; onu ve boşlukları atıyoruz.
        let event; try { event = JSON.parse(body.replace(/^﻿/, '').trim()); }
        catch { log('çözülemeyen hook olayı'); res.writeHead(400); res.end(); return; }
        try { handle(event, res, 'claude'); } catch (e) { console.error('[nackles] hook hatası', e); if (!res.writableEnded) { res.writeHead(200); res.end(''); } }
      });
    });
    server.on('error', e => { listenError = e.code === 'EADDRINUSE' ? `Port ${port} kullanımda` : e.message; onChange(); });
    server.listen(port, '127.0.0.1');
  }

  function stop() {
    for (const s of sessions.values()) release(s, null);
    server?.close();
  }

  // Ayar dosyalarını her olayda okumamak için bağlantı durumu en fazla 3 sn'de bir kontrol edilir.
  let linkCache = null, linkAt = 0;
  function links() {
    if (!linkCache || Date.now() - linkAt > 3000) {
      linkCache = { claude: connected(), codex: Boolean(codexOn()), codexAvailable: codexAvailable() };
      linkAt = Date.now();
    }
    return linkCache;
  }

  function view() {
    const list = [...sessions.values()]
      .filter(s => s.state !== 'ready' || s.permission)
      .sort((a, b) => (RANK[b.state] - RANK[a.state]) || (b.at - a.at))
      .map(({ permission, ...s }) => ({ ...s, permission: permission ? { tool: permission.tool, text: permission.text, canAnswer: Boolean(permission.res) } : null }));
    return { sessions: list, links: links(), error: listenError, history: history.slice(0, 6), jobsToday: jobsToday() };
  }

  // Bitmiş oturumlar bir süre sonra sakin hale döner.
  setInterval(() => {
    let changed = false;
    for (const s of sessions.values()) {
      if ((s.state === 'done' || s.state === 'error') && Date.now() - s.endedAt > 10 * 60 * 1000) { s.state = 'ready'; changed = true; }
    }
    if (changed) onChange();
  }, 30 * 1000).unref();

  return { start, stop, connect, disconnect, cleanupCodexHooks, forgetCodex, decide, view, handle, refreshLinks: () => { linkAt = 0; } };
}

module.exports = { createHub, PORT, ROUTE, EVENTS };
