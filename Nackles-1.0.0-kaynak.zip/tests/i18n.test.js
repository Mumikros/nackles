const test = require('node:test');
const assert = require('node:assert');
const i18n = require('../src/shared/i18n');

test('English translations: exact texts, patterns with values, unknown text untouched', () => {
  i18n.setLang('en');
  assert.equal(i18n.t('Yeni sohbet'), 'New chat');
  assert.equal(i18n.t('  Bitti  '), '  Done  '); // boşluklar korunur
  assert.equal(i18n.t('Bitti · {0} adım', 4), 'Done · 4 steps');
  assert.equal(i18n.t('Okuyor · app.js'), 'Reading · app.js');
  assert.equal(i18n.t('Bitiş 21:40 · bugün 3 kez korundun'), 'Ends 21:40 · protected 3 times today');
  assert.equal(i18n.t('Ben Pofuduk. Sana nasıl yardım edebilirim?'), "I'm Pofuduk. How can I help you?");
  assert.equal(i18n.t('Kedi videosu izle'), 'Kedi videosu izle');
  assert.deepStrictEqual(i18n.dates().months.slice(0, 2), ['Jan', 'Feb']);
  i18n.setLang('tr');
  assert.equal(i18n.t('Yeni sohbet'), 'Yeni sohbet');
  assert.equal(i18n.t('Bitti · {0} adım', 4), 'Bitti · 4 adım');
});
