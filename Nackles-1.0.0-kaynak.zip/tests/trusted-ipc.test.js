const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const { createTrustedIpc } = require('../src/trusted-ipc');

test('desktop IPC rejects remote views, subframes, navigated and destroyed windows', () => {
  const file = path.resolve('src/island/island.html');
  const frame = { url: pathToFileURL(file).href };
  const wc = { mainFrame: frame };
  let destroyed = false, calls = 0;
  const window = { webContents: wc, isDestroyed: () => destroyed };
  const handlers = {};
  const ipc = createTrustedIpc({ on: (c, fn) => handlers[c] = fn, handle: (c, fn) => handlers[c] = fn }, () => [{ window, file }]);
  ipc.on('send', () => ++calls);
  ipc.handle('read', () => 'local data');
  const local = { sender: wc, senderFrame: frame };
  handlers.send(local);
  assert.equal(handlers.read(local), 'local data');
  for (const invalid of [{}, { sender: {}, senderFrame: frame }, { sender: wc, senderFrame: { url: frame.url } }]) {
    handlers.send(invalid);
    assert.throws(() => handlers.read(invalid), /Untrusted/);
  }
  frame.url = 'https://gemini.google.com/app';
  handlers.send(local);
  assert.throws(() => handlers.read(local), /Untrusted/);
  frame.url = pathToFileURL(file).href;
  destroyed = true;
  handlers.send(local);
  assert.throws(() => handlers.read(local), /Untrusted/);
  assert.equal(calls, 1);
});
