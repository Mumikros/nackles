const test = require('node:test');
const assert = require('node:assert');
const { parseFormats, sortPopular, mergeOptions } = require('../src/filee');

test('merge options depend on the selected file types', () => {
  const ids = l => mergeOptions(l).map(o => o.preset);
  assert.deepStrictEqual(ids(['a.pdf', 'b.PDF']), ['merge-pdf', 'zip-all']);
  assert.deepStrictEqual(ids(['a.png', 'b.jpg']), ['merge-images', 'video-from-images', 'zip-all']);
  assert.deepStrictEqual(ids(['a.mp4', 'b.mov']), ['merge-videos', 'zip-all']);
  assert.deepStrictEqual(ids(['a.pdf', 'b.png']), ['zip-all']);
});

test('filee formats output is parsed into ready and optional targets', () => {
  const out = [
    'PNG (png, png_large) converts to:',
    '  jpg, webp, tiff, bmp, pdf, docx, txt',
    'With optional engines (install them in Filee, Settings → Engines):',
    '  heic, mp4, webm',
  ].join('\r\n');
  const f = parseFormats(out);
  assert.deepStrictEqual(f.ready, ['jpg', 'webp', 'tiff', 'bmp', 'pdf', 'docx', 'txt']);
  assert.deepStrictEqual(f.optional, ['heic', 'mp4', 'webm']);
  assert.deepStrictEqual(parseFormats('Unknown format'), { ready: [], optional: [] });
});

test('popular formats come first, the rest keep their order', () => {
  assert.deepStrictEqual(sortPopular(['tiff', 'bmp', 'pdf', 'jpg', 'xpm']), ['jpg', 'pdf', 'tiff', 'bmp', 'xpm']);
});
