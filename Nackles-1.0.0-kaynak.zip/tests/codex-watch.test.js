const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createCodexWatch, translate } = require('../src/codex-watch');

const ID = '01a19343-51eb-7e62-a3d3-60f754fc0a55';
const lines = [
  { type: 'session_meta', payload: { id: ID, cwd: '\\\\?\\C:\\Users\\me\\proj' } },
  { type: 'event_msg', payload: { type: 'task_started', turn_id: 't1' } },
  { type: 'response_item', payload: { type: 'message', role: 'user', content: [{ type: 'input_text', text: '<environment_context>…</environment_context>' }] } },
  { type: 'response_item', payload: { type: 'message', role: 'user', content: [{ type: 'input_text', text: 'Testleri düzelt' }] } },
  { type: 'response_item', payload: { type: 'custom_tool_call', name: 'exec', call_id: 'c1', input: 'const r = await tools.shell("npm test");\ntext(r)' } },
  { type: 'response_item', payload: { type: 'custom_tool_call_output', call_id: 'c1', output: 'ok' } },
  { type: 'response_item', payload: { type: 'function_call', name: 'wait', call_id: 'c2', arguments: '{"cell_id":"g1"}' } },
  { type: 'event_msg', payload: { type: 'token_count' } },
  { type: 'event_msg', payload: { type: 'task_complete', turn_id: 't1' } },
];

test('rollout lines become hook-style events', () => {
  const ctx = { id: ID, cwd: '', wantPrompt: false };
  const out = lines.map(l => translate(l, ctx)).filter(Boolean);
  assert.deepStrictEqual(out.map(e => e.hook_event_name), ['SessionStart', 'UserPromptSubmit', 'Title', 'PreToolUse', 'PostToolUse', 'PreToolUse', 'Stop']);
  assert.equal(out[0].cwd, 'C:\\Users\\me\\proj');
  assert.equal(out[2].prompt, 'Testleri düzelt');
  assert.equal(out[3].tool_name, 'exec');
  assert.match(out[3].tool_input.code, /npm test/);
  assert.deepStrictEqual(out[5].tool_input, { cell_id: 'g1' });
  assert.ok(out.every(e => e.session_id === ID));
});

test('watcher reads only new lines of new or growing rollout files', async () => {
  const home = fs.mkdtempSync(path.join(os.tmpdir(), 'nackles-codex-'));
  process.on('exit', () => fs.rmSync(home, { recursive: true, force: true }));
  const d = new Date();
  const dir = path.join(home, 'sessions', String(d.getFullYear()), String(d.getMonth() + 1).padStart(2, '0'), String(d.getDate()).padStart(2, '0'));
  fs.mkdirSync(dir, { recursive: true });
  const old = path.join(dir, 'rollout-old-11111111-2222-3333-4444-555555555555.jsonl');
  fs.writeFileSync(old, lines.slice(0, 2).map(l => JSON.stringify(l)).join('\n') + '\n');
  fs.utimesSync(old, new Date(Date.now() - 3600e3), new Date(Date.now() - 3600e3)); // bir saat önce

  const got = [];
  const w = createCodexWatch({ home, onEvent: e => got.push(e.hook_event_name + ':' + e.session_id.slice(0, 4)) });
  w.start();
  try {
    assert.deepStrictEqual(got, []); // eski sohbet yeniden oynatılmaz
    const file = path.join(dir, `rollout-2026-${ID}.jsonl`);
    fs.writeFileSync(file, lines.slice(0, 4).map(l => JSON.stringify(l)).join('\n') + '\n{"type":"event_msg","pay'); // yarım satır
    await new Promise(r => setTimeout(r, 1300));
    assert.deepStrictEqual(got, ['SessionStart:01a1', 'UserPromptSubmit:01a1', 'Title:01a1']);
    fs.appendFileSync(file, 'load":{"type":"task_complete"}}\n');
    fs.appendFileSync(old, JSON.stringify(lines[8]) + '\n'); // eski dosya büyürse yeni satır okunur
    await new Promise(r => setTimeout(r, 1300));
    assert.deepStrictEqual(got.slice(3).sort(), ['Stop:01a1', 'Stop:1111']);
  } finally { w.stop(); }
});
