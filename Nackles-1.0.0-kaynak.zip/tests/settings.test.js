const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createStore, clean, DEFAULTS } = require('../src/settings-store');

test('bad values fall back to defaults', () => {
  const s = clean({ volume: 7, sleepAfterMin: -3, sound: 'yes', colors: { done: 'green', error: '#00ff00' }, mascot: { eye: 'url(x)' } });
  assert.equal(s.volume, 1);
  assert.equal(s.sleepAfterMin, 0);
  assert.equal(s.sound, DEFAULTS.sound);
  assert.equal(s.colors.done, DEFAULTS.colors.done);
  assert.equal(s.colors.error, '#00FF00');
  assert.equal(s.mascot.eye, DEFAULTS.mascot.eye);
  assert.equal(clean({ name: '  Bulut   Kız  ' }).name, 'Bulut Kız');
  assert.equal(clean({ name: '<script>' }).name, 'script');
  assert.equal(clean({ name: '   ' }).name, 'Nackles');
  assert.equal(clean({ name: 'x'.repeat(40) }).name.length, 24);
  assert.equal(clean({ mascotKind: 'golge', palette: 'asit' }).mascotKind, 'golge');
  assert.equal(clean({ mascotKind: 'ejderha' }).mascotKind, 'robot');
  assert.equal(clean({ palette: 'pembe' }).palette, 'auto');
  // eklenmiş resim maskotu ancak listede varsa seçilebilir
  assert.equal(clean({ mascotKind: 'custom:abc123' }).mascotKind, 'robot');
  assert.equal(clean({ customMascots: [{ id: 'abc123', name: 'Benim' }], mascotKind: 'custom:abc123' }).mascotKind, 'custom:abc123');
  assert.equal(clean({ customMascots: [{ id: '../../x' }] }).customMascots.length, 0);
});

test('store saves partial changes and survives a restart', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'nackles-set-'));
  process.on('exit', () => fs.rmSync(dir, { recursive: true, force: true }));
  const a = createStore(dir);
  a.set({ sound: false, colors: { claude: '#123456' }, mascot: { cheeks: false } });
  const b = createStore(dir).get();
  assert.equal(b.sound, false);
  assert.equal(b.colors.claude, '#123456');
  assert.equal(b.colors.done, DEFAULTS.colors.done);
  assert.equal(b.mascot.cheeks, false);
  assert.equal(b.mascot.eye, DEFAULTS.mascot.eye);
  assert.deepStrictEqual(createStore(dir).reset(), clean());
});
