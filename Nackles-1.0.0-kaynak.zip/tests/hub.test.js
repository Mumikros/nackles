const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createHub, PORT, ROUTE, EVENTS } = require('../src/hub');

const TEST_PORT = PORT + 1; // çalışan Nackles uygulamasıyla çakışmasın
const made = [];
function tmp() { const d = fs.mkdtempSync(path.join(os.tmpdir(), 'nackles-')); made.push(d); return d; }
test.after(() => { for (const d of made) fs.rmSync(d, { recursive: true, force: true }); });

test('stale token in Claude Code hooks is repaired on start', async () => {
  const dir = tmp(), file = path.join(dir, 'settings.json');
  createHub({ userData: dir, settingsFile: file }).connect();
  fs.writeFileSync(path.join(dir, 'hook-token'), 'f'.repeat(32)); // token değişti, hook'larda eskisi kaldı
  const hub = createHub({ userData: dir, settingsFile: file, port: TEST_PORT });
  hub.start();
  try {
    const hooks = JSON.parse(fs.readFileSync(file, 'utf8')).hooks;
    for (const e of EVENTS) assert.equal(hooks[e][0].hooks[0].headers['X-Nackles-Token'], 'f'.repeat(32), e);
    assert.equal(hooks.Stop.length, 1);
  } finally { hub.stop(); await new Promise(r => setTimeout(r, 50)); }
});

test('connect keeps other hooks and settings, disconnect removes only ours', () => {
  const dir = tmp(), file = path.join(dir, 'settings.json');
  const original = { model: 'opus', hooks: { Stop: [{ hooks: [{ type: 'command', command: 'echo hi' }] }] } };
  fs.writeFileSync(file, JSON.stringify(original));
  const hub = createHub({ userData: dir, settingsFile: file });

  hub.connect();
  const after = JSON.parse(fs.readFileSync(file, 'utf8'));
  assert.equal(after.model, 'opus');
  assert.equal(after.hooks.Stop.length, 2);
  for (const e of EVENTS) assert.ok(after.hooks[e].some(g => g.hooks.some(h => h.url?.includes(ROUTE))), e);
  assert.ok(fs.existsSync(file + '.nackles-yedek'));
  assert.equal(hub.view().links.claude, true);

  hub.connect(); // ikinci kez bağlanınca kopya eklenmez
  assert.equal(JSON.parse(fs.readFileSync(file, 'utf8')).hooks.Stop.length, 2);

  hub.disconnect();
  assert.deepStrictEqual(JSON.parse(fs.readFileSync(file, 'utf8')), original);
});

test('old Nackles Codex hooks are cleaned up, other hooks stay', () => {
  const dir = tmp(), codexHome = path.join(dir, 'codex'), file = path.join(codexHome, 'hooks.json');
  fs.mkdirSync(codexHome);
  const theirs = { type: 'command', command: 'say done' };
  fs.writeFileSync(file, JSON.stringify({ hooks: {
    Stop: [{ hooks: [theirs] }, { hooks: [{ type: 'command', command: 'powershell.exe -File "C:\\x\\nackles-codex-hook.ps1"' }] }],
    SessionStart: [{ hooks: [{ type: 'command', command: `curl.exe --data-binary @- "http://127.0.0.1:${PORT}${ROUTE}?agent=codex"` }] }],
  } }));
  const hub = createHub({ userData: dir, settingsFile: path.join(dir, 's.json'), codexHome, codexOn: () => true });
  assert.equal(hub.cleanupCodexHooks(), true);
  assert.deepStrictEqual(JSON.parse(fs.readFileSync(file, 'utf8')), { hooks: { Stop: [{ hooks: [theirs] }] } });
  assert.equal(hub.cleanupCodexHooks(), false); // ikinci kez dokunmaz
  assert.equal(hub.view().links.codex, true);
});
test('broken settings.json is never overwritten', () => {
  const dir = tmp(), file = path.join(dir, 'settings.json');
  fs.writeFileSync(file, '{ bozuk');
  const hub = createHub({ userData: dir, settingsFile: file });
  assert.throws(() => hub.connect());
  assert.equal(fs.readFileSync(file, 'utf8'), '{ bozuk');
});

test('hook events drive session state; permission waits for a decision', async () => {
  const dir = tmp();
  const finished = [];
  const hub = createHub({ userData: dir, settingsFile: path.join(dir, 's.json'), onFinish: s => finished.push(s.state), port: TEST_PORT });
  hub.start();
  await new Promise(r => setTimeout(r, 100));
  const token = fs.readFileSync(path.join(dir, 'hook-token'), 'utf8');
  const post = (body, t = token) => fetch(`http://127.0.0.1:${TEST_PORT}${ROUTE}`, { method: 'POST', headers: { 'X-Nackles-Token': t, 'Content-Type': 'application/json' }, body: JSON.stringify({ session_id: 'a', cwd: 'C:\\code\\demo', ...body }) });

  try {
    assert.equal((await post({ hook_event_name: 'Stop' }, 'yanlis')).status, 403);
    // Same character count, different byte count must reject without crashing the server.
    assert.equal((await post({ hook_event_name: 'Stop' }, '\u00e9'.repeat(32))).status, 403);
    assert.equal((await post({ hook_event_name: 'Stop' }, '0'.repeat(32))).status, 403);

    await post({ hook_event_name: 'UserPromptSubmit', prompt: 'Testleri düzelt' });
    await post({ hook_event_name: 'PreToolUse', tool_name: 'Read', tool_use_id: 't1', tool_input: { file_path: 'C:\\code\\demo\\app.js' } });
    let s = hub.view().sessions[0];
    assert.equal(s.project, 'demo');
    assert.equal(s.state, 'running');
    assert.equal(s.detail, 'Okuyor · app.js');

    const pending = post({ hook_event_name: 'PermissionRequest', tool_name: 'Bash', tool_input: { command: 'npm install' } });
    await new Promise(r => setTimeout(r, 100));
    s = hub.view().sessions[0];
    assert.equal(s.state, 'question');
    assert.equal(s.permission.text, 'Çalıştırıyor · npm install');

    hub.decide('claude:a', 'allow');
    const answer = await (await pending).json();
    assert.deepStrictEqual(answer, { hookSpecificOutput: { hookEventName: 'PermissionRequest', decision: { behavior: 'allow' } } });

    await post({ hook_event_name: 'Stop' });
    assert.equal(hub.view().sessions[0].state, 'done');
    assert.deepStrictEqual(finished, ['done']);

    await post({ hook_event_name: 'SessionEnd' });
    assert.equal(hub.view().sessions.length, 0);

    // PowerShell'in eklediği BOM ve satır sonu olayı bozmamalı
    const bom = await fetch(`http://127.0.0.1:${TEST_PORT}${ROUTE}`, { method: 'POST', headers: { 'X-Nackles-Token': token }, body: '\uFEFF' + JSON.stringify({ hook_event_name: 'SessionStart', session_id: 'b' }) + '\r\n' });
    assert.equal(bom.status, 200);

    // Codex (kayıt izleyicisinden gelir, HTTP yanıtı yok): izin istekleri sadece gösterilir
    const codex = body => hub.handle({ session_id: 'c', cwd: 'C:\\code\\api', ...body }, null, 'codex');
    codex({ hook_event_name: 'UserPromptSubmit', prompt: '' });
    codex({ hook_event_name: 'Title', prompt: 'Refactor yap' });
    codex({ hook_event_name: 'PreToolUse', tool_name: 'shell', tool_input: { command: ['npm', 'test'] } });
    s = hub.view().sessions[0];
    assert.equal(s.agent, 'codex');
    assert.equal(s.title, 'Refactor yap');
    assert.equal(s.detail, 'Çalıştırıyor · npm test');
    codex({ hook_event_name: 'PermissionRequest', tool_name: 'shell', tool_input: { command: 'rm -rf build' } });
    s = hub.view().sessions[0];
    assert.equal(s.state, 'question');
    assert.equal(s.permission.canAnswer, false);
    codex({ hook_event_name: 'Stop' });
    assert.equal(hub.view().sessions[0].state, 'done');
  } finally { hub.stop(); }
});
