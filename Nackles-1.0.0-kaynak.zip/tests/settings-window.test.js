const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { EventEmitter } = require('node:events');

function fixture() {
  const windows = [];
  class BrowserWindow extends EventEmitter {
    constructor(options) {
      super(); this.options = options; this.visible = false; this.destroyed = false; this.minimized = false; this.shows = 0;
      this.webContents = new EventEmitter(); this.webContents.setWindowOpenHandler = () => {};
      this.loading = new Promise(resolve => { this.finish = resolve; });
      windows.push(this);
    }
    isDestroyed() { return this.destroyed; }
    isMinimized() { return this.minimized; }
    isVisible() { return this.visible; }
    restore() { this.minimized = false; }
    show() { this.shows++; if (!this.hideFirstShow || this.shows > 1) this.visible = true; }
    focus() { this.focused = true; }
    loadFile() { return this.loading; }
  }
  const source = fs.readFileSync(path.join(__dirname, '../src/main.js'), 'utf8');
  const context = { settingsWin: null, BrowserWindow, path, __dirname: '/src', store: { get: () => ({ name: 'Nackles' }) }, appIcon() {}, watchConsole() {}, log() {} };
  vm.createContext(context);
  vm.runInContext(source.slice(source.indexOf('function openSettings()'), source.indexOf('// Müzik sadece')), context);
  return { context, windows };
}

test('settings reopens a hidden or minimized existing window', async () => {
  const { context, windows } = fixture();
  context.openSettings();
  const win = windows[0]; win.emit('ready-to-show'); win.finish(); await win.loading;
  win.visible = false; win.minimized = true;
  context.openSettings();
  assert.equal(windows.length, 1);
  assert.equal(win.isVisible(), true); assert.equal(win.isMinimized(), false); assert.equal(win.focused, true);
});

test('settings becomes visible if Windows suppresses the first show on a hidden launch', async () => {
  const { context, windows } = fixture();
  context.openSettings();
  const win = windows[0]; win.hideFirstShow = true;
  win.emit('ready-to-show'); assert.equal(win.isVisible(), false);
  win.finish(); await win.loading;
  assert.equal(win.isVisible(), true);
  assert.equal(win.options.webPreferences.sandbox, true);
  assert.equal(win.options.webPreferences.contextIsolation, true);
});

test('late load of a closed settings window does not show a replacement window', async () => {
  const { context, windows } = fixture();
  context.openSettings(); const old = windows[0]; old.destroyed = true; old.emit('closed');
  context.openSettings(); const current = windows[1];
  old.emit('ready-to-show'); old.finish(); await old.loading;
  assert.equal(current.isVisible(), false); assert.equal(context.settingsWin, current);
  current.finish(); await current.loading; assert.equal(current.isVisible(), true);
});
