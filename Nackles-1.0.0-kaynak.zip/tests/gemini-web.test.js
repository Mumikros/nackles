const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { EventEmitter } = require('node:events');

function fixture() {
  const views = [], states = [], focus = [], partitions = [];
  const ses = { setPermissionCheckHandler(fn) { this.check = fn; }, setPermissionRequestHandler(fn) { this.request = fn; } };
  class WebContentsView {
    constructor(options) {
      this.options = options;
      this.webContents = new EventEmitter();
      Object.assign(this.webContents, {
        isDestroyed: () => false, url: '',
        setWindowOpenHandler(fn) { this.open = fn; },
        loadURL(url) { this.url = url; return Promise.resolve(); },
        getURL() { return this.url; }, reload() { this.reloaded = true; }, close() { this.closed = true; },
        navigationHistory: { canGoBack: () => true, goBack() { this.back = true; } },
      });
      views.push(this);
    }
    setVisible(visible) { this.visible = visible; }
    setBounds(bounds) { this.bounds = bounds; }
  }
  const electron = { WebContentsView, session: { fromPartition(p) { partitions.push(p); return ses; } } };
  const context = { module: { exports: {} }, URL, require: name => name === 'electron' ? electron : require(name) };
  vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../src/gemini-web.js'), 'utf8'), context);
  const attached = [];
  const win = { getContentSize: () => [600, 760], isDestroyed: () => false, contentView: {
    addChildView(v) { attached.push(v); }, removeChildView(v) { attached.splice(attached.indexOf(v), 1); },
  } };
  const web = context.module.exports.createGeminiWeb({ win, onState: s => states.push(s), onFocus: f => focus.push(f) });
  return { web, allowed: context.module.exports.allowed, views, states, focus, partitions, ses, attached };
}

test('Gemini uses an isolated native view inside the existing window and survives tab switches', () => {
  const { web, views, states, focus, partitions, ses, attached } = fixture();
  web.setBounds(null);
  assert.equal(views.length, 0);
  web.setBounds({ x: 46, y: 108, width: 508, height: 556 });
  const view = views[0], wc = view.webContents;
  assert.equal(attached.length, 1);
  assert.equal(partitions[0], 'persist:gemini-web');
  assert.equal(view.options.webPreferences.sandbox, true);
  assert.equal(view.options.webPreferences.contextIsolation, true);
  assert.equal(view.options.webPreferences.nodeIntegration, false);
  assert.equal(view.options.webPreferences.preload, undefined);
  assert.equal(wc.url, 'https://gemini.google.com/app');
  assert.equal(view.visible, false);
  assert.equal(ses.check(), false);
  let granted;
  ses.request(wc, 'media', value => { granted = value; });
  assert.equal(granted, false);
  wc.emit('did-finish-load');
  assert.equal(view.visible, true);
  assert.equal(states.at(-1).status, 'ready');
  wc.emit('focus'); assert.equal(focus.at(-1), true);
  web.setBounds(null); assert.equal(view.visible, false);
  assert.equal(focus.at(-1), false);
  web.setBounds({ x: 46, y: 108, width: 508, height: 556 });
  assert.equal(views.length, 1);
  assert.equal(view.visible, true);
  web.action('reload'); assert.equal(wc.reloaded, true);
  web.action('back'); assert.equal(wc.navigationHistory.back, true);
  web.action('new'); assert.equal(wc.url, 'https://gemini.google.com/app');
  web.close(); assert.equal(attached.length, 0); assert.equal(wc.closed, true);
  web.action('reload'); assert.equal(views.length, 1);
});

test('Navigation permits only exact Google HTTPS origins and never creates a popup', () => {
  const { allowed, web, views } = fixture();
  for (const url of ['https://gemini.google.com/app', 'https://accounts.google.com/ServiceLogin', 'https://consent.google.com/']) assert.equal(allowed(url), true);
  for (const url of ['http://gemini.google.com/', 'https://gemini.google.com.evil.test/', 'https://evil.test/?gemini.google.com', 'file:///C:/secret', 'javascript:alert(1)', 'https://user:pass@gemini.google.com/', 'https://gemini.google.com:8443/']) assert.equal(allowed(url), false);
  web.setBounds({ x: 0, y: 100, width: 600, height: 600 });
  const wc = views[0].webContents;
  let prevented = false;
  wc.emit('will-navigate', { preventDefault() { prevented = true; } }, 'https://evil.test');
  assert.equal(prevented, true);
  prevented = false;
  wc.emit('will-redirect', { preventDefault() { prevented = true; } }, 'file:///C:/secret');
  assert.equal(prevented, true);
  assert.equal(wc.open({ url: 'https://accounts.google.com/ServiceLogin' }).action, 'deny');
  assert.equal(wc.url, 'https://accounts.google.com/ServiceLogin');
  assert.equal(wc.open({ url: 'https://evil.test' }).action, 'deny');
  assert.equal(wc.url, 'https://accounts.google.com/ServiceLogin');
});

test('Bounds stay inside the island window and load failures offer recovery', () => {
  const { web, views, states } = fixture();
  web.setBounds({ x: NaN, y: 0, width: 600, height: 700 });
  assert.equal(views.length, 0);
  web.setBounds({ x: 50, y: 100, width: 900, height: 900 });
  const view = views[0], wc = view.webContents;
  assert.equal(view.bounds.width, 550); assert.equal(view.bounds.height, 660);
  wc.emit('did-finish-load'); assert.equal(view.visible, true);
  wc.emit('did-fail-load', {}, -105, 'offline', wc.url, true);
  assert.equal(view.visible, false); assert.equal(states.at(-1).status, 'error');
  wc.emit('did-finish-load'); assert.equal(view.visible, true);
  web.setBounds({ x: 700, y: 0, width: 100, height: 200 });
  assert.equal(view.visible, false);
});
