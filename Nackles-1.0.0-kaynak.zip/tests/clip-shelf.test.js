const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createClipHistory } = require('../src/clip-history');
const { createShelf } = require('../src/shelf');

function fakeClipboard() {
  const c = { text: '', formats: [], image: null, written: null, failRead: false, failWrite: false };
  return {
    state: c,
    async read() {
      if (c.failRead) throw Error('clipboard busy');
      const values = {};
      if (c.text) values['text/plain'] = new Blob([c.text]);
      if (c.image) values['image/png'] = new Blob([c.image]);
      for (const [name, value] of c.formats) values[`electron application/osclipboard;format="${name}"`] = new Blob([value]);
      return [{ types: Object.keys(values), async getType(type) { return values[type]; } }];
    },
    async readText() { return c.text; },
    async writeText(t) {
      if (c.failWrite) throw Error('clipboard busy');
      c.text = t; c.image = null; c.formats = []; c.written = t;
    },
    async write(clips) {
      if (c.failWrite) throw Error('clipboard busy');
      c.text = ''; c.formats = [];
      c.image = Buffer.from(await clips[0].values['image/png'].arrayBuffer());
    },
  };
}
class FakeClipboardItem { constructor(values) { this.values = values; } }
const fakeNativeImage = { createFromBuffer(bytes) { return {
  isEmpty: () => false, getSize: () => ({ width: 4, height: 4 }), toBitmap: () => bytes,
  resize() { return this; }, toDataURL: () => 'data:image/png;base64,' + bytes.toString('base64'),
}; } };

test('clipboard history uses async ClipboardItem reads, skips private copies and preserves re-copy ids', async t => {
  const cb = fakeClipboard();
  const h = createClipHistory({ clipboard: cb });
  t.after(() => h.stop());
  cb.state.text = 'açılışta vardı';
  await h.start(); h.stop(); await h.start(); // açılıştaki içerik alınmaz
  await h.poll();
  assert.equal(h.list().length, 0);

  cb.state.text = 'birinci'; await h.poll();
  cb.state.text = 'ikinci'; await h.poll();
  cb.state.text = 'gizli-parola'; cb.state.formats = [['ExcludeClipboardContentFromMonitorProcessing', '']]; await h.poll();
  cb.state.formats = [];
  assert.deepStrictEqual(h.list().map(i => i.text), ['ikinci', 'birinci']);

  cb.state.text = 'birinci'; await h.poll(); // aynı metin tekrar kopyalanınca en üste çıkar, kopya oluşmaz
  assert.deepStrictEqual(h.list().map(i => i.text), ['birinci', 'ikinci']);

  const id = h.list()[1].id;
  assert.equal(await h.copy(id), true);
  assert.equal(cb.state.written, 'ikinci');
  await h.poll(); // geri kopyaladığımız öğe yeni kayıt olmamalı
  assert.deepStrictEqual(h.list().map(i => i.text), ['ikinci', 'birinci']);
  assert.equal(h.list()[0].id, id);
  // Kendi yazdığımız panoyu izleme döngüsü görmeden yeni bir şey kopyalanırsa kaybolmamalı.
  await h.copy(h.list()[1].id);
  cb.state.text = 'hemen sonra kopyalandı'; await h.poll();
  assert.equal(h.list()[0].text, 'hemen sonra kopyalandı');

  h.clear();
  assert.equal(h.list().length, 0);
  h.stop();
});

test('Windows history flag value 1 permits capture; 0 and malformed values suppress it', async t => {
  const cb = fakeClipboard(), h = createClipHistory({ clipboard: cb });
  t.after(() => h.stop()); await h.start();
  for (const value of [Buffer.alloc(4), Buffer.from([1]), Buffer.from([2, 0, 0, 0])]) {
    cb.state.text = 'kaydedilmesin'; cb.state.formats = [['CanIncludeInClipboardHistory', value]]; await h.poll();
  }
  assert.equal(h.list().length, 0);
  cb.state.text = 'kaydedilsin'; cb.state.formats = [['CanIncludeInClipboardHistory', Buffer.from([1, 0, 0, 0])]]; await h.poll();
  assert.equal(h.list()[0].text, 'kaydedilsin');
  cb.state.text = 'parola'; cb.state.formats.push(['Clipboard Viewer Ignore', '']); await h.poll();
  assert.equal(h.list().length, 1);
});

test('same-size images are distinguished by pixels and can be copied with ClipboardItem', async t => {
  const cb = fakeClipboard(), h = createClipHistory({ clipboard: cb, nativeImage: fakeNativeImage, ClipboardItem: FakeClipboardItem });
  t.after(() => h.stop()); await h.start();
  cb.state.image = Buffer.from('pixels-one'); await h.poll();
  cb.state.image = Buffer.from('pixels-two'); await h.poll();
  assert.equal(h.list().length, 2);
  const first = h.list()[1];
  assert.equal(first.size, '4×4'); assert.match(first.thumb, /^data:image\/png;base64,/);
  assert.equal('blob' in first, false); assert.equal('image' in first, false);
  assert.equal(await h.copy(first.id), true); await h.poll();
  assert.equal(h.list().length, 2); assert.equal(h.list()[0].id, first.id);
  assert.equal(cb.state.image.toString(), 'pixels-one');
});

test('clipboard failures recover and stopping drops an unfinished asynchronous read', async t => {
  const cb = fakeClipboard(), h = createClipHistory({ clipboard: cb });
  t.after(() => h.stop()); await h.start();
  cb.state.failRead = true; cb.state.text = 'birinci'; await h.poll();
  cb.state.failRead = false; await h.poll(); assert.equal(h.list()[0].text, 'birinci');
  cb.state.failWrite = true; assert.equal(await h.copy(h.list()[0].id), false);
  cb.state.failWrite = false; cb.state.text = 'ikinci'; await h.poll();
  assert.equal(h.list()[0].text, 'ikinci');
  const read = cb.read;
  let release;
  cb.read = () => new Promise(resolve => { release = () => read().then(resolve); });
  cb.state.text = 'durdurulduktan sonra gelmesin';
  const pending = h.poll(); await new Promise(resolve => setImmediate(resolve));
  h.stop(); release(); await pending;
  assert.equal(h.list().length, 0);
  cb.read = read; await h.start(); assert.equal(h.list().length, 0);
});

test('file tray remembers paths, drops missing files, never deletes files', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'nackles-shelf-'));
  process.on('exit', () => fs.rmSync(dir, { recursive: true, force: true }));
  const a = path.join(dir, 'rapor.pdf'), b = path.join(dir, 'foto.png');
  fs.writeFileSync(a, 'x'); fs.writeFileSync(b, 'yy');
  const s = createShelf(dir);
  let list = s.add([a, b, 'goreli/yol.txt', path.join(dir, 'yok.txt')]);
  assert.deepStrictEqual(list.map(f => f.name), ['foto.png', 'rapor.pdf']);
  assert.equal(list[0].size, 2);

  list = s.remove(list[0].id);
  assert.ok(fs.existsSync(b)); // tepsiden çıkarmak dosyayı silmez
  fs.unlinkSync(a);
  assert.equal(createShelf(dir).list().length, 0); // silinen dosya listeden düşer
});
