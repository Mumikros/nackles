const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const vm = require('node:vm');
const { EventEmitter } = require('node:events');
const { PassThrough } = require('node:stream');

function fixture(t) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'nackles-chat-'));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const calls = [], events = [];
  const childProcess = {
    execFileSync(_cmd, args) { return `C:\\tools\\${args[0]}\r\n`; },
    spawn(cmd, args, opts) {
      const child = new EventEmitter();
      child.stdin = new PassThrough(); child.stdout = new PassThrough(); child.stderr = new PassThrough();
      calls.push({ cmd, args, opts, child });
      return child;
    },
  };
  const context = { module: { exports: {} }, process, require: name => name === 'node:child_process' ? childProcess : require(name) };
  vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../src/chat.js'), 'utf8'), context);
  const chat = context.module.exports.createChat({ userData: root, onEvent: e => events.push(e) });
  return { chat, calls, events };
}
function emit(child, event, newline = true) { child.stdout.write(JSON.stringify(event) + (newline ? '\n' : '')); }

test('Codex and ChatGPT keep independent sessions and read-only configuration on resume', t => {
  const { chat, calls } = fixture(t);
  for (const agent of ['codex', 'chatgpt']) {
    chat.send(agent, agent, 'ilk');
    const child = calls.at(-1).child;
    emit(child, { type: 'thread.started', thread_id: `${agent}-thread` });
    emit(child, { type: 'item.completed', item: { type: 'agent_message', text: 'tamam' } });
    child.emit('close', 0);
  }
  for (const agent of ['codex', 'chatgpt']) {
    chat.send(`${agent}-next`, agent, 'ikinci');
    const { args } = calls.at(-1);
    assert.equal(args[1], 'resume');
    assert.ok(args.includes(`${agent}-thread`));
    assert.ok(args.includes('sandbox_mode="read-only"'));
    assert.equal(args.includes('--sandbox'), false);
    assert.equal(args.includes('--color'), false);
  }
  chat.reset('chatgpt');
  chat.send('fresh', 'chatgpt', 'yeni');
  assert.equal(calls.at(-1).args.includes('resume'), false);
});

test('Gemini never launches a CLI process', t => {
  const { chat, calls } = fixture(t);
  chat.send('g1', 'gemini', 'merhaba');
  assert.equal(calls.length, 0);
  assert.equal(chat.available().gemini, undefined);
});

test('Stopping ignores late output and closing an empty stream is an error', t => {
  const { chat, calls, events } = fixture(t);
  chat.send('stopped', 'codex', 'merhaba');
  chat.stop('stopped');
  const count = events.length;
  emit(calls[0].child, { type: 'thread.started', thread_id: 'stale' });
  emit(calls[0].child, { type: 'item.completed', item: { type: 'agent_message', text: 'geç yanıt' } });
  calls[0].child.emit('close', 0);
  assert.equal(events.length, count);
  assert.equal(events.at(-1).stopped, true);
  chat.send('empty', 'codex', 'merhaba');
  assert.equal(calls.at(-1).args.includes('--resume'), false);
  calls.at(-1).child.emit('close', 0);
  assert.equal(events.at(-1).type, 'error');
});

test('Chat IPC routes every agent and opens only fixed service addresses', async () => {
  const source = fs.readFileSync(path.join(__dirname, '../src/main.js'), 'utf8');
  const block = source.slice(source.indexOf('const CHAT_AGENTS ='), source.indexOf('// Hızlı işlemler'));
  const handlers = {}, sent = [], reset = [], opened = [];
  let schemeExists = true, schemeFails = false;
  const ctx = {
    process: { platform: 'win32' },
    ipcMain: { on(name, fn) { handlers[name] = fn; }, handle() {} },
    chat: { send: (...args) => sent.push(args), reset: a => reset.push(a) },
    shell: { async openExternal(url) { if (schemeFails && !url.startsWith('https:')) throw Error('cannot open'); opened.push(url); } },
    async execFileAsync(cmd, args) { assert.equal(cmd, 'reg.exe'); assert.match(args[1], /^HKCR\\(claude|codex|chatgpt)$/); if (!schemeExists) throw Error('missing'); },
    log() {},
  };
  vm.runInNewContext(block, ctx);
  const agents = ['claude', 'codex', 'chatgpt', 'gemini'];
  for (const agent of agents) {
    handlers['chat:send']({}, { id: '1', agent, text: 'merhaba' });
    handlers['chat:reset']({}, agent);
    await handlers['chat:open-app']({}, agent);
  }
  assert.deepEqual(sent.map(a => a[1]), agents.slice(0, 3));
  assert.deepEqual(reset, agents);
  assert.deepEqual(opened, ['claude://', 'codex://', 'chatgpt://', 'https://gemini.google.com/app']);
  schemeExists = false;
  for (const agent of agents.slice(0, 3)) await handlers['chat:open-app']({}, agent);
  assert.deepEqual(opened.slice(-3), ['https://claude.ai/new', 'https://chatgpt.com/codex', 'https://chatgpt.com/']);
  schemeExists = true; schemeFails = true;
  await handlers['chat:open-app']({}, 'chatgpt');
  assert.equal(opened.at(-1), 'https://chatgpt.com/');
  await handlers['chat:open-app']({}, 'https://evil.example/');
  assert.equal(opened.at(-1), 'https://claude.ai/new');
});
