const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createNotes, MAX_LEN } = require('../src/notes');

test('notes are added newest first, edited, ticked and removed, and survive a restart', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'nackles-notes-'));
  process.on('exit', () => fs.rmSync(dir, { recursive: true, force: true }));
  const n = createNotes(dir);
  n.add('  süt al  ');
  n.add('');
  let list = n.add('PR yorumlarına bak');
  assert.deepStrictEqual(list.map(x => x.text), ['PR yorumlarına bak', 'süt al']);

  list = n.update(list[1].id, { done: true });
  assert.equal(list[1].done, true);
  list = n.update(list[0].id, { text: 'x'.repeat(MAX_LEN + 50) });
  assert.equal(list[0].text.length, MAX_LEN);

  assert.equal(createNotes(dir).list().length, 2);
  list = n.clearDone();
  assert.equal(list.length, 1);
  list = n.update(list[0].id, { text: '   ' }); // boş metin notu siler
  assert.equal(list.length, 0);
});

test('notepad saves all lines in order and drops trailing empty lines', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'nackles-pad-'));
  process.on('exit', () => fs.rmSync(dir, { recursive: true, force: true }));
  const n = createNotes(dir);
  const list = n.set([{ text: 'Alışveriş' }, { text: 'süt', task: true }, { text: 'ekmek', task: true, done: true }, { text: '' }, { text: '' }]);
  assert.deepStrictEqual(list.map(x => [x.text, x.task, x.done]), [['Alışveriş', false, false], ['süt', true, false], ['ekmek', true, true]]);
  assert.equal(createNotes(dir).list().length, 3);
});
