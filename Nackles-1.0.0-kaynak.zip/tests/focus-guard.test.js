const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createGuard, match } = require('../src/focus-guard');

test('distracting sites are recognised by browser title or app process', () => {
  const all = ['youtube', 'x', 'discord', 'netflix'];
  assert.equal(match({ proc: 'brave', title: 'Kedi videosu - YouTube - Brave' }, all), 'youtube');
  assert.equal(match({ proc: 'chrome', title: 'Ana sayfa / X - Google Chrome' }, all), 'x');
  assert.equal(match({ proc: 'Discord', title: '#genel | Sunucu' }, all), 'discord');
  assert.equal(match({ proc: 'Code', title: 'youtube-api.ts - Visual Studio Code' }, all), null); // editörde "youtube" geçmesi sayılmaz
  assert.equal(match({ proc: 'chrome', title: 'Kedi videosu - YouTube' }, ['x']), null); // seçilmeyen site korunmaz
});

test('guard only acts while focusing, snoozes after "open anyway" and counts the day', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'nackles-guard-'));
  process.on('exit', () => fs.rmSync(dir, { recursive: true, force: true }));
  let t = Date.parse('2026-11-01T10:00:00Z'), focusing = false;
  const settings = { focusGuard: { on: true, always: false, sites: ['youtube'], snoozeMin: 5 } };
  const shown = [];
  const g = createGuard({ userData: dir, getSettings: () => settings, focusRunning: () => focusing, onTrigger: e => shown.push(e.name), now: () => t });
  const yt = { proc: 'brave', title: 'Video - YouTube' };

  assert.equal(g.check(yt), null); // odak sayacı çalışmıyor
  focusing = true;
  assert.equal(g.check(yt), 'youtube');
  assert.equal(g.check(yt), null); // ekran zaten açık
  g.answer('back');
  assert.deepStrictEqual(g.todayStats(), { back: 1, open: 0 });

  assert.equal(g.check(yt), 'youtube');
  g.answer('open');
  t += 4 * 60000;
  assert.equal(g.check(yt), null); // 5 dk rahat bırakılır
  t += 2 * 60000;
  assert.equal(g.check(yt), 'youtube');
  g.answer('back');
  assert.deepStrictEqual(shown, ['YouTube', 'YouTube', 'YouTube']);
  assert.deepStrictEqual(createGuard({ userData: dir, getSettings: () => settings, now: () => t }).todayStats(), { back: 2, open: 1 });

  settings.focusGuard.on = false;
  assert.equal(g.check(yt), null);
});
