// Logo dosyalarını üretir: src/assets/logo.svg → icon-16…256.png ve icon.ico (Windows uygulama ikonu).
// Çalıştırma: npx electron scripts/make-icons.js
const { app, BrowserWindow } = require('electron');
const fs = require('node:fs');
const path = require('node:path');

const SIZES = [16, 20, 24, 32, 40, 48, 64, 128, 256];
const assets = path.join(__dirname, '..', 'src', 'assets');

// ICO: başlık + her boyut için bir girdi + PNG verileri (Windows Vista'dan beri PNG'li ICO desteklenir)
function buildIco(images) {
  const header = Buffer.alloc(6); header.writeUInt16LE(0, 0); header.writeUInt16LE(1, 2); header.writeUInt16LE(images.length, 4);
  const entries = [], datas = [];
  let offset = 6 + 16 * images.length;
  for (const { size, png } of images) {
    const e = Buffer.alloc(16);
    e.writeUInt8(size >= 256 ? 0 : size, 0); e.writeUInt8(size >= 256 ? 0 : size, 1);
    e.writeUInt8(0, 2); e.writeUInt8(0, 3); e.writeUInt16LE(1, 4); e.writeUInt16LE(32, 6);
    e.writeUInt32LE(png.length, 8); e.writeUInt32LE(offset, 12);
    offset += png.length; entries.push(e); datas.push(png);
  }
  return Buffer.concat([header, ...entries, ...datas]);
}

app.disableHardwareAcceleration();
app.whenReady().then(async () => {
  const svg = fs.readFileSync(path.join(assets, 'logo.svg'), 'utf8');
  const win = new BrowserWindow({ show: false, width: 256, height: 256, transparent: true, frame: false, webPreferences: { offscreen: true } });
  const images = [];
  for (const size of SIZES) {
    win.setContentSize(size, size);
    const html = `<html><body style="margin:0;background:transparent">${svg.replace('<svg ', `<svg width="${size}" height="${size}" `)}</body></html>`;
    await win.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(html));
    await new Promise(r => setTimeout(r, 150));
    const img = await win.webContents.capturePage({ x: 0, y: 0, width: size, height: size });
    const png = img.resize({ width: size, height: size, quality: 'best' }).toPNG();
    fs.writeFileSync(path.join(assets, `icon-${size}.png`), png);
    images.push({ size, png });
  }
  fs.writeFileSync(path.join(assets, 'icon.ico'), buildIco(images.filter(i => [16, 24, 32, 48, 64, 128, 256].includes(i.size))));
  fs.copyFileSync(path.join(assets, 'icon-256.png'), path.join(assets, 'icon.png'));
  console.log('ikonlar hazır:', SIZES.join(', '));
  app.quit();
});
