// Checks only tracked publication files. Findings print locations, never secret values.
const fs = require('node:fs');
const { execFileSync } = require('node:child_process');
const files = execFileSync('git', ['ls-files', '-z'], { encoding: 'utf8' }).split('\0').filter(Boolean);
if (!files.length) throw new Error('No tracked publication files');
const allowed = /^(?:src\/|tests\/|scripts\/|build\/installer\.nsh$|\.github\/|\.gitignore$|LICENSE$|README\.md$|SECURITY\.md$|SUPPORT\.md$|RELEASE_NOTES\.md$|package(?:-lock)?\.json$)/;
const denied = /(?:^|\/)(?:DEVAM\.md|\.env(?:\..*)?|hook-token|Cookies|Login Data|Web Data)|\.(?:log|pfx|p12|pem|key|dmp|bak|nackles-yedek)$/i;
const patterns = [
  ['private key', /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/],
  ['GitHub token', /\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})\b/],
  ['provider key', /\b(?:sk-(?:proj-|ant-)?[A-Za-z0-9_-]{32,}|AIza[A-Za-z0-9_-]{30,}|AKIA[A-Z0-9]{16})\b/],
  ['personal email', /\b[A-Za-z0-9._%+-]+@(?:gmail|hotmail|outlook|yahoo)\.[a-z.]+\b/i],
  ['credential URL', /https?:\/\/[^\s/@:]+:[^\s/@]+@/i],
];
const problems = [];
for (const file of files) {
  if (!allowed.test(file) || denied.test(file)) problems.push(`${file}: excluded publication path`);
  const data = fs.readFileSync(file);
  if (/\.(png|ico)$/.test(file)) {
    if (/\.(png)$/.test(file)) {
      for (let at = 8; at + 12 <= data.length;) {
        const n = data.readUInt32BE(at), type = data.toString('ascii', at + 4, at + 8);
        if (['tEXt', 'zTXt', 'iTXt', 'eXIf'].includes(type)) problems.push(`${file}: inspect image metadata (${type})`);
        at += n + 12;
      }
    }
    continue;
  }
  const lines = data.toString('utf8').split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    // Only this literal dummy credential URL is an intentional negative navigation fixture.
    const line = file === 'tests/gemini-web.test.js' ? lines[i].replace(/https:\/\/user:pass@gemini\.google\.com\//, 'dummy-credential-url') : lines[i];
    for (const [label, pattern] of patterns) if (pattern.test(line)) problems.push(`${file}:${i + 1}: ${label}`);
    // Generic fixtures use Users/me; real developer home paths must not be published.
    if (/[A-Z]:[\\/]+Users[\\/]+(?!me[\\/]|test[\\/]|Public[\\/]|Default[\\/])[^\s'"\\/]+/i.test(lines[i])) problems.push(`${file}:${i + 1}: personal home path`);
  }
}
if (problems.length) { console.error(problems.join('\n')); process.exitCode = 1; }
else console.log(`Publication checks passed: ${files.length} tracked files. Pattern checks are not a security guarantee.`);
